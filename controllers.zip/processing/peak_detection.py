# processing/peak_detection.py
import numpy as np
from scipy.signal import find_peaks
import traceback


def diagnose_array(arr, name):
    """Função de diagnóstico para imprimir detalhes de arrays."""
    print(f"\n🔍 DIAGNÓSTICO: {name}")
    print(f"  Tipo: {type(arr)}")

    if hasattr(arr, 'shape'):
        print(f"  Shape: {arr.shape}")
        print(f"  Dimensões: {arr.ndim}")
        print(f"  Tamanho total: {arr.size}")
        print(f"  dtype: {arr.dtype}")
        if arr.size > 0:
            print(f"  Min: {np.min(arr):.4f}")
            print(f"  Max: {np.max(arr):.4f}")
            print(f"  Primeiros 5: {arr.flatten()[:5]}")
    else:
        print(f"  ⚠️ Não é um array numpy: {type(arr)}")
        try:
            arr_np = np.array(arr)
            print(f"  Convertido para numpy: shape {arr_np.shape}")
        except:
            print(f"  ❌ Não foi possível converter para numpy")


def detect_peaks(ppm, intensities, noise_std, min_snr=3, min_distance=0.01):
    """
    Detect peaks with SNR > min_snr - VERSÃO ULTRA DEFENSIVA.
    """
    print("\n" + "=" * 70)
    print("🚨 INICIANDO DETECÇÃO DE PICOS - MODO DIAGNÓSTICO 🚨")
    print("=" * 70)

    try:
        # PASSO 1: Diagnosticar entradas
        diagnose_array(ppm, "ppm (original)")
        diagnose_array(intensities, "intensities (original)")

        # PASSO 2: Garantir que intensities seja numpy array
        if not isinstance(intensities, np.ndarray):
            print("\n📦 Convertendo intensities para numpy array...")
            intensities = np.array(intensities)
            diagnose_array(intensities, "intensities (após np.array)")

        # PASSO 3: Garantir que ppm seja numpy array
        if not isinstance(ppm, np.ndarray):
            print("\n📦 Convertendo ppm para numpy array...")
            ppm = np.array(ppm)
            diagnose_array(ppm, "ppm (após np.array)")

        # PASSO 4: Verificar dimensões de intensities
        print(f"\n📊 intensities.ndim = {intensities.ndim}")
        if intensities.ndim == 1:
            print("   intensities é 1D - convertendo para 2D com reshape(-1, 1)")
            intensities_2d = intensities.reshape(-1, 1)
        elif intensities.ndim == 2:
            print(f"   intensities é 2D com shape {intensities.shape}")
            intensities_2d = intensities
        else:
            raise ValueError(f"intensities tem {intensities.ndim} dimensões - deveria ser 1 ou 2")

        diagnose_array(intensities_2d, "intensities_2d")

        # PASSO 5: Verificar comprimentos
        if len(ppm) != intensities_2d.shape[0]:
            raise ValueError(
                f"Incompatibilidade: ppm tem {len(ppm)} pontos, "
                f"mas intensities tem {intensities_2d.shape[0]} pontos"
            )

        # PASSO 6: Calcular média das amostras
        print(f"\n📊 intensities_2d.shape[1] = {intensities_2d.shape[1]} (número de amostras)")

        if intensities_2d.shape[1] > 1:
            print("   Calculando média das amostras...")
            mean_intensity = np.mean(intensities_2d, axis=1)
        else:
            print("   Apenas uma amostra - usando flatten()")
            mean_intensity = intensities_2d.flatten()

        diagnose_array(mean_intensity, "mean_intensity")

        # PASSO 7: Calcular parâmetros
        ppm_range = np.max(ppm) - np.min(ppm)
        n_points = len(ppm)
        distance_in_points = max(1, int(min_distance / (ppm_range / n_points)))
        min_height = noise_std * min_snr

        print(f"\n⚙️ Parâmetros:")
        print(f"   ppm_range: {ppm_range:.4f}")
        print(f"   n_points: {n_points}")
        print(f"   distance_in_points: {distance_in_points}")
        print(f"   min_height: {min_height:.4f}")
        print(f"   noise_std: {noise_std:.4f}")
        print(f"   min_snr: {min_snr}")

        # PASSO 8: Encontrar picos
        print("\n🔍 Executando find_peaks...")
        peaks, properties = find_peaks(
            mean_intensity,
            height=min_height,
            distance=distance_in_points
        )

        print(f"   ✅ Picos encontrados: {len(peaks)}")

        # PASSO 9: Construir lista de picos
        peak_list = []
        for i, idx in enumerate(peaks):
            # Encontrar limites
            left = idx
            while left > 0 and mean_intensity[left] > noise_std:
                left -= 1

            right = idx
            while right < len(mean_intensity) - 1 and mean_intensity[right] > noise_std:
                right += 1

            snr = mean_intensity[idx] / noise_std if noise_std > 0 else 0

            peak_list.append({
                'index': int(idx),
                'ppm': float(ppm[idx]),
                'height': float(mean_intensity[idx]),
                'snr': float(snr),
                'start_ppm': float(ppm[left]),
                'end_ppm': float(ppm[right]),
                'width_ppm': float(abs(ppm[right] - ppm[left]))
            })

        # Ordenar por SNR
        peak_list.sort(key=lambda x: x['snr'], reverse=True)

        # Adicionar rank
        for i, peak in enumerate(peak_list, 1):
            peak['rank'] = i

        print(f"\n✅ Detecção concluída: {len(peak_list)} picos")
        if peak_list:
            print(f"   Primeiro pico: {peak_list[0]['ppm']:.4f} ppm (SNR: {peak_list[0]['snr']:.1f})")

        return peak_list

    except Exception as e:
        print(f"\n❌ ERRO NA DETECÇÃO DE PICOS:")
        print(f"   {str(e)}")
        print("\n📋 Traceback completo:")
        traceback.print_exc()
        print("=" * 70)

        # Relançar a exceção para ser capturada na interface
        raise