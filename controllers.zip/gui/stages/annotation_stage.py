# gui/stages/annotation_stage.py
"""
Metabolites Annotation Stage — Step 3.

Algorithm
---------
1. Align spectrum to 0 ppm (DSS/TSP) using the same anchor as peak_alignment.
2. For each detected peak, query DB candidates within tolerance.
3. Score each candidate:
   a. PPM distance score (Gaussian, σ = tolerance/2)
   b. Multiplet pattern score: find surrounding peaks that form the expected
      multiplet pattern using J from DB, score position + relative intensity.
4. Rank by composite score = 0.4×ppm_score + 0.6×multiplet_score.
5. Open results window showing ranked candidates with fingerprint overlay.
"""
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import numpy as np
import os
import time
import threading
import sqlite3
import certifi

os.environ['SSL_CERT_FILE']      = certifi.where()
os.environ['REQUESTS_CA_BUNDLE'] = certifi.where()

from .base_stage import BaseStage


# ── Alignment helper ──────────────────────────────────────────────────────────

def _align_peaks_to_reference(peaks, ppm_arr, all_intensities,
                               ref_ppm=0.0, window=0.05):
    """
    Return shift_ppm: the delta to add to all experimental PPM values
    so that the reference signal (DSS/TSP at ref_ppm) lands exactly at ref_ppm.

    Uses the mean spectrum to find the reference peak maximum.
    """
    if ppm_arr is None or all_intensities is None:
        return 0.0
    try:
        mean_y = np.mean(all_intensities, axis=1) \
                 if all_intensities.ndim == 2 else all_intensities
        mask   = (ppm_arr >= ref_ppm - window) & (ppm_arr <= ref_ppm + window)
        if not np.any(mask):
            return 0.0
        idx_in_win = np.argmax(mean_y[mask])
        current    = ppm_arr[mask][idx_in_win]
        return float(ref_ppm - current)   # positive = shift right
    except Exception:
        return 0.0


# ── Scoring helpers ───────────────────────────────────────────────────────────

def _ppm_score(exp_ppm, db_ppm, tolerance):
    """Gaussian score centred at 0 delta. Score=1 at perfect match."""
    sigma = tolerance / 2.0
    return float(np.exp(-0.5 * ((exp_ppm - db_ppm) / sigma) ** 2))


def _multiplet_score(result, peaks, tolerance, mhz,
                     ppm_array=None, intensity_array=None):
    """
    Wrapper around multiplet_scorer.score_multiplet_match.
    Returns (score 0-1, detail str, predicted_lines list).
    """
    try:
        from gui.notation.multiplet_scorer import score_multiplet_match
        return score_multiplet_match(result, peaks, tolerance, mhz,
                                     ppm_array=ppm_array,
                                     intensity_array=intensity_array)
    except Exception as e:
        return 0.0, f'scorer error: {e}', []


def _mult_compat_check(result, aligned_peaks, tolerance, mhz):
    """
    Classify the observed multiplicity near a DB candidate and return a
    compatibility score (0–1) between the expected (DB) and observed pattern.

    Returns (compat_score, observed_mult_str).
    1.0 = fully compatible, ~0.1 = strong mismatch (e.g. expected doublet, saw singlet).
    """
    try:
        import re as _re
        from gui.notation.multiplet_scorer import (
            classify_observed_multiplicity,
            multiplicity_compat_score,
            _norm as _mult_norm,
        )
        db_ppm   = float(result.get('ppm_center') or result.get('ppm') or 0)
        mult_raw = result.get('multiplicity') or result.get('type') or 's'
        j_str    = result.get('j_coupling', '') or ''
        j_nums   = [float(x) for x in _re.findall(r'\d+\.?\d*', j_str) if float(x) > 0]
        j_hz     = j_nums[0] if j_nums else 0.0

        # Search window: wide enough to catch all multiplet lines
        norm     = _mult_norm(mult_raw)
        n_lines  = {'s':1,'d':2,'t':3,'q':4,'quin':5,'dd':4,'ddd':8,'dt':6,'td':6}.get(norm, 3)
        j_ppm    = (j_hz / mhz) if j_hz > 0 and mhz > 0 else 0.0
        win      = max(j_ppm * (n_lines / 2) * 1.5, tolerance * 1.5, 0.008)

        peaks_near = [p for p in aligned_peaks if abs(p['ppm'] - db_ppm) <= win]
        obs_mult, obs_conf = classify_observed_multiplicity(peaks_near, j_hz, mhz)
        compat = multiplicity_compat_score(mult_raw, obs_mult, obs_conf)
        return compat, obs_mult
    except Exception:
        return 1.0, '?'


def _adaptive_mcr_mask(ppm_full, all_int, peak, cands=None, field_mhz=600.0):
    """
    Build an adaptive MCR region mask around a peak.
    Expands beyond the picked peak limits using candidate DB bounds + local signal,
    so MCR is not artificially clipped to only the peak head.
    """
    p_lo = float(min(peak.get('start_ppm', peak['ppm']), peak.get('end_ppm', peak['ppm'])))
    p_hi = float(max(peak.get('start_ppm', peak['ppm']), peak.get('end_ppm', peak['ppm'])))
    width = max(abs(p_hi - p_lo), 1e-4)
    margin = max(0.01, width * 1.5)
    lo = p_lo - margin
    hi = p_hi + margin

    # Expand by DB multiplet extents when available.
    cands = cands or []
    n_lines_map = {'s': 1, 'd': 2, 't': 3, 'q': 4, 'quin': 5, 'dd': 4, 'ddd': 8, 'dt': 6, 'td': 6}
    for c in cands:
        try:
            cp = float(c.get('ppm_center') or c.get('ppm') or peak['ppm'])
            cs = c.get('ppm_start')
            ce = c.get('ppm_end')
            if cs is not None and ce is not None:
                lo = min(lo, float(cs) - 0.006)
                hi = max(hi, float(ce) + 0.006)
            else:
                mult = str(c.get('type') or c.get('multiplicity') or 's').lower().strip()
                n_lines = n_lines_map.get(mult, 2)
                j_raw = str(c.get('j_coupling') or '')
                j_hz = 0.0
                try:
                    j_hz = float(j_raw.split(',')[0].strip()) if j_raw else 0.0
                except Exception:
                    j_hz = 0.0
                split_ppm = (j_hz / max(field_mhz, 1e-9)) * max(1, n_lines - 1)
                side = max(0.006, split_ppm * 0.8)
                lo = min(lo, cp - side)
                hi = max(hi, cp + side)
        except Exception:
            continue

    # Expand further using local signal envelope around peak center.
    try:
        y_full = (np.mean(all_int, axis=1) if getattr(all_int, 'ndim', 1) == 2
                  else np.asarray(all_int))
        base_mask = (ppm_full >= lo) & (ppm_full <= hi)
        if np.sum(base_mask) > 4:
            xw = ppm_full[base_mask]
            yw = y_full[base_mask]
            c_idx = int(np.argmin(np.abs(xw - float(peak.get('ppm', (p_lo + p_hi) * 0.5)))))
            y_min = float(np.min(yw))
            y_max = float(np.max(yw))
            thr = y_min + 0.10 * (y_max - y_min)
            l = c_idx
            while l > 0 and yw[l] > thr:
                l -= 1
            r = c_idx
            while r < len(yw) - 1 and yw[r] > thr:
                r += 1
            sig_margin = max(0.01, width * 0.8)
            lo = min(lo, float(xw[l]) - sig_margin)
            hi = max(hi, float(xw[r]) + sig_margin)
    except Exception:
        pass

    ppm_min = float(np.min(ppm_full)); ppm_max = float(np.max(ppm_full))
    lo = max(ppm_min, lo)
    hi = min(ppm_max, hi)
    mask = (ppm_full >= lo) & (ppm_full <= hi)
    return mask


def _pick_database(parent_widget):
    """Show a dialog to pick a database: bundled DBs or browse for a file.

    Returns the selected file path, or None if cancelled.
    """
    # Discover bundled databases in  <project_root>/databases/
    _here = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    _db_folder = os.path.join(_here, 'databases')
    bundled = []
    if os.path.isdir(_db_folder):
        for fname in sorted(os.listdir(_db_folder)):
            if fname.lower().endswith(('.db', '.csv')):
                bundled.append(os.path.join(_db_folder, fname))

    # If no bundled DBs, fall back directly to file dialog
    if not bundled:
        return filedialog.askopenfilename(
            title='Select Database File',
            filetypes=[('Database files', '*.db *.csv'),
                       ('SQLite', '*.db'), ('CSV', '*.csv'),
                       ('All files', '*.*')],
            initialdir=os.path.expanduser('~'))

    result = [None]

    dlg = tk.Toplevel(parent_widget)
    dlg.title('Select Database')
    dlg.resizable(False, False)
    dlg.grab_set()

    tk.Label(dlg, text='Choose a bundled database or browse for another file:',
             font=('TkDefaultFont', 10, 'bold'), pady=8).pack(padx=16, pady=(12, 4))

    frame = tk.Frame(dlg)
    frame.pack(padx=16, pady=4, fill='both', expand=True)

    scrollbar = tk.Scrollbar(frame, orient='vertical')
    lb = tk.Listbox(frame, yscrollcommand=scrollbar.set, selectmode='single',
                    height=min(len(bundled) + 1, 12), width=52,
                    font=('TkFixedFont', 10))
    scrollbar.config(command=lb.yview)
    scrollbar.pack(side='right', fill='y')
    lb.pack(side='left', fill='both', expand=True)

    for path in bundled:
        name = os.path.splitext(os.path.basename(path))[0].replace('_', ' ').title()
        lb.insert('end', f'  {name}')

    lb.insert('end', '  Browse for another file…')
    lb.select_set(0)

    def _confirm():
        sel = lb.curselection()
        if not sel:
            return
        idx = sel[0]
        if idx < len(bundled):
            result[0] = bundled[idx]
            dlg.destroy()
        else:
            path = filedialog.askopenfilename(
                title='Select Database File',
                filetypes=[('Database files', '*.db *.csv'),
                           ('SQLite', '*.db'), ('CSV', '*.csv'),
                           ('All files', '*.*')],
                initialdir=os.path.expanduser('~'))
            if path:
                result[0] = path
                dlg.destroy()

    def _cancel():
        dlg.destroy()

    btn_frame = tk.Frame(dlg)
    btn_frame.pack(padx=16, pady=(8, 14))
    tk.Button(btn_frame, text='Select', width=12, command=_confirm).pack(side='left', padx=6)
    tk.Button(btn_frame, text='Cancel', width=12, command=_cancel).pack(side='left', padx=6)

    lb.bind('<Double-Button-1>', lambda e: _confirm())
    dlg.bind('<Return>', lambda e: _confirm())
    dlg.bind('<Escape>', lambda e: _cancel())

    # Centre dialog on parent
    dlg.update_idletasks()
    pw = parent_widget.winfo_rootx() + parent_widget.winfo_width() // 2
    ph = parent_widget.winfo_rooty() + parent_widget.winfo_height() // 2
    w, h = dlg.winfo_width(), dlg.winfo_height()
    dlg.geometry(f'+{pw - w//2}+{ph - h//2}')

    parent_widget.wait_window(dlg)
    return result[0]


class AnnotationStage(BaseStage):

    def __init__(self, parent, app, peak_stage):
        super().__init__(parent, app)
        self.peak_stage         = peak_stage
        self.annotations        = {}
        self._last_results_args = None
        self._metabolites       = None   # live reference set by AnnotationResultsWindow
        self._quality_marks       = {}   # {(met_id, peak_rank): 'good'|'bad'} — persisted
        self._child_quality_marks = {}   # {(met_id, round(dp_ppm,3)): 'good'|'bad'} — persisted
        self.mcr_r2_threshold   = 0.95   # used by annotation MCR deconvolution
        self.create_widgets()

    # ── Status helpers ────────────────────────────────────────────────────────

    def _status(self, msg, color='blue'):
        try:
            self.app.status_label.config(text=msg, foreground=color)
            self.app.root.update_idletasks()
        except Exception:
            pass

    def _status_ok(self,  m): self._status(m, 'green')
    def _status_err(self, m): self._status(m, 'red')
    def _status_ready(self):  self._status('Ready', 'gray')

    @property
    def peaks(self):
        return self.peak_stage.peaks

    # ── Widgets ───────────────────────────────────────────────────────────────

    def create_widgets(self):
        self.frame = ttk.Frame(self.parent)

        ttk.Label(self.frame, text='Metabolites Annotation',
                  font=('Arial', 12, 'bold')).pack(pady=10)
        ttk.Separator(self.frame, orient='horizontal').pack(
            fill=tk.X, padx=5, pady=5)

        s3 = ttk.LabelFrame(self.frame, text='📡 Database Search', padding=5)
        s3.pack(fill=tk.X, padx=5, pady=5)

        tf = ttk.Frame(s3); tf.pack(fill=tk.X, pady=2)
        ttk.Label(tf, text='Tolerance (ppm):', width=18).pack(side=tk.LEFT)
        self.tolerance_var = tk.DoubleVar(value=0.05)
        ttk.Entry(tf, textvariable=self.tolerance_var, width=7).pack(
            side=tk.LEFT, padx=2)

        sf = ttk.Frame(s3); sf.pack(fill=tk.X, pady=2)
        ttk.Label(sf, text='Spectrometer (MHz):', width=18).pack(side=tk.LEFT)
        self.spectrometer_var = tk.StringVar(value='600')
        ttk.Entry(sf, textvariable=self.spectrometer_var, width=7).pack(
            side=tk.LEFT, padx=2)
        ttk.Label(sf, text='for J Hz→ppm',
                  font=('Arial', 7), foreground='gray').pack(
                      side=tk.LEFT, padx=4)

        bf = ttk.Frame(s3); bf.pack(fill=tk.X, pady=5)
        self.btn_search_internal = ttk.Button(
            bf, text='🔍 Search in External DB',
            command=self.search_internal_db)
        self.btn_search_internal.pack(
            side=tk.LEFT, expand=True, fill=tk.X, padx=2)
        self.btn_search_online = ttk.Button(
            bf, text='📚 Use Internal DB',
            command=self.search_builtin_library)
        self.btn_search_online.pack(
            side=tk.LEFT, expand=True, fill=tk.X, padx=2)

        self.internal_status = ttk.Label(
            s3, text='Internal DB: ready', foreground='gray')
        self.internal_status.pack(anchor=tk.W, pady=2)
        self.hmdb_status = ttk.Label(
            s3, text='Internal DB: ready', foreground='gray')
        self.hmdb_status.pack(anchor=tk.W, pady=2)

        info_frame = ttk.LabelFrame(
            self.frame, text='📊 Current Peaks', padding=5)
        info_frame.pack(fill=tk.X, padx=5, pady=5)
        self.peaks_info_label = ttk.Label(
            info_frame, text='No peaks detected yet.', foreground='gray')
        self.peaks_info_label.pack(anchor=tk.W)
        ttk.Label(info_frame,
                  text='Only peaks marked Good in Peak List are annotated.',
                  font=('Arial', 7), foreground='gray').pack(anchor=tk.W)

        mf = ttk.LabelFrame(self.frame, text='🐭 Mouse Controls', padding=5)
        mf.pack(fill=tk.X, padx=5, pady=5)
        ttk.Label(mf,
                  text='• Scroll: Zoom in/out\n'
                       '• Drag: Pan\n'
                       '• R: Reset view',
                  font=('Arial', 8), foreground='blue',
                  justify=tk.LEFT).pack(anchor=tk.W, padx=5)

        mcr_frame = ttk.LabelFrame(self.frame, text='🔬 MCR Deconvolution', padding=5)
        mcr_frame.pack(fill=tk.X, padx=5, pady=5)
        ttk.Label(mcr_frame,
                  text='Deconvolve overlapping peaks using MCR-ALS.',
                  font=('Arial', 8), foreground='gray').pack(anchor=tk.W)
        ttk.Button(mcr_frame, text='▶ Run MCR Deconvolution',
                   command=self._launch_mcr).pack(anchor=tk.W, pady=4)
        ttk.Button(mcr_frame, text='🛟 Rescue Unassigned Peaks (MCR)',
                   command=self._rescue_unassigned_with_mcr).pack(anchor=tk.W, pady=(0, 3))

    # ── Lifecycle ─────────────────────────────────────────────────────────────

    def on_activate(self):
        self.frame.pack(fill=tk.BOTH, expand=True)
        n      = len(self.peaks)
        n_good = sum(1 for p in self.peaks
                     if p.get('status', 'Undefined') == 'Good')
        if n == 0:
            self.peaks_info_label.config(
                text='No peaks detected yet.', foreground='gray')
        elif n_good == 0:
            self.peaks_info_label.config(
                text=f'{n} peaks — 0 marked Good. Mark in Peak List first.',
                foreground='orange')
        else:
            self.peaks_info_label.config(
                text=f'{n} peaks loaded — {n_good} Good (will annotate).',
                foreground='blue')

    def on_deactivate(self):
        self.frame.pack_forget()

    def _launch_mcr(self):
        """Launch the Full Spectrum MCR stage UI as a popup."""
        from gui.stages.fullspectrum_mcr_stage import FullSpectrumMCRStage
        # Switch to the fullspectrum_mcr stage if it exists in app.stages
        if 'fullspectrum_mcr' in self.app.stages:
            self.app.switch_stage('fullspectrum_mcr')
        else:
            messagebox.showinfo('MCR', 'MCR stage not available.')

    def _rescue_unassigned_with_mcr(self):
        """
        Rescue pass for Good peaks that remained unassigned after annotation.
        Uses relaxed DB search + scoring and then applies MCR on rescued
        multi-candidate regions.
        """
        if not self.peaks:
            messagebox.showinfo('Info', 'No peaks detected.')
            return
        if not self._last_results_args:
            messagebox.showinfo('Info', 'Run annotation first, then rescue unassigned peaks.')
            return

        db_path = (self._last_results_args.get('db_path')
                   or getattr(self.app, '_last_db_path', None))
        if not db_path or not str(db_path).lower().endswith('.db') or not os.path.isfile(db_path):
            messagebox.showinfo('Info', 'Rescue requires a valid SQLite DB (.db) from annotation search.')
            return

        try:
            tolerance = float(self.tolerance_var.get())
        except Exception:
            tolerance = 0.05
        relax_tol = min(0.20, max(tolerance + 0.01, tolerance * 1.8))
        delta_max = max(0.05, relax_tol * 1.2)
        try:
            mhz = float(self.spectrometer_var.get())
        except Exception:
            mhz = 600.0

        existing_results = list(self._last_results_args.get('results', []))
        already_matched = {int(r.get('peak_rank')) for r in existing_results
                           if r.get('peak_rank') is not None}
        good_peaks = [p for p in self.peaks if p.get('status', 'Undefined') == 'Good']
        unassigned = [p for p in good_peaks if int(p.get('rank', -1)) not in already_matched]
        if not unassigned:
            messagebox.showinfo('Rescue', 'No unassigned Good peaks to rescue.')
            return

        shift_ppm = _align_peaks_to_reference(
            self.peaks,
            getattr(self.app, 'ppm', None),
            getattr(self.app, 'all_intensities', None))
        aligned_good = []
        for p in good_peaks:
            ap = dict(p)
            ap['ppm'] = p['ppm'] + shift_ppm
            ap['start_ppm'] = p.get('start_ppm', p['ppm']) + shift_ppm
            ap['end_ppm'] = p.get('end_ppm', p['ppm']) + shift_ppm
            aligned_good.append(ap)
        aligned_unassigned = [p for p in aligned_good if int(p.get('rank', -1)) in
                              {int(u.get('rank', -1)) for u in unassigned}]

        self._status(f'Rescue pass: scanning {len(aligned_unassigned)} unassigned peaks…')
        t0 = time.monotonic()
        conn = None
        rescued = []
        try:
            conn = sqlite3.connect(db_path)
            conn.row_factory = sqlite3.Row
            cur = conn.cursor()
            tables = {r[0] for r in cur.execute(
                "SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
            is_bmrb = 'shifts_1h' in tables
            is_hmdb = 'multiplets' in tables
            if not is_bmrb and not is_hmdb:
                messagebox.showerror('Incompatible DB', 'Database must contain shifts_1h or multiplets.')
                return

            _ppm_arr = getattr(self.app, 'ppm', None)
            _raw_int = getattr(self.app, 'all_intensities', None)
            _int_arr = np.mean(_raw_int, axis=1) if _ppm_arr is not None and _raw_int is not None else None

            for peak in aligned_unassigned:
                ppm = float(peak['ppm'])
                p_lo = min(float(peak.get('start_ppm', ppm - relax_tol)),
                           float(peak.get('end_ppm', ppm + relax_tol))) - 0.03
                p_hi = max(float(peak.get('start_ppm', ppm - relax_tol)),
                           float(peak.get('end_ppm', ppm + relax_tol))) + 0.03

                rows = []
                if is_bmrb:
                    cur.execute(
                        "SELECT s.bmrb_id as hmdb_id, met.name,"
                        " s.ppm as ppm_center, s.ppm as ppm,"
                        " s.atom_name, s.multiplicity as type,"
                        " s.j_coupling, s.multiplicity,"
                        " ? as peak_ppm, ? as peak_rank,"
                        " ABS(s.ppm - ?) as ppm_diff"
                        " FROM shifts_1h s"
                        " JOIN metabolites met ON s.bmrb_id = met.bmrb_id"
                        " WHERE s.ppm BETWEEN ? AND ?"
                        " ORDER BY ABS(s.ppm - ?) LIMIT 25",
                        (ppm, peak['rank'], ppm, p_lo, p_hi, ppm))
                    rows = [dict(r) for r in cur.fetchall()]
                    for r in rows:
                        r['match_type'] = 'shift'
                        r['database'] = 'BMRB'
                        r['shift_ppm'] = shift_ppm
                elif is_hmdb:
                    cur.execute("""
                        SELECT m.*, m.j_coupling, met.name,
                               ? as peak_ppm, ? as peak_rank,
                               ABS(m.ppm_center - ?) as ppm_diff
                        FROM multiplets m
                        JOIN metabolites met ON m.hmdb_id = met.hmdb_id
                        WHERE m.ppm_center BETWEEN ? AND ?
                        ORDER BY ABS(m.ppm_center - ?) LIMIT 25
                    """, (ppm, peak['rank'], ppm, p_lo, p_hi, ppm))
                    rows = [dict(r) for r in cur.fetchall()]
                    for r in rows:
                        r['match_type'] = 'multiplet'
                        r['database'] = 'HMDB'
                        r['shift_ppm'] = shift_ppm

                for r in rows:
                    ps = _ppm_score(r.get('peak_ppm', 0), r.get('ppm_center', r.get('ppm', 0)), relax_tol)
                    ms, md, pl = _multiplet_score(r, aligned_good, relax_tol, mhz,
                                                  ppm_array=_ppm_arr, intensity_array=_int_arr)
                    mult_type = (r.get('multiplicity') or r.get('type') or 's').lower().strip()
                    is_singlet = mult_type in ('s', 'singlet', '')
                    composite = ps if is_singlet else (0.4 * ps + 0.6 * ms)
                    compat, obs_mult = _mult_compat_check(r, aligned_good, relax_tol, mhz)
                    composite *= compat
                    r['observed_mult'] = obs_mult
                    r['mult_compat'] = round(compat, 3)
                    r['ppm_score'] = ps
                    r['multiplet_score'] = ms
                    r['composite_score'] = composite
                    r['multiplet_detail'] = md + (f'  |  obs={obs_mult} compat={compat:.2f}' if compat < 0.95 else '')
                    r['predicted_lines'] = pl
                    rescued.append(r)

            # Deduplicate per rescued peak and entry
            seen = {}
            for r in rescued:
                key = (int(r.get('peak_rank', -1)),
                       r.get('hmdb_id') or r.get('bmrb_id', ''),
                       round(float(r.get('ppm_center') or r.get('ppm') or 0), 3))
                if key not in seen or r.get('composite_score', 0) > seen[key].get('composite_score', 0):
                    seen[key] = r
            rescued = [r for r in seen.values() if r.get('ppm_diff', 0) <= delta_max]
            rescued.sort(key=lambda r: r.get('composite_score', 0), reverse=True)

            # Apply MCR on rescued ranks with >=2 candidates
            _by_rank = {}
            for r in rescued:
                _by_rank.setdefault(int(r.get('peak_rank', -1)), []).append(r)
            _ppm_full = getattr(self.app, 'ppm', None)
            _all_int = getattr(self.app, 'all_intensities', None)
            if _ppm_full is not None and _all_int is not None:
                from gui.utils.mcr_utils import mcr_annotation_region, simulate_lorentzian_profile
                from gui.widgets.annotation_results_window import _build_stick_positions
                for peak in aligned_unassigned:
                    rk = int(peak['rank'])
                    cands = _by_rank.get(rk, [])
                    if len(cands) < 2:
                        continue
                    mask = _adaptive_mcr_mask(_ppm_full, _all_int, peak, cands, field_mhz=mhz)
                    if np.sum(mask) < 4:
                        continue
                    ppm_reg = _ppm_full[mask]
                    X_reg = (_all_int[mask, :] if _all_int.ndim == 2 else _all_int[mask, np.newaxis])
                    db_profiles = []
                    for c in cands:
                        try:
                            dp_ppm = float(c.get('ppm_center') or c.get('ppm') or 0)
                            mult = (c.get('type') or c.get('multiplicity') or 's')
                            try:
                                nh = int(c.get('protons') or 1)
                            except Exception:
                                nh = 1
                            sticks = _build_stick_positions(dp_ppm, mult, nh, c.get('j_coupling'))
                            if not sticks:
                                sticks = [(dp_ppm, 1.0)]
                            prof = simulate_lorentzian_profile(sticks, ppm_reg)
                        except Exception:
                            prof = np.zeros(len(ppm_reg))
                        db_profiles.append(prof)
                    if not db_profiles:
                        continue
                    S, C, mcr_m, K, assignments = mcr_annotation_region(
                        X_reg, db_profiles, r2_threshold=self.mcr_r2_threshold)
                    orig_peak = next((p for p in self.peak_stage.peaks if int(p.get('rank', -1)) == rk), None)
                    if orig_peak is not None:
                        orig_peak['mcr_annotation'] = {
                            'S': S, 'C': C, 'metrics': mcr_m, 'K': K,
                            'assignments': assignments, 'ppm_region': ppm_reg,
                            'candidates': cands, 'r2_threshold': self.mcr_r2_threshold,
                        }

            if not rescued:
                self._status_ok('Rescue completed: no robust new assignments found.')
                messagebox.showinfo('Rescue', 'No robust rescued candidates found.')
                return

            combined = existing_results + rescued
            combined.sort(key=lambda r: r.get('composite_score', 0), reverse=True)
            elapsed = time.monotonic() - t0
            self._status_ok(f'Rescue completed: +{len(rescued)} candidate match(es) in {elapsed:.2f}s.')
            self._open_results_window(combined, None, len(good_peaks), db_path, elapsed)
        except Exception as e:
            self._status_err(f'Rescue failed: {e}')
            messagebox.showerror('Rescue Error', str(e))
        finally:
            if conn:
                conn.close()

    # ── Search ────────────────────────────────────────────────────────────────

    def search_internal_db(self):
        if not self.peaks:
            messagebox.showinfo('Info',
                'No peaks detected.\nRun Peak Detection first.')
            return

        # Warn if a previous search already produced results
        has_prev = bool(self._quality_marks) or bool(self._metabolites)
        if has_prev:
            ok = messagebox.askyesno(
                'Reset Previous Analysis?',
                'A previous annotation and quantification analysis already exists.\n\n'
                'Running a new search will discard all previous results,\n'
                'including Good/Bad marks and quantification assignments.\n\n'
                'Continue and reset?',
                icon='warning')
            if not ok:
                return
            # Clear all previous state
            self._quality_marks       = {}
            self._child_quality_marks = {}
            self._metabolites         = None
            self._last_results_args   = None
            self.annotations          = {}

        db_path = _pick_database(self.app.root)
        if not db_path:
            return

        # Share DB path with other stages
        self.app._last_db_path = db_path

        ext     = os.path.splitext(db_path)[1].lower()
        db_type = 'hmdb' if ext == '.db' else ('csv' if ext == '.csv' else None)
        if not db_type:
            messagebox.showerror('Error', 'Unsupported file type.')
            return

        self.internal_status.config(
            text=f'Selected: {os.path.basename(db_path)}',
            foreground='blue')

        tolerance = float(self.tolerance_var.get())
        try:
            mhz = float(self.spectrometer_var.get())
        except ValueError:
            mhz = 600.0
        try:
            delta_max = float(self.delta_max_var.get())
        except (ValueError, AttributeError):
            delta_max = 0.05

        # Compute alignment shift (always applied)
        shift_ppm = _align_peaks_to_reference(
            self.peaks,
            getattr(self.app, 'ppm', None),
            getattr(self.app, 'all_intensities', None))
        if abs(shift_ppm) > 0.0001:
            self._status(
                f'Alignment shift: {shift_ppm:+.4f} ppm', 'blue')

        good_peaks = [p for p in self.peaks
                      if p.get('status', 'Undefined') == 'Good']

        if not good_peaks:
            messagebox.showinfo(
                'No Good Peaks',
                'No peaks are marked as Good in the Peak List.\n\n'
                'Open the Peak List and mark peaks as Good (Ctrl+1) '
                'before running annotation.')
            return

        # Apply shift to Good peaks only (temporary copy)
        aligned_peaks = []
        for p in good_peaks:
            ap = dict(p)
            ap['ppm']       = p['ppm']       + shift_ppm
            ap['start_ppm'] = p.get('start_ppm', p['ppm']) + shift_ppm
            ap['end_ppm']   = p.get('end_ppm',   p['ppm']) + shift_ppm
            aligned_peaks.append(ap)

        # Progress window
        pw = tk.Toplevel(self.app.root)
        pw.title('Searching Database')
        pw.geometry('500x270')
        pw.transient(self.app.root)
        pw.grab_set()

        ttk.Label(pw, text=f'Database: {os.path.basename(db_path)}',
                  font=('Arial', 9)).pack(pady=5)
        ttk.Label(pw, text=f'Shift applied: {shift_ppm:+.4f} ppm',
                  font=('Arial', 8), foreground='gray').pack()
        self.progress_bar = ttk.Progressbar(
            pw, length=400, mode='determinate')
        self.progress_bar.pack(pady=8)

        cf = ttk.Frame(pw); cf.pack(pady=4)
        for row, (lbl, attr) in enumerate([
            ('Peaks processed:',    'progress_peaks_label'),
            ('Matches found:',      'progress_matches_label'),
            ('Peaks with matches:', 'progress_peaks_matched_label'),
        ]):
            ttk.Label(cf, text=lbl, font=('Arial', 9)).grid(
                row=row, column=0, padx=5)
            w = ttk.Label(cf, text='0', font=('Arial', 9, 'bold'))
            w.grid(row=row, column=1, padx=5)
            setattr(self, attr, w)

        self.progress_time_label = ttk.Label(
            pw, text='0.0 s', font=('Arial', 9, 'bold'))
        self.progress_time_label.pack()
        self.progress_op_label = ttk.Label(
            pw, text='Initializing…',
            font=('Arial', 8), foreground='blue')
        self.progress_op_label.pack(pady=4)
        pw.update()

        def search_task():
            t0 = time.monotonic()
            all_results, peaks_matched = [], set()
            processed   = 0
            total_peaks = len(aligned_peaks)
            self.progress_bar['maximum'] = total_peaks
            conn = None
            try:
                if db_type == 'hmdb':
                    conn = sqlite3.connect(db_path)
                    conn.row_factory = sqlite3.Row
                    cur   = conn.cursor()
                    tables = {r[0] for r in cur.execute(
                        "SELECT name FROM sqlite_master "
                        "WHERE type='table'").fetchall()}
                    is_bmrb = 'shifts_1h' in tables
                    is_hmdb = 'multiplets' in tables
                    if not is_bmrb and not is_hmdb:
                        self.app.root.after(0, lambda: messagebox.showerror(
                            'Incompatible DB',
                            'Database must contain shifts_1h or multiplets.'))
                        self.app.root.after(0, pw.destroy)
                        return

                    for peak in aligned_peaks:
                        ppm       = peak['ppm']
                        # Use the full peak region for DB search — captures
                        # overlapping metabolites whose DB ppm falls anywhere
                        # within [start_ppm, end_ppm], not just near the centre.
                        _margin   = 0.02  # small extra margin (ppm) at each edge
                        p_lo      = peak.get('start_ppm', ppm - tolerance) - _margin
                        p_hi      = peak.get('end_ppm',   ppm + tolerance) + _margin
                        # Ensure lo < hi (NMR axes may be inverted)
                        if p_lo > p_hi:
                            p_lo, p_hi = p_hi, p_lo

                        if is_bmrb:
                            cur.execute(
                                "SELECT s.bmrb_id as hmdb_id, met.name,"
                                " s.ppm as ppm_center, s.ppm as ppm,"
                                " s.atom_name, s.multiplicity as type,"
                                " s.j_coupling, s.multiplicity,"
                                " ? as peak_ppm, ? as peak_rank,"
                                " ABS(s.ppm - ?) as ppm_diff"
                                " FROM shifts_1h s"
                                " JOIN metabolites met ON s.bmrb_id = met.bmrb_id"
                                " WHERE s.ppm BETWEEN ? AND ?"
                                " ORDER BY ABS(s.ppm - ?) LIMIT 20",
                                (ppm, peak['rank'], ppm, p_lo, p_hi, ppm))
                            for row in cur.fetchall():
                                r = dict(row)
                                r['match_type'] = 'shift'
                                r['database']   = 'BMRB'
                                r['shift_ppm']  = shift_ppm
                                all_results.append(r)
                                peaks_matched.add(peak['rank'])

                        else:
                            # HMDB — query multiplets within the peak region
                            cur.execute("""
                                SELECT m.*, m.j_coupling, met.name,
                                       ? as peak_ppm, ? as peak_rank,
                                       ABS(m.ppm_center - ?) as ppm_diff
                                FROM multiplets m
                                JOIN metabolites met ON m.hmdb_id = met.hmdb_id
                                WHERE m.ppm_center BETWEEN ? AND ?
                                ORDER BY ABS(m.ppm_center - ?) LIMIT 20
                            """, (ppm, peak['rank'], ppm, p_lo, p_hi, ppm))
                            for row in cur.fetchall():
                                r = dict(row)
                                r['match_type'] = 'multiplet'
                                r['database']   = 'HMDB'
                                r['shift_ppm']  = shift_ppm
                                all_results.append(r)
                                peaks_matched.add(peak['rank'])

                        processed += 1
                        if processed % 5 == 0 or processed == total_peaks:
                            el = time.monotonic() - t0
                            self.app.root.after(
                                0,
                                lambda p=processed, t=total_peaks,
                                       m=len(all_results),
                                       pm=len(peaks_matched), e=el:
                                self._update_progress(p, t, m, pm, e))

                elif db_type == 'csv':
                    import pandas as pd
                    df = pd.read_csv(db_path)
                    for peak in aligned_peaks:
                        ppm  = peak['ppm']
                        mask = df['ppm'].sub(ppm).abs() <= tolerance
                        for _, row in df[mask].iterrows():
                            r = dict(row)
                            r.update({'peak_ppm':    ppm,
                                      'peak_rank':   peak['rank'],
                                      'ppm_center':  row.get('ppm', ppm),
                                      'ppm_diff':    abs(row.get('ppm', ppm) - ppm),
                                      'match_type':  'csv_match',
                                      'database':    'CSV',
                                      'shift_ppm':   shift_ppm})
                            all_results.append(r)
                            peaks_matched.add(peak['rank'])
                        processed += 1

                # ── Score all candidates ──────────────────────────────────────
                self.app.root.after(
                    0, lambda: self._status('Scoring multiplet patterns…'))

                # Prepare spectrum arrays for baseline-corrected height
                # computation inside _find_doublet_pair.
                _ppm_arr = getattr(self.app, 'ppm', None)
                _raw_int = getattr(self.app, 'all_intensities', None)
                if _ppm_arr is not None and _raw_int is not None:
                    try:
                        # all_intensities shape: (n_points, n_samples)
                        # axis=1 averages over samples → 1-D (n_points,) array
                        _int_arr = np.mean(_raw_int, axis=1)
                    except Exception:
                        _int_arr = None
                else:
                    _int_arr = None

                for r in all_results:
                    ps = _ppm_score(
                        r.get('peak_ppm', 0),
                        r.get('ppm_center', r.get('ppm', 0)),
                        tolerance)
                    ms, md, pl = _multiplet_score(
                        r, aligned_peaks, tolerance, mhz,
                        ppm_array=_ppm_arr, intensity_array=_int_arr)
                    # Composite: 40% position, 60% multiplet pattern
                    mult_type = (r.get('multiplicity') or
                                 r.get('type') or 's').lower().strip()
                    is_singlet = mult_type in ('s', 'singlet', '')
                    if is_singlet:
                        composite = ps
                    else:
                        composite = 0.4 * ps + 0.6 * ms

                    # ── Multiplicity compatibility penalty ────────────────────
                    # Classify what is actually observed near the DB PPM, then
                    # compare with what the DB expects.  A mismatch (e.g. DB
                    # says doublet but we see a singlet) multiplies the composite
                    # score by a penalty factor (0–1).  When observations are
                    # uncertain the factor stays near 1.0 to avoid false rejects.
                    compat, obs_mult = _mult_compat_check(
                        r, aligned_peaks, tolerance, mhz)
                    composite *= compat
                    r['observed_mult'] = obs_mult
                    r['mult_compat']   = round(compat, 3)

                    r['ppm_score']       = ps
                    r['multiplet_score'] = ms
                    r['composite_score'] = composite
                    r['multiplet_detail'] = (
                        md + f'  |  obs={obs_mult} compat={compat:.2f}'
                        if compat < 0.95 else md)
                    r['predicted_lines']  = pl

                # ── Correct ppm_diff to centre-to-centre ─────────────────
                # For multiplets: ppm_diff = |exp_centre - db_centre|
                # exp_centre comes from predicted_lines midpoint (scorer output)
                for r in all_results:
                    pl = r.get('predicted_lines', [])
                    if len(pl) >= 2:
                        exp_centre = sum(l['ppm'] for l in pl) / len(pl)
                        db_centre  = float(r.get('ppm_center') or
                                           r.get('ppm') or 0)
                        r['ppm_diff']  = abs(exp_centre - db_centre)
                        r['peak_ppm']  = exp_centre  # report centre, not line

                # ── Deduplicate: same DB entry × same analyte ─────────────
                # Keep only the best-scoring result per (hmdb_id, ppm_center)
                seen = {}
                for r in all_results:
                    key = (r.get('hmdb_id') or r.get('bmrb_id', ''),
                           round(float(r.get('ppm_center') or
                                       r.get('ppm') or 0), 3))
                    cs = r.get('composite_score', 0)
                    if key not in seen or cs > seen[key].get('composite_score', 0):
                        seen[key] = r
                all_results = list(seen.values())

                # ── Apply delta_max filter on corrected ppm_diff ──────────
                all_results = [r for r in all_results
                               if r.get('ppm_diff', 0) <= delta_max]

                # Sort by composite score descending
                all_results.sort(
                    key=lambda r: r.get('composite_score', 0),
                    reverse=True)

                # ── MCR-ALS deconvolution for multi-candidate regions ────
                try:
                    self.app.root.after(
                        0, lambda: self._status('Running MCR deconvolution…'))
                    _ppm_full = getattr(self.app, 'ppm', None)
                    _all_int  = getattr(self.app, 'all_intensities', None)
                    if _ppm_full is not None and _all_int is not None:
                        from gui.utils.mcr_utils import (
                            mcr_annotation_region, simulate_lorentzian_profile)
                        from gui.widgets.annotation_results_window import (
                            _build_stick_positions)
                        # Group results by peak_rank
                        _by_rank = {}
                        for r in all_results:
                            rk = r.get('peak_rank')
                            if rk is not None:
                                _by_rank.setdefault(rk, []).append(r)
                        # For each peak with ≥2 candidates, run MCR
                        for peak in aligned_peaks:
                            rk = peak['rank']
                            cands = _by_rank.get(rk, [])
                            if len(cands) < 2:
                                continue
                            try:
                                mask = _adaptive_mcr_mask(
                                    _ppm_full, _all_int, peak, cands, field_mhz=mhz)
                                if mask.sum() < 4:
                                    continue
                                ppm_reg = _ppm_full[mask]
                                X_reg   = (_all_int[mask, :]
                                           if _all_int.ndim == 2
                                           else _all_int[mask, np.newaxis])
                                # Build simulated profiles for each candidate
                                db_profiles = []
                                for c in cands:
                                    try:
                                        dp_ppm  = float(c.get('ppm_center') or
                                                        c.get('ppm') or 0)
                                        mult    = (c.get('type') or
                                                   c.get('multiplicity') or 's')
                                        try:
                                            nh = int(c.get('protons') or 1)
                                        except Exception:
                                            nh = 1
                                        sticks = _build_stick_positions(
                                            dp_ppm, mult, nh,
                                            c.get('j_coupling'))
                                        if not sticks:
                                            sticks = [(dp_ppm, 1.0)]
                                        prof = simulate_lorentzian_profile(
                                            sticks, ppm_reg)
                                    except Exception:
                                        prof = np.zeros(len(ppm_reg))
                                    db_profiles.append(prof)
                                S, C, mcr_m, K, assignments = mcr_annotation_region(
                                    X_reg, db_profiles,
                                    r2_threshold=self.mcr_r2_threshold)
                                # Store on the original (non-aligned) peak
                                orig_peak = next(
                                    (p for p in self.peak_stage.peaks
                                     if p['rank'] == rk), None)
                                if orig_peak is not None:
                                    orig_peak['mcr_annotation'] = {
                                        'S':           S,
                                        'C':           C,
                                        'metrics':     mcr_m,
                                        'K':           K,
                                        'assignments': assignments,
                                        'ppm_region':  ppm_reg,
                                        'candidates':  cands,
                                        'r2_threshold': self.mcr_r2_threshold,
                                    }
                            except Exception as _mcr_e:
                                print(f'MCR annotation error peak #{rk}: {_mcr_e}')
                except Exception as _mcr_outer:
                    print(f'MCR annotation outer error: {_mcr_outer}')
                    import traceback; traceback.print_exc()

                # ── Merge confirmed multiplets in peak list ───────────────
                try:
                    from gui.notation.multiplet_scorer import merge_multiplet_peaks
                    _new_peaks, _merge_log = merge_multiplet_peaks(
                        self.peak_stage.peaks,
                        all_results,
                        spectrometer_mhz=mhz)
                    if _merge_log:
                        self.peak_stage.peaks = _new_peaks
                        _desc = ', '.join(
                            f"{m['type'].upper()} "
                            f"J={m['J_obs_hz']:.1f}Hz"
                            for m in _merge_log)
                        print(f'   Merged {len(_merge_log)} multiplet(s): {_desc}')
                        self.app.root.after(
                            0, lambda n=len(_merge_log), d=_desc:
                            self._status_ok(
                                f'Merged {n} multiplet(s): {d}'))
                except Exception as _me:
                    print(f'merge error: {_me}')
                    import traceback; traceback.print_exc()

                elapsed = time.monotonic() - t0
                nm  = len(all_results)
                np_ = len(peaks_matched)
                self.app.root.after(
                    0, lambda: self._status_ok(
                        f'Search complete — {nm} matches '
                        f'for {np_}/{total_peaks} peaks  '
                        f'({elapsed:.2f}s)'))
                self.app.root.after(0, lambda: self._open_results_window(
                    all_results, pw, total_peaks, db_path, elapsed))

            except Exception as e:
                self.app.root.after(
                    0, lambda: self._status_err(f'Search failed: {e}'))
                self.app.root.after(
                    0, lambda: self._handle_search_error(pw, e))
                import traceback; traceback.print_exc()
            finally:
                if conn:
                    conn.close()

        threading.Thread(target=search_task, daemon=True).start()

    # ── MCR recompute ─────────────────────────────────────────────────────────

    def _rerun_mcr_for_peak(self, peak, r2_threshold):
        """Re-run MCR-ALS on a single peak with a new R² threshold."""
        mcr_ann = peak.get('mcr_annotation')
        if not mcr_ann:
            return
        try:
            from gui.utils.mcr_utils import (
                mcr_annotation_region, simulate_lorentzian_profile)
            ppm_reg  = mcr_ann['ppm_region']
            cands    = mcr_ann['candidates']
            _all_int = getattr(self.app, 'all_intensities', None)
            _ppm_full = getattr(self.app, 'ppm', None)
            if _ppm_full is None or _all_int is None:
                return
            # Recompute with adaptive bounds (not only old ppm_reg),
            # so MCR can re-fit full multiplet shape and tails.
            mask = _adaptive_mcr_mask(
                _ppm_full, _all_int, peak, cands, field_mhz=600.0)
            if mask.sum() < 4:
                return
            ppm_reg_new = _ppm_full[mask]
            X_reg = (_all_int[mask, :]
                     if _all_int.ndim == 2
                     else _all_int[mask, np.newaxis])
            from gui.widgets.annotation_results_window import _build_stick_positions
            db_profiles = []
            for c in cands:
                try:
                    dp_ppm = float(c.get('ppm_center') or c.get('ppm') or 0)
                    mult   = c.get('type') or c.get('multiplicity') or 's'
                    try:    nh = int(c.get('protons') or 1)
                    except: nh = 1
                    sticks = _build_stick_positions(dp_ppm, mult, nh,
                                                    c.get('j_coupling'))
                    if not sticks:
                        sticks = [(dp_ppm, 1.0)]
                    prof = simulate_lorentzian_profile(sticks, ppm_reg_new)
                except Exception:
                    prof = np.zeros(len(ppm_reg_new))
                db_profiles.append(prof)
            S, C, mcr_m, K, assignments = mcr_annotation_region(
                X_reg, db_profiles, r2_threshold=r2_threshold)
            peak['mcr_annotation'].update({
                'S': S, 'C': C, 'metrics': mcr_m, 'K': K,
                'assignments': assignments,
                'ppm_region': ppm_reg_new,
                'r2_threshold': r2_threshold,
            })
        except Exception as e:
            print(f'_rerun_mcr_for_peak error: {e}')

    # ── Progress update ───────────────────────────────────────────────────────

    def _update_progress(self, processed, total, matches, peaks_matched, elapsed):
        try:
            self.progress_bar['value'] = processed
            self.progress_peaks_label.config(
                text=f'{processed} / {total}')
            self.progress_matches_label.config(text=str(matches))
            self.progress_peaks_matched_label.config(
                text=str(peaks_matched))
            self.progress_time_label.config(
                text=f'{elapsed:.1f} s')
        except Exception:
            pass

    def _handle_search_error(self, pw, error):
        try:
            pw.destroy()
        except Exception:
            pass
        messagebox.showerror('Search Error', str(error))

    # ── Open results window ───────────────────────────────────────────────────

    def _open_results_window(self, results, pw, total_peaks,
                             db_path, elapsed):
        try:
            pw.destroy()
        except Exception:
            pass
        if not results:
            messagebox.showinfo('No Results',
                'No matches found.\n'
                'Try increasing the tolerance or checking the DB file.')
            return

        self._last_results_args = {
            'results':    results,
            'db_path':    db_path,
            'total_peaks': total_peaks,
            'elapsed':    elapsed,
        }

        # Enable the shortcut buttons in the toolbar
        try:
            self.app.btn_annot_shortcut.config(state='normal')
        except Exception:
            pass
        # Enable Deconvolution button (MCR results will be available)
        try:
            self.app.btn_deconv_shortcut.config(state='normal')
        except Exception:
            pass

        from gui.widgets.annotation_results_window import AnnotationResultsWindow
        _win = AnnotationResultsWindow(
            self.app.root,
            results,
            self.peak_stage.peaks,
            getattr(self.app, 'ppm', None),
            getattr(self.app, 'all_intensities', None),
            db_path=db_path,
            app=self.app)
        # Keep a live reference so ResolvingMethodWindow can access
        # the metabolites list with user-assigned quality marks.
        self._metabolites = _win.metabolites

    # ── Built-in library search ───────────────────────────────────────────────

    def search_builtin_library(self):
        """Search the built-in NMR metabolite library without a file picker."""
        if not self.peaks:
            messagebox.showinfo('Info',
                'No peaks detected.\nRun Peak Detection first.')
            return

        import pandas as pd

        _root = os.path.dirname(os.path.dirname(
            os.path.dirname(os.path.abspath(__file__))))
        lib_path = os.path.join(_root, 'data', 'nmr_metabolite_library.csv')
        if not os.path.isfile(lib_path):
            messagebox.showerror('Error',
                f'Built-in library not found:\n{lib_path}')
            return

        tolerance = float(self.tolerance_var.get())
        good_peaks = [p for p in self.peaks
                      if p.get('status', 'Undefined') == 'Good']
        if not good_peaks:
            messagebox.showinfo('No Good Peaks',
                'No peaks are marked as Good in the Peak List.\n\n'
                'Open the Peak List and mark peaks as Good (Ctrl+1) '
                'before running annotation.')
            return

        self.hmdb_status.config(text='Internal DB: searching…', foreground='blue')
        self.app.root.update()

        pw = tk.Toplevel(self.app.root)
        pw.title('Searching Internal Library')
        pw.geometry('420x120')
        pw.transient(self.app.root)
        pw.grab_set()
        ttk.Label(pw, text='Searching built-in NMR metabolite library…',
                  font=('Arial', 10)).pack(pady=10)
        pb = ttk.Progressbar(pw, length=360, mode='indeterminate')
        pb.pack(pady=10); pb.start(); pw.update()

        def _search():
            try:
                df = pd.read_csv(lib_path)
                all_results, peaks_matched = [], set()
                t0 = time.monotonic()
                for peak in good_peaks:
                    p_lo = min(peak.get('start_ppm', peak['ppm']),
                               peak.get('end_ppm',   peak['ppm'])) - tolerance
                    p_hi = max(peak.get('start_ppm', peak['ppm']),
                               peak.get('end_ppm',   peak['ppm'])) + tolerance
                    mask = (df['start_ppm'] <= p_hi) & (df['end_ppm'] >= p_lo)
                    for _, row in df[mask].iterrows():
                        mult = str(row.get('multiplicity', '') or '')
                        all_results.append({
                            'name':          row['name'],
                            'id':            str(int(row['id'])),
                            'ppm':           (row['start_ppm'] + row['end_ppm']) / 2.0,
                            'ppm_center':    (row['start_ppm'] + row['end_ppm']) / 2.0,
                            'start_ppm':     float(row['start_ppm']),
                            'end_ppm':       float(row['end_ppm']),
                            'multiplicity':  mult,
                            'match_type':    mult or 'internal_library',
                            'type':          mult or 'internal_library',
                            'database':      'Internal Library',
                            'source':        'Internal Library',
                            'protons':       1,
                            'peak_ppm':      peak['ppm'],
                            'peak_rank':     peak['rank'],
                            'composite_score': 0.0,
                            'multiplet_score': 0.0,
                        })
                        peaks_matched.add(peak['rank'])
                elapsed = time.monotonic() - t0
                n_m = len(all_results)
                n_p = len(peaks_matched)

                def _show():
                    self.hmdb_status.config(
                        text=f'Internal DB: {n_m} matches ({n_p}/{len(good_peaks)} peaks)',
                        foreground='green')
                    # _open_results_window sets _last_results_args (enables quantification)
                    # and opens AnnotationResultsWindow; pass None as db_path → no fingerprint DB
                    self._open_results_window(all_results, pw, len(good_peaks), None, elapsed)

                self.app.root.after(0, _show)
            except Exception as exc:
                self.app.root.after(0, pw.destroy)
                self.app.root.after(
                    0, lambda: messagebox.showerror('Error',
                        f'Library search failed:\n{exc}'))
                import traceback; traceback.print_exc()

        threading.Thread(target=_search, daemon=True).start()

    # ── Online search (BMRB) ──────────────────────────────────────────────────

    def search_hmdb_online(self):
        if not self.peaks:
            messagebox.showinfo('Info',
                'No peaks detected.\nRun Peak Detection first.')
            return
        messagebox.showinfo('BMRB Online',
            'Online search not implemented in this version.\n'
            'Use Search Internal DB with a BMRB .db file.')

    # ── Export helper (called from results window) ────────────────────────────

    def _export(self, results):
        import csv
        fn = filedialog.asksaveasfilename(
            title='Save Results',
            defaultextension='.csv',
            filetypes=[('CSV', '*.csv'), ('All', '*.*')],
            initialfile='annotation_results.csv')
        if not fn:
            return
        try:
            with open(fn, 'w', newline='', encoding='utf-8-sig') as f:
                w = csv.writer(f)
                w.writerow(['ID', 'Name', 'Match Type', 'DB PPM',
                            'Peak PPM', 'Peak Rank', 'PPM Score',
                            'Multiplet Score', 'Composite Score',
                            'Multiplet Detail'])
                for r in results:
                    w.writerow([
                        r.get('hmdb_id', r.get('bmrb_id', '')),
                        r.get('name', ''),
                        r.get('match_type', ''),
                        f"{r.get('ppm_center', r.get('ppm', 0)):.4f}",
                        f"{r.get('peak_ppm', 0):.4f}",
                        r.get('peak_rank', ''),
                        f"{r.get('ppm_score', 0):.3f}",
                        f"{r.get('multiplet_score', 0):.3f}",
                        f"{r.get('composite_score', 0):.3f}",
                        r.get('multiplet_detail', ''),
                    ])
            messagebox.showinfo('Export', f'Saved:\n{fn}')
        except Exception as e:
            messagebox.showerror('Export Error', str(e))