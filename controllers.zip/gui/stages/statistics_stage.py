# gui/stages/statistics_stage.py
"""
Statistics Stage — multivariate analysis and visualisation.

Left panel  : method selector + options
Right panel : plot canvas with save / export controls
"""
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import numpy as np

# ---------- helpers ----------------------------------------------------------

def _get_quantification_matrix(app):
    """
    Build a (n_samples, n_peaks) concentration matrix from the app state.
    Returns (X, sample_labels, feature_labels, group_labels).
    X rows = samples, columns = quantified peaks.
    """
    quant_stage = (getattr(app, 'stages', {}) or {}).get('quantification')
    ann_stage   = (getattr(app, 'stages', {}) or {}).get('annotation')

    # Try quantification results first
    quant_results = getattr(quant_stage, '_last_results', None)
    if quant_results:
        # quant_results is a list of dicts: {name, concentrations: {sample: val}, ...}
        sample_names = [s.get('name', f'S{i}') for i, s in
                        enumerate(getattr(app, 'samples_info', []))]
        feature_labels = []
        X_cols = []
        for met in quant_results:
            concs = met.get('concentrations') or met.get('conc', {})
            if not concs:
                continue
            col = [float(concs.get(s, 0.0) or 0.0) for s in sample_names]
            feature_labels.append(met.get('name', '?'))
            X_cols.append(col)
        if X_cols:
            X = np.array(X_cols, dtype=float).T  # (n_samples, n_features)
            si = getattr(app, 'samples_info', [])
            group_labels = [s.get('label', s.get('group', 'Unknown'))
                            for s in si]
            return X, sample_names, feature_labels, group_labels

    # Fallback: use annotation "Good" peaks as intensities at their ppm
    ppm_arr = getattr(app, 'ppm', None)
    all_int = getattr(app, 'all_intensities', None)
    ann_results = getattr(ann_stage, '_last_results', None)
    if ppm_arr is None or all_int is None or ann_results is None:
        return None, None, None, None

    si = getattr(app, 'samples_info', [])
    sample_names  = [s.get('name', f'S{i}') for i, s in enumerate(si)]
    group_labels  = [s.get('label', s.get('group', 'Unknown')) for s in si]

    from gui.widgets.annotation_results_window import AnnotationResultsWindow
    peaks = getattr(getattr(app.stages.get('peak_detection', None),
                            'peaks', None), '__iter__', lambda: [])()

    feature_labels = []
    X_cols = []
    # Use peak intensities for Good-annotated peaks
    det_stage = (getattr(app, 'stages', {}) or {}).get('peak_detection')
    for pk in (getattr(det_stage, 'peaks', None) or []):
        if pk.get('annotation_quality') == 'good':
            idx = int(np.argmin(np.abs(ppm_arr - pk['ppm'])))
            col = all_int[idx, :].tolist() if all_int.ndim == 2 else [float(all_int[idx])]
            name = pk.get('annotation', {}).get('name', f'{pk["ppm"]:.4f}ppm')
            feature_labels.append(name)
            X_cols.append(col)

    if not X_cols:
        return None, None, None, None

    X = np.array(X_cols, dtype=float).T
    return X, sample_names, feature_labels, group_labels


def _group_to_int(group_labels):
    """Convert group label strings to integer class array y."""
    unique = sorted(set(group_labels))
    mapping = {g: i for i, g in enumerate(unique)}
    return np.array([mapping[g] for g in group_labels], dtype=int), unique


# ---------- main class -------------------------------------------------------

class StatisticsStage:
    def __init__(self, parent, app):
        self.parent = parent
        self.app    = app
        self._fig   = None
        self._ax    = None
        self._canvas = None
        self._current_method = None
        self._last_plot_fig  = None   # for export
        self.create_widgets()

    # ── Layout ───────────────────────────────────────────────────────────────

    def create_widgets(self):
        self.frame = ttk.Frame(self.parent)

        # Top toolbar
        tb = ttk.Frame(self.frame)
        tb.pack(fill=tk.X, padx=6, pady=(6, 2))
        ttk.Label(tb, text='Statistics', font=('Arial', 12, 'bold')).pack(side=tk.LEFT)
        ttk.Button(tb, text='Run', command=self._run).pack(side=tk.RIGHT, padx=4)
        ttk.Button(tb, text='Export…', command=self._export).pack(side=tk.RIGHT, padx=2)

        # Main paned: left options | right plot
        paned = ttk.PanedWindow(self.frame, orient=tk.HORIZONTAL)
        paned.pack(fill=tk.BOTH, expand=True, padx=4, pady=4)

        # ── Left panel ────────────────────────────────────────────────────────
        left = ttk.Frame(paned, padding=4)
        paned.add(left, weight=1)
        self._build_left(left)

        # ── Right panel ───────────────────────────────────────────────────────
        right = ttk.Frame(paned, padding=4)
        paned.add(right, weight=4)
        self._build_right(right)

    def _build_left(self, parent):
        ttk.Label(parent, text='Method', font=('Arial', 9, 'bold')).pack(anchor=tk.W)

        self._method_var = tk.StringVar(value='PCA')
        methods = ['PCA', 'PLS-DA', 'OPLS-DA', 'Heatmap',
                   'VIP Score', 'Volcano']
        for m in methods:
            ttk.Radiobutton(parent, text=m, variable=self._method_var,
                            value=m, command=self._on_method_change
                            ).pack(anchor=tk.W, pady=1)

        ttk.Separator(parent, orient=tk.HORIZONTAL).pack(fill=tk.X, pady=6)

        # Options frame — rebuilt per method
        self._opt_frame = ttk.LabelFrame(parent, text='Options', padding=4)
        self._opt_frame.pack(fill=tk.X)
        self._build_options('PCA')

        ttk.Separator(parent, orient=tk.HORIZONTAL).pack(fill=tk.X, pady=6)

        # Scaling
        ttk.Label(parent, text='Scaling', font=('Arial', 8, 'bold')).pack(anchor=tk.W)
        self._scale_var = tk.StringVar(value='UV')
        for lbl, val in [('None', 'none'), ('UV (unit var.)', 'UV'),
                         ('Pareto', 'pareto'), ('Log', 'log')]:
            ttk.Radiobutton(parent, text=lbl, variable=self._scale_var,
                            value=val).pack(anchor=tk.W, pady=1)

    def _on_method_change(self):
        self._build_options(self._method_var.get())

    def _build_options(self, method):
        for w in self._opt_frame.winfo_children():
            w.destroy()

        if method in ('PCA',):
            ttk.Label(self._opt_frame, text='Components:',
                      font=('Arial', 8)).grid(row=0, column=0, sticky=tk.W)
            self._n_comp_var = tk.IntVar(value=2)
            ttk.Spinbox(self._opt_frame, from_=2, to=10,
                        textvariable=self._n_comp_var, width=4
                        ).grid(row=0, column=1, sticky=tk.W, padx=4)
            self._biplot_var = tk.BooleanVar(value=False)
            ttk.Checkbutton(self._opt_frame, text='Show loadings (biplot)',
                            variable=self._biplot_var
                            ).grid(row=1, column=0, columnspan=2, sticky=tk.W)
            self._ellipse_var = tk.BooleanVar(value=True)
            ttk.Checkbutton(self._opt_frame, text='95% confidence ellipses',
                            variable=self._ellipse_var
                            ).grid(row=2, column=0, columnspan=2, sticky=tk.W)

        elif method in ('PLS-DA', 'OPLS-DA'):
            ttk.Label(self._opt_frame, text='Components:',
                      font=('Arial', 8)).grid(row=0, column=0, sticky=tk.W)
            self._n_comp_var = tk.IntVar(value=2)
            ttk.Spinbox(self._opt_frame, from_=1, to=10,
                        textvariable=self._n_comp_var, width=4
                        ).grid(row=0, column=1, sticky=tk.W, padx=4)
            self._cv_var = tk.BooleanVar(value=True)
            ttk.Checkbutton(self._opt_frame, text='Show CV R²/Q²',
                            variable=self._cv_var
                            ).grid(row=1, column=0, columnspan=2, sticky=tk.W)
            self._ellipse_var = tk.BooleanVar(value=True)
            ttk.Checkbutton(self._opt_frame, text='95% confidence ellipses',
                            variable=self._ellipse_var
                            ).grid(row=2, column=0, columnspan=2, sticky=tk.W)
            ttk.Label(self._opt_frame, text='Permutations:',
                      font=('Arial', 8)).grid(row=3, column=0, sticky=tk.W)
            self._n_perm_var = tk.IntVar(value=200)
            ttk.Spinbox(self._opt_frame, from_=0, to=2000, increment=100,
                        textvariable=self._n_perm_var, width=6
                        ).grid(row=3, column=1, sticky=tk.W, padx=4)

        elif method == 'Heatmap':
            ttk.Label(self._opt_frame, text='Clustering:',
                      font=('Arial', 8)).grid(row=0, column=0, sticky=tk.W)
            self._clust_var = tk.StringVar(value='ward')
            ttk.Combobox(self._opt_frame, textvariable=self._clust_var,
                         values=['ward', 'complete', 'average', 'single'],
                         width=10, state='readonly'
                         ).grid(row=0, column=1, sticky=tk.W, padx=4)
            ttk.Label(self._opt_frame, text='Color map:',
                      font=('Arial', 8)).grid(row=1, column=0, sticky=tk.W)
            self._cmap_var = tk.StringVar(value='RdYlBu_r')
            ttk.Combobox(self._opt_frame, textvariable=self._cmap_var,
                         values=['RdYlBu_r', 'seismic', 'coolwarm', 'viridis',
                                 'plasma', 'RdBu_r'],
                         width=10, state='readonly'
                         ).grid(row=1, column=1, sticky=tk.W, padx=4)

        elif method == 'VIP Score':
            ttk.Label(self._opt_frame, text='Top N features:',
                      font=('Arial', 8)).grid(row=0, column=0, sticky=tk.W)
            self._top_n_var = tk.IntVar(value=20)
            ttk.Spinbox(self._opt_frame, from_=5, to=100, increment=5,
                        textvariable=self._top_n_var, width=5
                        ).grid(row=0, column=1, sticky=tk.W, padx=4)
            ttk.Label(self._opt_frame, text='VIP threshold:',
                      font=('Arial', 8)).grid(row=1, column=0, sticky=tk.W)
            self._vip_thr_var = tk.DoubleVar(value=1.0)
            ttk.Spinbox(self._opt_frame, from_=0.5, to=3.0, increment=0.1,
                        textvariable=self._vip_thr_var, width=5, format='%.1f'
                        ).grid(row=1, column=1, sticky=tk.W, padx=4)

        elif method == 'Volcano':
            ttk.Label(self._opt_frame, text='Group A:',
                      font=('Arial', 8)).grid(row=0, column=0, sticky=tk.W)
            self._grp_a_var = tk.StringVar()
            self._cb_a = ttk.Combobox(self._opt_frame, textvariable=self._grp_a_var,
                                       width=12, state='readonly')
            self._cb_a.grid(row=0, column=1, sticky=tk.W, padx=4)
            ttk.Label(self._opt_frame, text='Group B:',
                      font=('Arial', 8)).grid(row=1, column=0, sticky=tk.W)
            self._grp_b_var = tk.StringVar()
            self._cb_b = ttk.Combobox(self._opt_frame, textvariable=self._grp_b_var,
                                       width=12, state='readonly')
            self._cb_b.grid(row=1, column=1, sticky=tk.W, padx=4)
            ttk.Label(self._opt_frame, text='FC threshold:',
                      font=('Arial', 8)).grid(row=2, column=0, sticky=tk.W)
            self._fc_thr_var = tk.DoubleVar(value=1.5)
            ttk.Spinbox(self._opt_frame, from_=1.0, to=10.0, increment=0.5,
                        textvariable=self._fc_thr_var, width=5, format='%.1f'
                        ).grid(row=2, column=1, sticky=tk.W, padx=4)
            ttk.Label(self._opt_frame, text='p-value thr:',
                      font=('Arial', 8)).grid(row=3, column=0, sticky=tk.W)
            self._p_thr_var = tk.DoubleVar(value=0.05)
            ttk.Spinbox(self._opt_frame, from_=0.001, to=0.20, increment=0.01,
                        textvariable=self._p_thr_var, width=5, format='%.3f'
                        ).grid(row=3, column=1, sticky=tk.W, padx=4)
            self._p_adj_var = tk.BooleanVar(value=True)
            ttk.Checkbutton(self._opt_frame, text='FDR correction (BH)',
                            variable=self._p_adj_var
                            ).grid(row=4, column=0, columnspan=2, sticky=tk.W)
            # Populate group comboboxes
            self._refresh_groups()

    def _refresh_groups(self):
        si = getattr(self.app, 'samples_info', [])
        groups = sorted(set(s.get('label', s.get('group', 'Unknown')) for s in si))
        for cb in (getattr(self, '_cb_a', None), getattr(self, '_cb_b', None)):
            if cb is not None:
                cb['values'] = groups
        if groups:
            if hasattr(self, '_grp_a_var') and not self._grp_a_var.get():
                self._grp_a_var.set(groups[0])
            if hasattr(self, '_grp_b_var') and not self._grp_b_var.get():
                self._grp_b_var.set(groups[-1] if len(groups) > 1 else groups[0])

    def _build_right(self, parent):
        import matplotlib.pyplot as plt
        from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
        from matplotlib.figure import Figure

        # Export bar at the bottom
        eb = ttk.Frame(parent)
        eb.pack(side=tk.BOTTOM, fill=tk.X, pady=(4, 0))
        ttk.Label(eb, text='DPI:', font=('Arial', 8)).pack(side=tk.LEFT, padx=(4, 2))
        self._dpi_var = tk.IntVar(value=150)
        ttk.Spinbox(eb, from_=72, to=600, increment=25,
                    textvariable=self._dpi_var, width=5
                    ).pack(side=tk.LEFT, padx=(0, 8))
        ttk.Label(eb, text='Format:', font=('Arial', 8)).pack(side=tk.LEFT, padx=(0, 2))
        self._fmt_var = tk.StringVar(value='PNG')
        ttk.Combobox(eb, textvariable=self._fmt_var,
                     values=['PNG', 'SVG', 'PDF', 'TIFF', 'EPS'],
                     width=6, state='readonly').pack(side=tk.LEFT, padx=(0, 8))
        ttk.Button(eb, text='💾 Save figure', command=self._export
                   ).pack(side=tk.LEFT, padx=4)

        # Plot canvas
        self._fig = Figure(figsize=(8, 5), dpi=100, layout='constrained')
        self._ax  = self._fig.add_subplot(111)
        self._ax.text(0.5, 0.5, 'Select a method and click Run',
                      transform=self._ax.transAxes,
                      ha='center', va='center', color='#888888', fontsize=12)
        self._ax.set_axis_off()

        self._canvas = FigureCanvasTkAgg(self._fig, master=parent)
        self._canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
        self._toolbar = NavigationToolbar2Tk(self._canvas, parent, pack_toolbar=False)
        self._toolbar.update()
        self._toolbar.pack(side=tk.BOTTOM, fill=tk.X)

    # ── Lifecycle ────────────────────────────────────────────────────────────

    def on_activate(self):
        self.frame.pack(fill=tk.BOTH, expand=True)
        self._refresh_groups()

    def on_deactivate(self):
        self.frame.pack_forget()

    # ── Run ──────────────────────────────────────────────────────────────────

    def _run(self):
        method = self._method_var.get()
        X, sample_names, feature_labels, group_labels = _get_quantification_matrix(self.app)
        if X is None or X.shape[0] < 2 or X.shape[1] < 2:
            messagebox.showwarning(
                'No data',
                'Not enough data.\n'
                'Run Annotation (mark peaks as Good) or Quantification first.',
                parent=self.frame)
            return

        X_scaled = self._scale(X)

        self._fig.clear()
        try:
            if method == 'PCA':
                self._plot_pca(X_scaled, sample_names, feature_labels, group_labels)
            elif method == 'PLS-DA':
                self._plot_plsda(X_scaled, sample_names, feature_labels, group_labels, opls=False)
            elif method == 'OPLS-DA':
                self._plot_plsda(X_scaled, sample_names, feature_labels, group_labels, opls=True)
            elif method == 'Heatmap':
                self._plot_heatmap(X_scaled, sample_names, feature_labels, group_labels)
            elif method == 'VIP Score':
                self._plot_vip(X_scaled, sample_names, feature_labels, group_labels)
            elif method == 'Volcano':
                self._plot_volcano(X, sample_names, feature_labels, group_labels)
        except Exception as e:
            import traceback; traceback.print_exc()
            ax = self._fig.add_subplot(111)
            ax.text(0.5, 0.5, f'Error:\n{e}',
                    transform=ax.transAxes, ha='center', va='center',
                    color='red', fontsize=9, wrap=True)
            ax.set_axis_off()

        self._canvas.draw_idle()

    # ── Scaling ───────────────────────────────────────────────────────────────

    def _scale(self, X):
        mode = getattr(self, '_scale_var', None)
        mode = mode.get() if mode else 'UV'
        Xs = X.copy().astype(float)
        # Replace zeros/negatives with small positive for log
        if mode == 'log':
            Xs = np.log1p(np.clip(Xs, 0, None))
            mode = 'UV'   # then UV scale the log-transformed data
        # Mean-centre always
        Xs -= Xs.mean(axis=0)
        if mode == 'UV':
            std = Xs.std(axis=0)
            std[std == 0] = 1.0
            Xs /= std
        elif mode == 'pareto':
            std = Xs.std(axis=0)
            std[std == 0] = 1.0
            Xs /= np.sqrt(std)
        return Xs

    # ── Plot methods ─────────────────────────────────────────────────────────

    def _group_colors(self, unique_groups):
        """Return color dict for groups using app colors or a tab10 fallback."""
        import matplotlib.cm as cm
        app_gc = getattr(self.app, 'group_colors', {})
        cmap   = cm.get_cmap('tab10', max(len(unique_groups), 1))
        return {g: app_gc.get(g, cmap(i)) for i, g in enumerate(unique_groups)}

    def _confidence_ellipse(self, ax, x, y, color, n_std=2.0, **kw):
        """Draw a confidence ellipse for 2-D data (x, y)."""
        if len(x) < 3:
            return
        from matplotlib.patches import Ellipse
        import matplotlib.transforms as transforms
        cov = np.cov(x, y)
        vals, vecs = np.linalg.eigh(cov)
        order = vals.argsort()[::-1]
        vals, vecs = vals[order], vecs[:, order]
        theta = np.degrees(np.arctan2(*vecs[:, 0][::-1]))
        w, h  = 2 * n_std * np.sqrt(np.abs(vals))
        ell   = Ellipse(xy=(np.mean(x), np.mean(y)), width=w, height=h,
                        angle=theta, facecolor=color, alpha=0.12,
                        edgecolor=color, linewidth=1.2, **kw)
        ax.add_patch(ell)

    def _plot_pca(self, X, sample_names, feature_labels, group_labels):
        from sklearn.decomposition import PCA
        n_comp = getattr(self, '_n_comp_var', None)
        n_comp = n_comp.get() if n_comp else 2
        n_comp = min(n_comp, X.shape[0], X.shape[1])

        pca    = PCA(n_components=n_comp)
        scores = pca.fit_transform(X)
        ev     = pca.explained_variance_ratio_ * 100

        y, unique = _group_to_int(group_labels)
        gcols = self._group_colors(unique)

        biplot  = getattr(self, '_biplot_var',  None)
        biplot  = biplot.get()  if biplot  else False
        ellipse = getattr(self, '_ellipse_var', None)
        ellipse = ellipse.get() if ellipse else True

        if n_comp >= 3:
            # 2×2 grid: PC1v2, PC1v3, PC2v3, scree
            axes = [self._fig.add_subplot(2, 2, i+1) for i in range(4)]
            pairs = [(0, 1), (0, 2), (1, 2)]
            for idx, (a, b) in enumerate(pairs):
                ax = axes[idx]
                for gi, grp in enumerate(unique):
                    mask = y == gi
                    ax.scatter(scores[mask, a], scores[mask, b],
                               color=gcols[grp], label=grp, s=55, alpha=0.85,
                               edgecolors='white', linewidths=0.5)
                    if ellipse and mask.sum() >= 3:
                        self._confidence_ellipse(ax, scores[mask, a],
                                                 scores[mask, b], gcols[grp])
                ax.set_xlabel(f'PC{a+1} ({ev[a]:.1f}%)', fontsize=8)
                ax.set_ylabel(f'PC{b+1} ({ev[b]:.1f}%)', fontsize=8)
                ax.axhline(0, color='#cccccc', lw=0.5); ax.axvline(0, color='#cccccc', lw=0.5)
                ax.set_facecolor('#f9f9f9')
                if idx == 0:
                    ax.legend(fontsize=7, loc='best')
            # Scree plot
            ax4 = axes[3]
            ax4.bar(range(1, n_comp+1), ev, color='#1565c0', alpha=0.7)
            ax4.set_xlabel('Component', fontsize=8)
            ax4.set_ylabel('Explained variance (%)', fontsize=8)
            ax4.set_title('Scree', fontsize=8)
        else:
            ax = self._fig.add_subplot(111)
            for gi, grp in enumerate(unique):
                mask = y == gi
                ax.scatter(scores[mask, 0], scores[mask, 1],
                           color=gcols[grp], label=grp, s=60, alpha=0.88,
                           edgecolors='white', linewidths=0.5)
                if ellipse and mask.sum() >= 3:
                    self._confidence_ellipse(ax, scores[mask, 0],
                                             scores[mask, 1], gcols[grp])
            if biplot:
                loadings = pca.components_.T
                scale = np.max(np.abs(scores[:, :2])) / np.max(np.abs(loadings[:, :2]) + 1e-9)
                for i, feat in enumerate(feature_labels):
                    ax.annotate('', xy=(loadings[i,0]*scale, loadings[i,1]*scale),
                                xytext=(0, 0),
                                arrowprops=dict(arrowstyle='->', color='#c62828', lw=0.8))
                    ax.text(loadings[i,0]*scale*1.05, loadings[i,1]*scale*1.05,
                            feat, fontsize=5, color='#c62828', ha='center')
            for i, name in enumerate(sample_names):
                ax.annotate(name, (scores[i,0], scores[i,1]),
                            fontsize=5.5, ha='center', va='bottom',
                            xytext=(0, 4), textcoords='offset points', color='#444')
            ax.set_xlabel(f'PC1 ({ev[0]:.1f}%)', fontsize=9)
            ax.set_ylabel(f'PC2 ({ev[1]:.1f}%)', fontsize=9)
            ax.set_title(f'PCA Score Plot  —  {X.shape[1]} features', fontsize=10)
            ax.axhline(0, color='#cccccc', lw=0.6); ax.axvline(0, color='#cccccc', lw=0.6)
            ax.legend(fontsize=8, loc='best', framealpha=0.85)
            ax.set_facecolor('#f9f9f9')

    def _plot_plsda(self, X, sample_names, feature_labels, group_labels, opls=False):
        from sklearn.cross_decomposition import PLSRegression
        from sklearn.preprocessing import label_binarize
        from sklearn.model_selection import cross_val_score

        y_int, unique = _group_to_int(group_labels)
        n_classes = len(unique)
        if n_classes < 2:
            raise ValueError('Need at least 2 groups for PLS-DA.')
        # Binarize Y
        if n_classes == 2:
            Y = y_int.reshape(-1, 1).astype(float)
        else:
            Y = label_binarize(y_int, classes=list(range(n_classes))).astype(float)

        n_comp = getattr(self, '_n_comp_var', None)
        n_comp = n_comp.get() if n_comp else 2
        n_comp = min(n_comp, X.shape[0]-1, X.shape[1])

        pls = PLSRegression(n_components=n_comp, scale=False)
        pls.fit(X, Y)
        scores = pls.transform(X)
        if scores.ndim == 1:
            scores = scores.reshape(-1, 1)

        ev_x = [np.var(scores[:, k]) / np.var(X) * 100 for k in range(min(2, scores.shape[1]))]
        gcols   = self._group_colors(unique)
        ellipse = getattr(self, '_ellipse_var', None)
        ellipse = ellipse.get() if ellipse else True

        if opls:
            # OPLS-DA approximation: orthogonal correction
            # Regress out the variance orthogonal to Y from T[:,0]
            t1 = scores[:, 0]
            t_orth = scores[:, 1] if scores.shape[1] > 1 else np.zeros_like(t1)
            proj = np.dot(t_orth, t1) / (np.dot(t1, t1) + 1e-12)
            t_orth_corr = t_orth - proj * t1
            plot_x, plot_y = t1, t_orth_corr
            xlabel, ylabel = 'T score (predictive)', 'T orthogonal'
            title = 'OPLS-DA Score Plot'
        else:
            plot_x = scores[:, 0]
            plot_y = scores[:, 1] if scores.shape[1] > 1 else np.zeros_like(plot_x)
            xlabel = f'LV1 ({ev_x[0]:.1f}% X var.)'
            ylabel = f'LV2 ({ev_x[1]:.1f}% X var.)' if len(ev_x) > 1 else 'LV2'
            title  = 'PLS-DA Score Plot'

        ax = self._fig.add_subplot(111)
        for gi, grp in enumerate(unique):
            mask = y_int == gi
            ax.scatter(plot_x[mask], plot_y[mask],
                       color=gcols[grp], label=grp, s=60, alpha=0.88,
                       edgecolors='white', linewidths=0.5)
            if ellipse and mask.sum() >= 3:
                self._confidence_ellipse(ax, plot_x[mask], plot_y[mask], gcols[grp])
        for i, name in enumerate(sample_names):
            ax.annotate(name, (plot_x[i], plot_y[i]),
                        fontsize=5.5, ha='center', va='bottom',
                        xytext=(0, 4), textcoords='offset points', color='#444')

        cv = getattr(self, '_cv_var', None)
        if cv and cv.get():
            try:
                from sklearn.model_selection import StratifiedKFold
                cv_scores = cross_val_score(
                    PLSRegression(n_components=n_comp, scale=False),
                    X, y_int.astype(float),
                    cv=StratifiedKFold(n_splits=min(5, X.shape[0])),
                    scoring='r2')
                r2cv = cv_scores.mean()
                ax.set_title(f'{title}  —  CV R²={r2cv:.3f}', fontsize=10)
            except Exception:
                ax.set_title(title, fontsize=10)
        else:
            ax.set_title(title, fontsize=10)

        # Permutation test
        n_perm = getattr(self, '_n_perm_var', None)
        n_perm = n_perm.get() if n_perm else 0
        if n_perm > 0:
            try:
                from sklearn.model_selection import permutation_test_score
                _, _, pval = permutation_test_score(
                    PLSRegression(n_components=n_comp, scale=False),
                    X, y_int.astype(float),
                    n_permutations=n_perm, scoring='r2',
                    cv=min(5, X.shape[0]), n_jobs=1)
                ax.text(0.02, 0.02, f'Permutation p={pval:.3f}',
                        transform=ax.transAxes, fontsize=7.5,
                        color='#555', va='bottom')
            except Exception:
                pass

        ax.set_xlabel(xlabel, fontsize=9)
        ax.set_ylabel(ylabel, fontsize=9)
        ax.axhline(0, color='#cccccc', lw=0.6); ax.axvline(0, color='#cccccc', lw=0.6)
        ax.legend(fontsize=8, loc='best', framealpha=0.85)
        ax.set_facecolor('#f9f9f9')

    def _plot_heatmap(self, X, sample_names, feature_labels, group_labels):
        from scipy.cluster.hierarchy import linkage, dendrogram
        import matplotlib.patches as mpatches

        clust = getattr(self, '_clust_var', None)
        clust = clust.get() if clust else 'ward'
        cmap  = getattr(self, '_cmap_var',  None)
        cmap  = cmap.get()  if cmap  else 'RdYlBu_r'

        # Limit features for legibility
        MAX_FEAT = 60
        if X.shape[1] > MAX_FEAT:
            var_order = np.argsort(X.var(axis=0))[::-1][:MAX_FEAT]
            X_h  = X[:, var_order]
            flbl = [feature_labels[i] for i in var_order]
        else:
            X_h  = X
            flbl = feature_labels

        # Cluster rows (samples) and cols (features)
        row_link = linkage(X_h,   method=clust, metric='euclidean')
        col_link = linkage(X_h.T, method=clust, metric='euclidean')
        row_ord  = dendrogram(row_link, no_plot=True)['leaves']
        col_ord  = dendrogram(col_link, no_plot=True)['leaves']
        X_ord    = X_h[np.ix_(row_ord, col_ord)]
        slbl_ord = [sample_names[i]  for i in row_ord]
        flbl_ord = [flbl[i]          for i in col_ord]
        glbl_ord = [group_labels[i]  for i in row_ord]

        gs   = self._fig.add_gridspec(1, 2, width_ratios=[1, 12], wspace=0.02)
        ax_g = self._fig.add_subplot(gs[0])
        ax_h = self._fig.add_subplot(gs[1])

        y_int, unique = _group_to_int(glbl_ord)
        gcols = self._group_colors(unique)
        import matplotlib.colors as mcolors
        group_arr = np.array([[mcolors.to_rgba(gcols[g])[:3] for g in glbl_ord]])
        ax_g.imshow(np.array([[mcolors.to_rgba(gcols[g])[:3]] for g in glbl_ord]),
                    aspect='auto', interpolation='nearest')
        ax_g.set_xticks([]); ax_g.set_yticks(range(len(slbl_ord)))
        ax_g.set_yticklabels(slbl_ord, fontsize=7)

        im = ax_h.imshow(X_ord, aspect='auto', cmap=cmap,
                         interpolation='nearest',
                         vmin=np.percentile(X_ord, 2),
                         vmax=np.percentile(X_ord, 98))
        ax_h.set_xticks(range(len(flbl_ord)))
        ax_h.set_xticklabels(flbl_ord, rotation=90, fontsize=6)
        ax_h.set_yticks([])
        self._fig.colorbar(im, ax=ax_h, fraction=0.02, pad=0.01,
                           label='Scaled intensity')
        self._fig.suptitle('Heatmap (hierarchical clustering)', fontsize=10)

        patches = [mpatches.Patch(color=gcols[g], label=g) for g in unique]
        ax_h.legend(handles=patches, fontsize=7, loc='upper right',
                    bbox_to_anchor=(1.18, 1), framealpha=0.85)

    def _vip_scores(self, X, Y, n_comp):
        """Compute VIP scores from a PLSRegression model."""
        from sklearn.cross_decomposition import PLSRegression
        pls = PLSRegression(n_components=n_comp, scale=False)
        pls.fit(X, Y)
        T = pls.x_scores_
        W = pls.x_weights_
        Q = pls.y_loadings_
        p, h = W.shape
        vips = np.zeros(p)
        s    = np.diag(T.T @ T @ Q.T @ Q)
        s_total = np.sum(s)
        for i in range(p):
            weight = np.array([(W[i, j] / np.linalg.norm(W[:, j]))**2 * s[j]
                               for j in range(h)])
            vips[i] = np.sqrt(p * weight.sum() / s_total)
        return vips

    def _plot_vip(self, X, sample_names, feature_labels, group_labels):
        y_int, unique = _group_to_int(group_labels)
        if len(unique) < 2:
            raise ValueError('Need at least 2 groups for VIP.')
        from sklearn.preprocessing import label_binarize
        if len(unique) == 2:
            Y = y_int.reshape(-1, 1).astype(float)
        else:
            Y = label_binarize(y_int, classes=list(range(len(unique)))).astype(float)

        n_comp = getattr(self, '_n_comp_var', None)
        n_comp = n_comp.get() if n_comp else 2
        n_comp = min(n_comp, X.shape[0]-1, X.shape[1])
        top_n  = getattr(self, '_top_n_var',  None)
        top_n  = top_n.get()  if top_n  else 20
        vip_thr = getattr(self, '_vip_thr_var', None)
        vip_thr = vip_thr.get() if vip_thr else 1.0

        vips = self._vip_scores(X, Y, n_comp)
        order = np.argsort(vips)[::-1][:top_n]
        vips_top  = vips[order]
        feats_top = [feature_labels[i] for i in order]

        ax = self._fig.add_subplot(111)
        colors = ['#c62828' if v >= vip_thr else '#1565c0' for v in vips_top]
        ax.barh(range(len(feats_top)), vips_top[::-1], color=colors[::-1],
                edgecolor='white', linewidth=0.5)
        ax.set_yticks(range(len(feats_top)))
        ax.set_yticklabels(feats_top[::-1], fontsize=7)
        ax.axvline(vip_thr, color='#c62828', lw=1.0, ls='--',
                   label=f'VIP = {vip_thr:.1f}')
        ax.set_xlabel('VIP Score', fontsize=9)
        ax.set_title(f'VIP Scores (PLS-DA, top {top_n})', fontsize=10)
        ax.legend(fontsize=8)
        ax.set_facecolor('#f9f9f9')

    def _plot_volcano(self, X_raw, sample_names, feature_labels, group_labels):
        from scipy import stats
        ga = getattr(self, '_grp_a_var', None)
        gb = getattr(self, '_grp_b_var', None)
        ga = ga.get() if ga else ''
        gb = gb.get() if gb else ''
        if not ga or not gb or ga == gb:
            raise ValueError('Select two different groups for Volcano plot.')

        fc_thr = getattr(self, '_fc_thr_var', None)
        fc_thr = fc_thr.get() if fc_thr else 1.5
        p_thr  = getattr(self, '_p_thr_var', None)
        p_thr  = p_thr.get() if p_thr else 0.05
        p_adj  = getattr(self, '_p_adj_var', None)
        p_adj  = p_adj.get() if p_adj else True

        idx_a = [i for i, g in enumerate(group_labels) if g == ga]
        idx_b = [i for i, g in enumerate(group_labels) if g == gb]
        if not idx_a or not idx_b:
            raise ValueError(f'No samples found for group "{ga}" or "{gb}".')

        Xa = X_raw[idx_a, :]
        Xb = X_raw[idx_b, :]

        eps = 1e-9
        fc  = (Xb.mean(axis=0) + eps) / (Xa.mean(axis=0) + eps)
        log2fc = np.log2(fc)

        pvals = np.array([stats.ttest_ind(Xa[:, j], Xb[:, j],
                                          equal_var=False).pvalue
                          for j in range(X_raw.shape[1])])
        pvals = np.nan_to_num(pvals, nan=1.0)

        if p_adj:
            # Benjamini-Hochberg FDR
            n   = len(pvals)
            ord_i = np.argsort(pvals)
            pvals_adj = pvals.copy()
            for rank, idx in enumerate(ord_i):
                pvals_adj[idx] = min(pvals[idx] * n / (rank + 1), 1.0)
            # Enforce monotonicity
            min_val = 1.0
            for idx in ord_i[::-1]:
                pvals_adj[idx] = min(pvals_adj[idx], min_val)
                min_val = pvals_adj[idx]
            pvals_plot = pvals_adj
        else:
            pvals_plot = pvals

        neg_log_p = -np.log10(np.clip(pvals_plot, 1e-15, 1.0))

        ax = self._fig.add_subplot(111)
        sig_up   = (log2fc > np.log2(fc_thr))  & (pvals_plot < p_thr)
        sig_down = (log2fc < -np.log2(fc_thr)) & (pvals_plot < p_thr)
        ns       = ~(sig_up | sig_down)

        ax.scatter(log2fc[ns],       neg_log_p[ns],       color='#888888', s=20,
                   alpha=0.5, label='NS', edgecolors='none')
        ax.scatter(log2fc[sig_up],   neg_log_p[sig_up],   color='#c62828', s=28,
                   alpha=0.85, label=f'Up in {gb}', edgecolors='white', lw=0.4)
        ax.scatter(log2fc[sig_down], neg_log_p[sig_down], color='#1565c0', s=28,
                   alpha=0.85, label=f'Up in {ga}', edgecolors='white', lw=0.4)

        # Label top significant
        top_idx = np.argsort(neg_log_p)[::-1][:10]
        for i in top_idx:
            if pvals_plot[i] < p_thr:
                ax.annotate(feature_labels[i], (log2fc[i], neg_log_p[i]),
                            fontsize=5.5, xytext=(3, 2),
                            textcoords='offset points', color='#333')

        ax.axhline(-np.log10(p_thr), color='#555', lw=0.8, ls='--',
                   label=f'p={p_thr}')
        ax.axvline( np.log2(fc_thr), color='#999', lw=0.6, ls=':')
        ax.axvline(-np.log2(fc_thr), color='#999', lw=0.6, ls=':')
        ax.set_xlabel(f'log₂ FC ({gb} / {ga})', fontsize=9)
        p_label = 'FDR-adjusted p' if p_adj else 'p-value'
        ax.set_ylabel(f'−log₁₀({p_label})', fontsize=9)
        ax.set_title(f'Volcano: {ga} vs {gb}  '
                     f'({sig_up.sum()} up, {sig_down.sum()} down)', fontsize=10)
        ax.legend(fontsize=7.5, loc='best', framealpha=0.85)
        ax.set_facecolor('#f9f9f9')

    # ── Export ────────────────────────────────────────────────────────────────

    def _export(self):
        fmt  = getattr(self, '_fmt_var', None)
        fmt  = fmt.get().lower() if fmt else 'png'
        dpi  = getattr(self, '_dpi_var', None)
        dpi  = dpi.get() if dpi else 150
        ext  = fmt if fmt != 'tiff' else 'tif'
        fn = filedialog.asksaveasfilename(
            title='Save figure',
            defaultextension=f'.{ext}',
            filetypes=[(fmt.upper(), f'*.{ext}'), ('All', '*.*')],
            initialfile=f'statistics_{self._method_var.get().replace(" ","_")}.{ext}',
            parent=self.frame)
        if not fn:
            return
        try:
            self._fig.savefig(fn, dpi=dpi, format=fmt,
                              bbox_inches='tight', facecolor='white')
            messagebox.showinfo('Saved', f'Figure saved to:\n{fn}', parent=self.frame)
        except Exception as e:
            messagebox.showerror('Export error', str(e), parent=self.frame)
