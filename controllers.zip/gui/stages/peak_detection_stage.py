# gui/stages/peak_detection_stage.py
"""
Peak Detection Stage — Step 1 (noise) + Step 2 (peaks + deconvolution).
The matplotlib canvas is shared with all other stages and is never
recreated here — only the left-panel menu changes when switching tabs.
"""
import tkinter as tk
from tkinter import ttk, messagebox
import numpy as np
import os
import time
import certifi

os.environ['SSL_CERT_FILE']      = certifi.where()
os.environ['REQUESTS_CA_BUNDLE'] = certifi.where()

from processing.noise_estimation import estimate_noise_from_region
from .base_stage import BaseStage



def _no_blk_group_mean(all_intensities, samples_info):
    """Group mean of non-BLK, non-excluded samples (equal group weight)."""
    import numpy as np
    from collections import defaultdict
    if all_intensities is None: return None
    if all_intensities.ndim == 1: return all_intensities
    groups = defaultdict(list)
    for i, s in enumerate(samples_info or []):
        stype = s.get('type', s.get('label', 'Sample'))
        if (str(stype).upper() != 'BLK'
                and not s.get('excluded', False)
                and i < all_intensities.shape[1]):
            groups[s.get('label', 'unknown')].append(i)
    if not groups:
        return np.mean(all_intensities, axis=1)
    gmeans = np.stack([np.mean(all_intensities[:, idxs], axis=1)
                       for idxs in groups.values()], axis=1)
    n_blk = all_intensities.shape[1] - sum(len(v) for v in groups.values())
    print(f'   _no_blk_group_mean: {len(groups)} group(s), '
          f'{sum(len(v) for v in groups.values())} samples, {n_blk} BLK excl')
    return np.mean(gmeans, axis=1)


def _reference_group_mean(all_intensities, samples_info):
    """Mean of the non-BLK group with highest total intensity."""
    import numpy as np
    from collections import defaultdict
    if all_intensities is None: return None
    groups = defaultdict(list)
    for i, s in enumerate(samples_info or []):
        stype = s.get('type', s.get('label', 'Sample'))
        if str(stype).upper() != 'BLK' and i < all_intensities.shape[1]:
            groups[s.get('label', 'unknown')].append(i)
    if not groups:
        return np.mean(all_intensities, axis=1)
    best = max(groups, key=lambda g: float(
        np.sum(np.mean(all_intensities[:, groups[g]], axis=1))))
    print(f'   _reference_group_mean: group "{best}" '
          f'({len(groups[best])} sample(s)) — highest intensity')
    return np.mean(all_intensities[:, groups[best]], axis=1)

class PeakDetectionStage(BaseStage):

    def __init__(self, parent, app):
        super().__init__(parent, app)

        self.step1_completed = False
        self.noise_std       = None
        self.noise_source    = None
        self.peaks           = []
        self.default_noise_region = (12.0, 10.0)
        self._deconv_controller = None   # persists across tool opens
        self._overlaps = []              # last found overlap regions

        # Peak processor
        try:
            from gui.notation.peak_processing import PeakProcessor
            self.processor = PeakProcessor(app)
            print("✅ PeakProcessor initialized")
        except Exception as e:
            print(f"❌ PeakProcessor: {e}")
            self.processor = None

        self.create_widgets()

    # ── Status bar ────────────────────────────────────────────────────────────

    def _status(self, msg, color="blue"):
        try:
            self.app.status_label.config(text=msg, foreground=color)
            self.app.root.update_idletasks()
        except Exception:
            pass

    def _status_ok(self, msg):    self._status(msg, "green")
    def _status_err(self, msg):   self._status(msg, "red")
    def _status_ready(self):      self._status("Ready", "gray")

    # ── Widgets ───────────────────────────────────────────────────────────────

    def create_widgets(self):
        self.frame = ttk.Frame(self.parent)

        ttk.Label(self.frame, text="Peak Detection",
                  font=("Arial", 12, "bold")).pack(pady=10)
        ttk.Separator(self.frame, orient='horizontal').pack(
            fill=tk.X, padx=5, pady=5)

        # ── STEP 1: Noise ─────────────────────────────────────────────────────
        s1 = ttk.LabelFrame(self.frame,
                             text="📏 STEP 1: Noise Estimation", padding=5)
        s1.pack(fill=tk.X, padx=5, pady=5)

        rf = ttk.Frame(s1)
        rf.pack(fill=tk.X, pady=2)
        ttk.Label(rf, text="Noise Region (ppm):").pack(side=tk.LEFT, padx=2)
        self.noise_start_var = tk.StringVar(
            value=str(self.default_noise_region[0]))
        self.noise_end_var = tk.StringVar(
            value=str(self.default_noise_region[1]))
        ttk.Entry(rf, textvariable=self.noise_start_var,
                  width=8).pack(side=tk.LEFT, padx=2)
        ttk.Label(rf, text="to").pack(side=tk.LEFT)
        ttk.Entry(rf, textvariable=self.noise_end_var,
                  width=8).pack(side=tk.LEFT, padx=2)

        self.btn_calc_noise = ttk.Button(
            s1, text="🧮 Calculate Noise", command=self.calculate_noise)
        self.btn_calc_noise.pack(fill=tk.X, pady=5)

        self.noise_value_label = ttk.Label(s1, text="Noise Std Dev: --")
        self.noise_value_label.pack(anchor=tk.W, pady=2)
        self.step1_status = ttk.Label(
            s1, text="⏳ Not started", foreground="gray")
        self.step1_status.pack(anchor=tk.W, pady=2)

        # ── STEP 2: Peak Detection ────────────────────────────────────────────
        s2 = ttk.LabelFrame(
            self.frame,
            text="🔍 STEP 2: Peak Detection & Deconvolution", padding=5)
        s2.pack(fill=tk.X, padx=5, pady=5)

        # Row 1: Min SNR
        pf1 = ttk.Frame(s2)
        pf1.pack(fill=tk.X, pady=2)
        ttk.Label(pf1, text="Min SNR:").pack(side=tk.LEFT, padx=2)
        self.min_snr_var = tk.DoubleVar(value=3.0)
        ttk.Entry(pf1, textvariable=self.min_snr_var,
                  width=6).pack(side=tk.LEFT, padx=2)

        # Row 2: Min Width + Prominence
        pf2 = ttk.Frame(s2)
        pf2.pack(fill=tk.X, pady=2)
        ttk.Label(pf2, text="Min Width (ppm):").pack(side=tk.LEFT, padx=2)
        self.min_width_var = tk.DoubleVar(value=0.003)
        ttk.Entry(pf2, textvariable=self.min_width_var,
                  width=6).pack(side=tk.LEFT, padx=2)
        ttk.Label(pf2, text="Prominence:").pack(side=tk.LEFT, padx=(8, 2))
        self.prominence_var = tk.DoubleVar(value=1.5)
        ttk.Entry(pf2, textvariable=self.prominence_var,
                  width=5).pack(side=tk.LEFT, padx=2)

        self.btn_detect = ttk.Button(
            s2, text="🎯 Detect Peaks",
            command=self.detect_peaks, state="disabled")
        self.btn_detect.pack(fill=tk.X, pady=5)

        self.peaks_count_label = ttk.Label(s2, text="Peaks found: 0")
        self.peaks_count_label.pack(anchor=tk.W, pady=2)
        self.step2_status = ttk.Label(
            s2, text="⏳ Complete Step 1 first", foreground="gray")
        self.step2_status.pack(anchor=tk.W, pady=2)

        self.btn_toggle_peaks = ttk.Button(
            s2, text="👁 Show/Hide Peak Areas",
            command=self.toggle_peaks, state="disabled")
        self.btn_toggle_peaks.pack(fill=tk.X, pady=2)

        ttk.Separator(s2, orient='horizontal').pack(
            fill=tk.X, padx=5, pady=5)

        # Deconvolution buttons
        self.btn_find_overlaps = ttk.Button(
            s2, text="🔍 Find Overlaps",
            command=self.find_overlaps, state="disabled")
        self.btn_find_overlaps.pack(fill=tk.X, pady=2)

        # Consensus threshold row
        cf = ttk.Frame(s2)
        cf.pack(fill=tk.X, pady=2)
        ttk.Label(cf, text="Consensus %:").pack(side=tk.LEFT, padx=2)
        self.consensus_var = tk.DoubleVar(value=50.0)
        ttk.Entry(cf, textvariable=self.consensus_var,
                  width=5).pack(side=tk.LEFT, padx=2)
        ttk.Label(cf, text="(% espectros que devem votar)",
                  font=("Arial", 7), foreground="gray").pack(
                  side=tk.LEFT, padx=2)

        self.btn_open_deconv = ttk.Button(
            s2, text="🧅 Open Deconvolution Tool",
            command=self.open_deconv_tool, state="disabled")
        self.btn_open_deconv.pack(fill=tk.X, pady=2)

        self.deconv_status = ttk.Label(
            s2, text="Run peak detection first",
            foreground="gray", font=("Arial", 8))
        self.deconv_status.pack(anchor=tk.W, pady=2)

        # ── Mouse Controls ────────────────────────────────────────────────────
        mf = ttk.LabelFrame(self.frame, text="🐭 Mouse Controls", padding=5)
        mf.pack(fill=tk.X, padx=5, pady=5)
        ttk.Label(mf,
                  text="• Scroll: Zoom in/out\n"
                       "• Drag: Pan\n"
                       "• R: Reset view",
                  font=("Arial", 8), foreground="blue",
                  justify=tk.LEFT).pack(anchor=tk.W, padx=5)

    # ── Step 1 ────────────────────────────────────────────────────────────────

    def calculate_noise(self):
        if self.app.ppm is None:
            messagebox.showerror("Error", "Please load data first.")
            return
        try:
            r_start = float(self.noise_start_var.get())
            r_end   = float(self.noise_end_var.get())
            if r_start <= r_end:
                messagebox.showerror(
                    "Error",
                    "For NMR the left value must be greater than the right.")
                return
            self._status("Estimating noise...")
            t0 = time.monotonic()
            self.noise_std    = estimate_noise_from_region(
                self.app.ppm, self.app.all_intensities, r_start, r_end)
            self.noise_source = 'ppm'
            elapsed = time.monotonic() - t0
            self.noise_value_label.config(
                text=f"Noise Std Dev: {self.noise_std:.4f}")
            self.step1_completed = True
            self.step1_status.config(text="✅ Completed", foreground="green")
            self.btn_detect.config(state="normal")
            self.step2_status.config(
                text="⏳ Ready to detect peaks", foreground="blue")
            self._status_ok(
                f"Noise estimated: σ = {self.noise_std:.4f}  ({elapsed:.2f}s)")
        except ValueError as e:
            self._status_err(f"Noise failed: {e}")
            messagebox.showerror("Error", f"Invalid values: {e}")
        except Exception as e:
            self._status_err(f"Noise failed: {e}")
            messagebox.showerror("Error", str(e))

    # ── Step 2 ────────────────────────────────────────────────────────────────

    def detect_peaks(self):
        if not self.step1_completed or self.noise_std is None:
            messagebox.showinfo("Info", "Please estimate noise first.")
            return
        if self.processor is None:
            messagebox.showerror("Error", "Peak processor not initialized.")
            return
        try:
            self._status("Detecting peaks...")
            t0 = time.monotonic()
            self.processor.set_noise(self.noise_std)
            # Pass full intensity matrix — detect_peaks uses samples_info
            # internally to identify groups and build the reference spectrum
            # from the highest-intensity group (pointwise max).
            raw = self.processor.detect_peaks(
                self.app.ppm, self.app.all_intensities,
                min_snr=self.min_snr_var.get(),
                min_width_ppm=self.min_width_var.get(),
                prominence_factor=self.prominence_var.get(),
            )
            self.peaks = raw.copy()
            # Reset overlap flags and deconv controller (new detection run)
            for p in self.peaks:
                p['overlapping'] = False
            self._deconv_controller = None
            self._overlaps = []
            self.btn_open_deconv.config(state='disabled')
            self.peaks_count_label.config(
                text=f"Found {len(self.peaks)} peaks")
            # Enable Peak List button in right panel
            try:
                self.app.btn_peak_list.config(state="normal")
            except Exception:
                pass
            self.btn_find_overlaps.config(state="normal")
            self.btn_toggle_peaks.config(state="normal")
            self.deconv_status.config(
                text="Click 'Find Overlaps' to identify overlapping regions",
                foreground="blue")
            # Reset deconv tool button until new overlaps are found
            self.btn_open_deconv.config(state="disabled")
            self._status("Drawing peak areas...")
            self.color_peaks(force=True)
            elapsed = time.monotonic() - t0
            self._status_ok(
                f"Found {len(self.peaks)} peaks  ({elapsed:.2f}s)")
            messagebox.showinfo(
                "Success", f"Detected {len(self.peaks)} peaks")
        except Exception as e:
            self._status_err(f"Peak detection failed: {e}")
            messagebox.showerror("Error", f"Peak detection failed: {e}")
            import traceback; traceback.print_exc()

    def toggle_peaks(self):
        if self.peaks:
            self.color_peaks(force=False)

    def color_peaks(self, force=False):
        if not self.peaks or self.app.all_intensities is None:
            return
        mean = _no_blk_group_mean(
            self.app.all_intensities, self.app.samples_info)
        if self.app.plot_manager is not None:
            if force:
                self.app.plot_manager.force_redraw_peaks(
                    self.peaks, mean, self.app.ppm)
            else:
                self.app.plot_manager.draw_peak_overlay(
                    self.peaks, mean, self.app.ppm)

    def find_overlaps(self):
        if not self.peaks:
            messagebox.showinfo("Info", "Please detect peaks first.")
            return
        self._status("Searching for overlapping regions (consensus)...")
        t0 = time.monotonic()

        # Read consensus threshold from UI (convert % → fraction)
        try:
            consensus_pct = float(self.consensus_var.get())
            consensus_thr = max(0.0, min(1.0, consensus_pct / 100.0))
        except Exception:
            consensus_thr = 0.50

        # Consensus-based detection: each spectrum votes independently.
        # Store a copy of the current mean_intensity so downstream code
        # (colour_peaks, DeconvController) still has a reference spectrum.
        self.processor._original_mean_intensity = (
            self.processor.mean_intensity.copy()
            if self.processor.mean_intensity is not None else None)

        overlaps = self.processor.find_overlapping_regions_consensus(
            all_intensities=self.app.all_intensities,
            samples_info=self.app.samples_info,
            distance_threshold=0.04,
            consensus_threshold=consensus_thr,
            min_snr=self.min_snr_var.get(),
            min_width_ppm=self.min_width_var.get(),
            prominence_factor=self.prominence_var.get(),
        )
        elapsed = time.monotonic() - t0

        # Update overlapping flag on all peaks; clear any stale deconv state.
        for peak in self.peaks:
            in_group = peak.pop('_in_overlap_group', False)
            peak['overlapping'] = in_group
            peak.pop('_deconvolved', None)
            if in_group:
                peak.setdefault('from_overlap_search', True)
        self.processor.peaks = self.peaks
        self._overlaps = overlaps
        from gui.notation.deconvolution import DeconvController
        self._deconv_controller = DeconvController(self.processor)

        # Build controller entries: one per overlap region, split into sub-regions
        # of at most MAX_PEAKS_PER_REGION peaks so deconvolution stays tractable.
        _MAX = 3
        region_peaks = []
        for (lo, hi) in overlaps:
            lo_n, hi_n = min(lo, hi), max(lo, hi)
            peaks_in = sorted(
                [p for p in self.peaks
                 if p.get('overlapping') and lo_n <= p['ppm'] <= hi_n],
                key=lambda p: p['ppm'])
            if not peaks_in:
                continue
            n = len(peaks_in)
            for i in range(0, n, _MAX):
                chunk = peaks_in[i:i + _MAX]
                sub_lo = lo_n if i == 0 else (peaks_in[i - 1]['ppm'] + peaks_in[i]['ppm']) / 2
                last   = min(i + _MAX, n) - 1
                sub_hi = hi_n if (i + _MAX >= n) else (peaks_in[last]['ppm'] + peaks_in[last + 1]['ppm']) / 2
                rep = max(chunk, key=lambda p: p.get('height', 0))
                rp = dict(rep)
                rp['start_ppm'] = sub_hi
                rp['end_ppm']   = sub_lo
                rp['overlapping'] = True
                rp['from_overlap_search'] = True
                rp['_grouped_from'] = [p['ppm'] for p in chunk]
                region_peaks.append(rp)
        self._deconv_controller.set_peaks(region_peaks)

        # Redraw overlay with updated overlap flags
        if self.app.plot_manager and self.app.plot_manager._peaks_drawn:
            self.color_peaks(force=True)

        if not overlaps:
            self._status_ok(f"No overlapping regions  ({elapsed:.2f}s)")
            messagebox.showinfo("Info",
                                "No overlapping regions found.\n"
                                "All peaks are well separated.")
            return

        n = len(overlaps)
        self.btn_open_deconv.config(state="normal")
        self.deconv_status.config(
            text=f"{n} overlapping region{'s' if n != 1 else ''} found — "
                 f"click 'Open Deconvolution Tool'",
            foreground="orange")
        self._status_ok(f"Found {n} overlapping regions  ({elapsed:.2f}s)")
        # Enable bottom-bar shortcut
        try:
            self.app.btn_deconv_shortcut.config(state="normal")
        except Exception:
            pass

    def open_deconv_tool(self):
        """Open the deconvolution tool, reusing the persistent controller."""
        if not self._overlaps:
            messagebox.showinfo("Info",
                                "No overlapping regions found.\n"
                                "Run 'Find Overlaps' first.")
            return

        # Reuse the existing controller so all deconvolved results are preserved.
        # If the processor changed (new detection run), _deconv_controller was
        # reset in detect_peaks and recreated in find_overlaps.
        if self._deconv_controller is None:
            from gui.notation.deconvolution import DeconvController
            self._deconv_controller = DeconvController(self.processor)
            pass  # set_peaks already called in find_overlaps

        from gui.notation.deconvolution import DeconvWindow
        dw = DeconvWindow(self.app.root, self._deconv_controller, self)
        # Guardar referência singleton na app
        try:
            self.app._deconv_win = dw
            dw.window.protocol('WM_DELETE_WINDOW',
                lambda: (dw.window.destroy(),
                         setattr(self.app, '_deconv_win', None)))
        except Exception:
            pass

    def _show_deconv_results(self, results):
        import matplotlib.pyplot as plt
        from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
        win = tk.Toplevel(self.app.root)
        win.title(f"Deconvolution — {len(results['peaks'])} peaks")
        win.geometry("900x700")
        win.transient(self.app.root)
        mf = ttk.Frame(win, padding=10)
        mf.pack(fill=tk.BOTH, expand=True)
        fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(10, 8))

        def gaussian(x, a, c, w):
            return a * np.exp(-(x - c) ** 2 / (2 * w ** 2))

        ax1.plot(results['region_ppm'], results['region_intensity'],
                 'b-', lw=1.5, label='Original', alpha=0.8)
        for i, p in enumerate(results['peaks']):
            ax1.axvline(p['ppm'], color='r', ls='--', alpha=0.5, lw=1)
            ax1.text(p['ppm'], p['height'], f' {i+1}',
                     fontsize=9, fontweight='bold', color='darkred')
        ax1.invert_xaxis()
        ax1.set_xlabel('δ (ppm)'); ax1.set_ylabel('Intensity')
        ax1.set_title('Detected Peak Positions')
        ax1.grid(True, alpha=0.3, ls='--'); ax1.legend()

        ax2.plot(results['region_ppm'], results['region_intensity'],
                 'b-', lw=1.5, alpha=0.4, label='Original')
        xd = np.linspace(
            results['region_ppm'][0], results['region_ppm'][-1], 500)
        cols = plt.cm.tab10(np.linspace(0, 1, len(results['peaks'])))
        cum = np.zeros_like(xd)
        for i, p in enumerate(results['peaks']):
            yp = gaussian(xd, p['height'], p['ppm'], p['width'])
            cum += yp
            ax2.plot(xd, yp, '--', color=cols[i], lw=2,
                     label=f"Peak {i+1}: {p['ppm']:.4f}")
            ax2.fill_between(xd, 0, yp, alpha=0.2, color=cols[i])
        ax2.plot(xd, cum, 'r-', lw=2, label='Fit', alpha=0.9)
        ax2.invert_xaxis()
        ax2.set_xlabel('δ (ppm)'); ax2.set_ylabel('Intensity')
        ax2.set_title(f"Deconvolution — BIC: {results['bic']:.1f}")
        ax2.grid(True, alpha=0.3, ls='--')
        ax2.legend(loc='upper right', fontsize=8)
        fig.tight_layout()

        cv = FigureCanvasTkAgg(fig, master=mf)
        cv.draw()
        cv.get_tk_widget().pack(fill=tk.BOTH, expand=True)
        ttk.Button(mf, text="Close",
                   command=win.destroy).pack(side=tk.RIGHT, pady=5)
        win.update_idletasks()
        w, h = win.winfo_width(), win.winfo_height()
        win.geometry(
            f'{w}x{h}+{win.winfo_screenwidth()//2-w//2}'
            f'+{win.winfo_screenheight()//2-h//2}')

    # ── Lifecycle ─────────────────────────────────────────────────────────────

    def on_activate(self):
        print("🔄 PeakDetectionStage activated")
        if self.frame:
            self.frame.pack(fill=tk.BOTH, expand=True)
        if self.app.plot_manager and self.app.plot_manager.original_xlim is None:
            self.app.plot_manager.original_xlim = self.app.ax.get_xlim()
            self.app.plot_manager.original_ylim = self.app.ax.get_ylim()
        self._status_ready()
        self.app.root.bind('<Key-r>', lambda e: self.reset_zoom())
        self.app.root.bind('<Key-R>', lambda e: self.reset_zoom())

    def on_deactivate(self):
        print("PeakDetectionStage deactivated")
        self.app.root.unbind('<Key-r>')
        self.app.root.unbind('<Key-R>')
        if self.frame:
            self.frame.pack_forget()

    def reset_zoom(self):
        if self.app.plot_manager:
            self.app.plot_manager.reset_zoom()