# gui/stages/quantification_stage.py
"""
Quantification Stage — Step 4.

Left  : IS config, normalisation, MCR toggle, run, export
Right : PanedWindow (vertical)
  Top    : Treeview — analytes × quality columns (CV per group)
  Middle : Overlay plot (per-sample spectra, coloured by group)
           + bar chart (mean ± SD per group)
  Right  : Quality card

Integration: trapezoidal, per sample.
MCR option : simplified NMF-ALS per peak region.
CV         : calculated within each group independently.
"""
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import numpy as np
import csv, os

import matplotlib
matplotlib.use('TkAgg')
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

from .base_stage import BaseStage

# ── helpers ───────────────────────────────────────────────────────────────────

def _trapz(y, x):
    try:
        return np.trapezoid(y, x=x)
    except AttributeError:
        return np.trapz(y, x=x)


def _pls_vip(X, y, n_components=2):
    """Compute PLS-DA VIP scores (no sklearn required).

    X : (n_samples, n_features)  — concentrations, NaN columns are skipped
    y : (n_samples,)             — group labels encoded as integers
    Returns array of shape (n_features,) with VIP scores (NaN for skipped cols).
    """
    n, p = X.shape
    n_comp = min(n_components, min(n - 1, p))
    if n_comp < 1 or n < 3:
        return np.full(p, float('nan'))

    # Replace NaN with column mean, keep track of all-NaN columns
    col_means = np.nanmean(X, axis=0)
    nan_cols   = np.all(np.isnan(X), axis=0)
    Xc = np.where(np.isnan(X), col_means, X)
    # Standardise X
    x_std = Xc.std(axis=0)
    x_std[x_std < 1e-12] = 1.0
    Xc = (Xc - col_means) / x_std

    yc = y.astype(float)
    yc -= yc.mean()
    y_std = yc.std()
    if y_std < 1e-12:
        return np.full(p, float('nan'))
    yc /= y_std

    W = np.zeros((p, n_comp))
    T = np.zeros((n, n_comp))
    SS = np.zeros(n_comp)

    Xr, yr = Xc.copy(), yc.copy()
    for k in range(n_comp):
        w = Xr.T @ yr
        wn = np.linalg.norm(w)
        if wn < 1e-12:
            break
        w /= wn
        t = Xr @ w
        tt = float(t @ t)
        if tt < 1e-12:
            break
        q = float(yr @ t) / tt
        p_k = Xr.T @ t / tt
        W[:, k] = w
        T[:, k] = t
        SS[k] = q * q * tt
        Xr -= np.outer(t, p_k)
        yr -= q * t

    SS_total = SS.sum()
    if SS_total < 1e-12:
        return np.full(p, float('nan'))

    vip = np.sqrt(p * (W ** 2 @ SS) / SS_total)
    vip[nan_cols] = float('nan')
    return vip


def _cv(vals):
    """CV% of a 1-D array, returns NaN if < 2 finite positive values."""
    v = [x for x in vals if np.isfinite(x) and x > 0]
    if len(v) < 2:
        return float('nan')
    m = float(np.mean(v))
    return float(np.std(v) / m * 100) if m > 0 else float('nan')


def _pqn(areas_dict, ref_dict):
    quotients = [v / ref_dict[k]
                 for k, v in areas_dict.items()
                 if k in ref_dict and ref_dict[k] > 0 and v > 0]
    if len(quotients) < 3:
        return dict(areas_dict), 1.0
    f = float(np.median(quotients))
    if f <= 0:
        return dict(areas_dict), 1.0
    return {k: v / f for k, v in areas_dict.items()}, f


def _effective_nh(hit, detected_ppm, spectrometer_mhz=600.0):
    """
    Return the effective nH for the specific detected line of a multiplet.

    When only one line of a doublet (or triplet, quartet…) is integrated,
    the area represents only a fraction of the total multiplet area.
    The effective nH = nH_total × (intensity_fraction_of_that_line).

    For a doublet (equal lines): nH_eff = nH / 2
    For a triplet centre line:   nH_eff = nH × 0.5
    For a triplet outer line:    nH_eff = nH × 0.25
    etc.

    Falls back to nH_total when pattern is unknown or J cannot be parsed.
    """
    import re as _re
    nH = max(1.0, float(hit.get('protons', 1) or 1))
    pattern = (hit.get('pattern') or 's').lower().strip()

    # Pascal's triangle coefficients for common first-order multiplets
    _pascal = {
        's':  [1],
        'd':  [1, 1],
        't':  [1, 2, 1],
        'q':  [1, 3, 3, 1],
        'p':  [1, 4, 6, 4, 1],
        'h':  [1, 5, 10, 10, 5, 1],
        'dd': [1, 1, 1, 1],
        'dt': [1, 1, 2, 2, 1, 1],
        'td': [1, 2, 1, 1, 2, 1],
    }
    coeffs = _pascal.get(pattern)
    if coeffs is None or len(coeffs) == 1:
        return nH  # singlet or unknown — use full nH

    # Parse the first J value to compute line spacing in ppm
    j_str  = str(hit.get('j_coupling') or '').strip()
    j_nums = [float(x) for x in _re.findall(r'\d+\.?\d*', j_str) if float(x) > 0]
    if not j_nums:
        return nH  # can't determine positions — fall back

    j_hz   = j_nums[0]
    spacing_ppm = j_hz / spectrometer_mhz   # ppm between adjacent lines

    # Compute line positions relative to multiplet centre
    n      = len(coeffs)
    centre = float(hit.get('ppm_center', hit.get('ppm', detected_ppm)))
    positions = [centre + (i - (n - 1) / 2.0) * spacing_ppm for i in range(n)]

    # Find which line the detected peak is closest to
    dists   = [abs(detected_ppm - pos) for pos in positions]
    closest = dists.index(min(dists))

    fraction = coeffs[closest] / sum(coeffs)
    return nH * fraction


def _mcr_als(X, n_components=1, max_iter=200, tol=1e-6, S_init=None):
    """Wrapper around shared MCR-ALS implementation."""
    from gui.utils.mcr_utils import mcr_als as _shared_mcr
    return _shared_mcr(X, n_components=n_components, max_iter=max_iter,
                       tol=tol, S_init=S_init)


def _lorentz_shape(x, cen, wid):
    """Unit-height Lorentzian: 1 at centre, HWHM = wid."""
    return wid ** 2 / ((x - cen) ** 2 + wid ** 2)


def _fit_lorentz_mean(x, y_mean):
    """
    Fit a Lorentzian A·L(x; cen, wid) to the mean spectrum.
    Optimises A, cen, wid jointly so that the model truly matches the data.
    Returns (A, cen, wid_hwhm) — wid is the HWHM of the fitted Lorentzian.
    Falls back to heuristic estimates on failure.
    """
    from scipy.optimize import curve_fit
    y = np.clip(y_mean, 0, None)
    if len(x) < 4 or y.max() <= 0:
        i = int(np.argmax(y))
        return float(y[i]), float(x[i]), float(abs(x[-1] - x[0]) / 4)

    i_max = int(np.argmax(y))
    A0  = float(y[i_max])
    c0  = float(x[i_max])
    # Estimate HWHM from the half-max crossing points
    half  = A0 / 2.0
    above = np.where(y >= half)[0]
    if len(above) >= 2:
        w0 = abs(float(x[above[-1]] - x[above[0]])) / 2.0
    else:
        w0 = abs(float(x[-1] - x[0])) / 4.0
    dppm = abs(float(x[1] - x[0])) if len(x) > 1 else 1e-4
    w0   = max(w0, dppm)

    x_span = abs(float(x[-1] - x[0]))
    try:
        popt, _ = curve_fit(
            lambda x_, A, c, w: A * _lorentz_shape(x_, c, w),
            x, y,
            p0=[A0, c0, w0],
            bounds=([0,         float(x.min()), dppm],
                    [A0 * 5.0,  float(x.max()), x_span]),
            maxfev=4000)
        return float(popt[0]), float(popt[1]), float(popt[2])
    except Exception:
        return A0, c0, w0


def _align_sample_center(x, y, cen_mean, max_shift_ppm=0.02):
    """
    Find the peak center for a single sample within ±max_shift_ppm of the
    mean-spectrum center.  Returns the per-sample center (ppm).

    Strategy: argmax within the allowed window.  Falls back to cen_mean when
    the window contains fewer than 2 points or the signal is flat.
    """
    mask = np.abs(x - cen_mean) <= max_shift_ppm
    if mask.sum() < 2:
        return float(cen_mean)
    x_w = x[mask]
    y_w = y[mask]
    if y_w.max() <= 0:
        return float(cen_mean)
    return float(x_w[int(np.argmax(y_w))])


def _lorentz_amplitude(x, y, cen, wid):
    """
    NNLS amplitude for a Lorentzian with *fixed* shape (cen, wid already
    optimised on the mean spectrum).  cen may be a per-sample aligned center.
    """
    from scipy.optimize import nnls as _nnls
    wid = max(abs(float(wid)), 1e-5)
    L   = _lorentz_shape(x, cen, wid).reshape(-1, 1)
    A, _ = _nnls(L, np.clip(y, 0, None))
    return float(A[0])


_STD_PRESETS = {
    'TSP':         {'ppm': '0.0',  'nh': '9'},
    'DSS':         {'ppm': '0.0',  'nh': '9'},
    'TMSP':        {'ppm': '0.0',  'nh': '9'},
    'Maleic acid': {'ppm': '6.0',  'nh': '2'},
    'Formate':     {'ppm': '8.46', 'nh': '1'},
    'Custom':      {'ppm': '',     'nh': ''},
}


class QuantificationStage(BaseStage):

    def __init__(self, parent, app, peak_stage, annotation_stage):
        super().__init__(parent, app)
        self.peak_stage       = peak_stage
        self.annotation_stage = annotation_stage
        self._quant_results   = []
        self._pqn_factor      = 1.0
        self._right_widget    = None
        self._detail_fig      = None
        self._detail_canvas   = None
        self._sort_col        = 'conc_mm'
        self._sort_rev        = True
        self._search_var      = None  # set in _build_right_panel
        self._placeholder     = None  # set in _build_right_panel
        self._tree            = None  # set in _build_right_panel
        self.create_widgets()

    # ── status helpers ────────────────────────────────────────────────────────

    def _status(self, msg, color='blue'):
        try:
            self.app.status_label.config(text=msg, foreground=color)
            self.app.root.update_idletasks()
        except Exception:
            pass

    def _status_ok(self,  m): self._status(m, 'green')
    def _status_err(self, m): self._status(m, 'red')

    def _find_peak(self, ppm_target, tol=0.01):
        best, best_d = None, tol
        for p in (self.peak_stage.peaks or []):
            d = abs(p['ppm'] - ppm_target)
            if d < best_d:
                best, best_d = p, d
        return best

    # ── Left panel ────────────────────────────────────────────────────────────

    def create_widgets(self):
        self.frame = ttk.Frame(self.parent)
        ttk.Label(self.frame, text='Quantification',
                  font=('Arial', 12, 'bold')).pack(pady=8)
        ttk.Separator(self.frame, orient='horizontal').pack(
            fill=tk.X, padx=5, pady=4)

        cv_canvas = tk.Canvas(self.frame, borderwidth=0, highlightthickness=0)
        sb = ttk.Scrollbar(self.frame, orient=tk.VERTICAL, command=cv_canvas.yview)
        sf = ttk.Frame(cv_canvas)
        _sf_win = cv_canvas.create_window((0, 0), window=sf, anchor='nw')

        def _on_sf_configure(e):
            cv_canvas.configure(scrollregion=cv_canvas.bbox('all'))
        def _on_canvas_resize(e):
            cv_canvas.itemconfig(_sf_win, width=e.width)

        sf.bind('<Configure>', _on_sf_configure)
        cv_canvas.bind('<Configure>', _on_canvas_resize)
        cv_canvas.configure(yscrollcommand=sb.set)
        sb.pack(side=tk.RIGHT, fill=tk.Y)
        cv_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        def _on_mousewheel(event):
            cv_canvas.yview_scroll(int(-1 * (event.delta / 120)), 'units')
        def _bind_mousewheel(widget):
            widget.bind('<MouseWheel>', _on_mousewheel)
            for child in widget.winfo_children():
                _bind_mousewheel(child)
        sf.bind('<Map>', lambda e: _bind_mousewheel(sf))

        # 1. Reference Signal
        s1 = ttk.LabelFrame(sf, text='1 · Reference Signal (IS)', padding=6)
        s1.pack(fill=tk.X, padx=6, pady=4)

        r0 = ttk.Frame(s1); r0.pack(fill=tk.X, pady=1)
        ttk.Label(r0, text='Standard:', width=14).pack(side=tk.LEFT)
        self.ref_std_var = tk.StringVar(value='TSP')
        cb = ttk.Combobox(r0, textvariable=self.ref_std_var,
                          values=list(_STD_PRESETS.keys()),
                          state='readonly', width=12)
        cb.pack(side=tk.LEFT, padx=2)
        cb.bind('<<ComboboxSelected>>', self._on_std_select)

        r2 = ttk.Frame(s1); r2.pack(fill=tk.X, pady=1)
        ttk.Label(r2, text='Peak Ref (ppm):', width=20).pack(side=tk.LEFT)
        self.ref_ppm_var = tk.StringVar(value='0.0')
        ttk.Entry(r2, textvariable=self.ref_ppm_var, width=7).pack(
            side=tk.LEFT, padx=2)
        ttk.Label(r2, text='±0.05 ppm', font=('Arial', 7),
                  foreground='gray').pack(side=tk.LEFT)

        r1 = ttk.Frame(s1); r1.pack(fill=tk.X, pady=1)
        ttk.Label(r1, text='— or Peak #:', width=20).pack(side=tk.LEFT)
        self.ref_rank_var = tk.StringVar(value='')
        ttk.Entry(r1, textvariable=self.ref_rank_var, width=6).pack(
            side=tk.LEFT, padx=2)

        r3 = ttk.Frame(s1); r3.pack(fill=tk.X, pady=1)
        ttk.Label(r3, text='Concentration (mM):', width=20).pack(side=tk.LEFT)
        self.ref_conc_var = tk.StringVar(value='1.0')
        ttk.Entry(r3, textvariable=self.ref_conc_var, width=7).pack(
            side=tk.LEFT, padx=2)

        r4 = ttk.Frame(s1); r4.pack(fill=tk.X, pady=1)
        ttk.Label(r4, text='nH of IS:', width=20).pack(side=tk.LEFT)
        self.ref_nh_var = tk.StringVar(value='9')
        ttk.Entry(r4, textvariable=self.ref_nh_var, width=7).pack(
            side=tk.LEFT, padx=2)

        ttk.Label(s1,
                  text='TSP/DSS/TMSP: 0.00 ppm | nH=9\n'
                       'Maleic acid: 6.00 ppm | nH=2\n'
                       'Formate: 8.46 ppm | nH=1',
                  font=('Arial', 7), foreground='gray').pack(anchor=tk.W)

        ttk.Separator(s1, orient='horizontal').pack(fill=tk.X, pady=4)
        ext_row = ttk.Frame(s1); ext_row.pack(fill=tk.X, pady=1)
        self.ext_is_var = tk.BooleanVar(value=False)
        self._ext_is_cb = ttk.Checkbutton(ext_row, text='External IS',
                                           variable=self.ext_is_var)
        self._ext_is_cb.pack(side=tk.LEFT)
        ttk.Button(ext_row, text='Select samples…',
                   command=self._open_ext_is_dialog).pack(side=tk.LEFT, padx=6)
        self._ext_is_label = ttk.Label(ext_row, text='(none selected)',
                                        font=('Arial', 7), foreground='gray')
        self._ext_is_label.pack(side=tk.LEFT)
        ttk.Label(s1,
                  text='External IS: uses IS area from selected samples\n'
                       '(e.g. BLK) as fixed reference for all analytical samples.',
                  font=('Arial', 7), foreground='gray').pack(anchor=tk.W)

        # 3. Integration
        s2 = ttk.LabelFrame(sf, text='2 · Integration', padding=6)
        s2.pack(fill=tk.X, padx=6, pady=4)

        mf = ttk.Frame(s2); mf.pack(fill=tk.X, pady=1)
        ttk.Label(mf, text='Signal:').pack(side=tk.LEFT)
        self.integ_var = tk.StringVar(value='Area')
        for v, lbl in [('Area', 'Area (trapz)'), ('Lorentz', 'Lorentz Fit ★')]:
            ttk.Radiobutton(mf, text=lbl, variable=self.integ_var,
                            value=v, command=self._on_integ_change).pack(side=tk.LEFT, padx=4)

        pf = ttk.Frame(s2); pf.pack(fill=tk.X, pady=1)
        self.proton_corr_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(pf, text='Proton correction (÷ nH)',
                        variable=self.proton_corr_var).pack(side=tk.LEFT)

        mf2 = ttk.Frame(s2); mf2.pack(fill=tk.X, pady=1)
        self._ext_is_indices = []   # sample indices used as External IS
        self.mcr_var = tk.BooleanVar(value=False)
        self._mcr_cb = ttk.Checkbutton(mf2, text='MCR-ALS (per-region, 1 component)',
                                        variable=self.mcr_var)
        self._mcr_cb.pack(side=tk.LEFT)
        ttk.Label(s2,
                  text='Lorentz Fit: fits Lorentzian per sample (BATMAN-style).\n'
                       'MCR-ALS: deconvolução multivariada (picos sobrepostos).\n'
                       'MCR-ALS só é compatível com Area. Inativo em Lorentz.',
                  font=('Arial', 7), foreground='gray').pack(anchor=tk.W)

        # 3. Normalisation
        s4 = ttk.LabelFrame(sf, text='3 · Normalisation', padding=6)
        s4.pack(fill=tk.X, padx=6, pady=4)

        self.norm_var = tk.StringVar(value='IS')
        for lbl, val in [('Internal std (IS)', 'IS'),
                         ('PQN',               'PQN'),
                         ('Total area %',      'Total'),
                         ('None',              'None')]:
            ttk.Radiobutton(s4, text=lbl, variable=self.norm_var,
                            value=val).pack(anchor=tk.W)
        ttk.Separator(s4, orient='horizontal').pack(fill=tk.X, pady=4)
        self.blk_sub_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(s4, text='Subtract BLK mean (blank correction)',
                        variable=self.blk_sub_var).pack(anchor=tk.W)
        ttk.Label(s4, text='Removes mean BLK area from each\nsample before quantification.',
                  font=('Arial', 7), foreground='gray').pack(anchor=tk.W)

        # Run
        ttk.Separator(sf, orient='horizontal').pack(
            fill=tk.X, padx=5, pady=6)
        self.btn_run = ttk.Button(
            sf, text='⚗ Run Quantification',
            command=self._run, state='disabled')
        self.btn_run.pack(fill=tk.X, padx=6, pady=2)
        self.run_status = ttk.Label(
            sf, text='Run Annotation first',
            foreground='gray', font=('Arial', 8))
        self.run_status.pack(pady=2)

        ttk.Separator(sf, orient='horizontal').pack(
            fill=tk.X, padx=5, pady=4)

        # Export
        ttk.Label(sf, text='Export',
                  font=('Arial', 10, 'bold')).pack(anchor=tk.W, padx=6)
        self.btn_csv = ttk.Button(
            sf, text='📋 Export CSV',
            command=lambda: self._export('csv'), state='disabled')
        self.btn_csv.pack(fill=tk.X, padx=6, pady=2)
        self.btn_metaboanalyst = ttk.Button(
            sf, text='📊 Export MetaboAnalyst',
            command=lambda: self._export('metaboanalyst'), state='disabled')
        self.btn_metaboanalyst.pack(fill=tk.X, padx=6, pady=2)
        ttk.Label(sf,
                  text='CSV: Sample × Group × Metabolite (mM)\n'
                       'MetaboAnalyst: samples × metabolites',
                  font=('Arial', 7), foreground='gray').pack(
                      anchor=tk.W, padx=6)

    # ── Lifecycle ─────────────────────────────────────────────────────────────

    def on_activate(self):
        self.frame.pack(fill=tk.BOTH, expand=True)
        has_ann = (hasattr(self.annotation_stage, '_last_results_args')
                   and bool(self.annotation_stage._last_results_args))
        _fs_stage   = (getattr(self.app, 'stages', {}) or {}).get('fullspectrum_mcr')
        has_fs      = bool(getattr(_fs_stage, '_mcr_regions', None))
        ready       = has_ann or has_fs
        self.btn_run.config(state='normal' if ready else 'disabled')
        self.run_status.config(
            text='Ready — configure and run' if ready
                 else 'Run Full Spectrum MCR or Annotation first',
            foreground='blue' if ready else 'gray')
        self._hide_canvas()
        self._show_right_panel()

    def on_deactivate(self):
        if self.frame:
            self.frame.pack_forget()
        self._restore_canvas()

    def _hide_canvas(self):
        try:
            self.app.canvas.get_tk_widget().pack_forget()
        except Exception:
            pass
        try:
            self.app.toolbar.pack_forget()
        except Exception:
            pass

    def _restore_canvas(self):
        if self._right_widget:
            try: self._right_widget.pack_forget()
            except Exception: pass
        # Ordem correcta: toolbar BOTTOM primeiro, canvas TOP depois
        # (mesma ordem do create_main_layout no app.py)
        try:
            self.app.toolbar.pack_forget()
        except Exception:
            pass
        try:
            self.app.canvas.get_tk_widget().pack_forget()
        except Exception:
            pass
        try:
            self.app.toolbar.pack(side=tk.BOTTOM, fill=tk.X)
        except Exception:
            pass
        try:
            self.app.canvas.get_tk_widget().pack(
                side=tk.TOP, fill=tk.BOTH, expand=True)
        except Exception:
            pass

    # ── Right panel ───────────────────────────────────────────────────────────

    def _show_right_panel(self):
        if self._right_widget is None:
            self._build_right_panel()
        self._right_widget.pack(fill=tk.BOTH, expand=True)
        if self._quant_results:
            self._populate_tree()
        else:
            self._show_placeholder()

    def _build_right_panel(self):
        self._right_widget = ttk.Frame(self.app.right_panel)

        paned = tk.PanedWindow(self._right_widget, orient=tk.VERTICAL,
                               sashwidth=6, sashrelief=tk.RAISED)
        paned.pack(fill=tk.BOTH, expand=True)

        # Top: Treeview
        top = ttk.Frame(paned)
        paned.add(top, minsize=240)

        # Search bar
        sf2 = ttk.Frame(top)
        sf2.pack(fill=tk.X, padx=2, pady=(2, 0))
        ttk.Label(sf2, text='🔍', font=('Arial', 9)).pack(side=tk.LEFT)
        self._search_var = tk.StringVar()
        self._search_var.trace_add('write', lambda *_: self._populate_tree())
        ttk.Entry(sf2, textvariable=self._search_var,
                  width=20).pack(side=tk.LEFT, padx=2)
        ttk.Button(sf2, text='✕', width=2,
                   command=lambda: self._search_var.set('')
                   ).pack(side=tk.LEFT)

        cols = ('peak_num', 'metabolite', 'ppm', 'conc_mm',
                'raw_area', 'snr', 'vip_score', 'status')
        self._tree = ttk.Treeview(top, columns=cols, show='headings',
                                   selectmode='browse')
        for cid, hd, w in [
            ('peak_num',    '#',               35),
            ('metabolite',  'Metabolite',     210),
            ('ppm',         'PPM',             70),
            ('conc_mm',     'Mean Conc (mM)', 110),
            ('raw_area',    'Mean Area',        90),
            ('snr',         'Mean SNR',         60),
            ('vip_score',   'VIP',              55),
            ('status',      'Quality',          70),
        ]:
            self._tree.heading(cid, text=hd,
                               command=lambda c=cid: self._sort_tree(c))
            self._tree.column(cid, width=w, minwidth=40)

        self._tree.tag_configure('good', background='#c8f7c5')
        self._tree.tag_configure('warn', background='#fef9c3')
        self._tree.tag_configure('poor', background='#ffd6d6')

        vsb = ttk.Scrollbar(top, orient=tk.VERTICAL,
                             command=self._tree.yview)
        self._tree.configure(yscrollcommand=vsb.set)
        self._tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        vsb.pack(side=tk.RIGHT, fill=tk.Y)
        self._tree.bind('<<TreeviewSelect>>', self._on_tree_select)
        self._tree.bind('<Motion>',  self._on_tree_motion)
        self._tree.bind('<Leave>',   self._hide_tooltip)
        self._tooltip_win  = None
        self._tooltip_iid  = None

        self._placeholder = ttk.Label(
            top, text='Run Quantification to see results.',
            font=('Arial', 11), foreground='gray')

        # Bottom: horizontal split — left (spec+bar) | right (card)
        bot = tk.PanedWindow(paned, orient=tk.HORIZONTAL,
                             sashwidth=5, sashrelief=tk.RAISED,
                             bg='#d9d9d9')
        paned.add(bot, minsize=400)

        # Left: vertical split — spectrum | bar
        left_paned = tk.PanedWindow(bot, orient=tk.VERTICAL,
                                    sashwidth=5, sashrelief=tk.RAISED,
                                    bg='#d9d9d9')
        bot.add(left_paned, stretch='always')
        self._bot_paned = bot  # keep ref to set sash after render

        # Spectrum frame
        f_spec = ttk.Frame(left_paned)
        left_paned.add(f_spec, minsize=180, stretch='always')
        self._fig_spec = plt.Figure(facecolor='#f8f8f8', tight_layout=True)
        self._ax_spec  = self._fig_spec.add_subplot(111)
        self._cv_spec  = FigureCanvasTkAgg(self._fig_spec, master=f_spec)
        
        # Toolbar: BOTTOM inside f_spec, before canvas TOP
        from matplotlib.backends.backend_tkagg import NavigationToolbar2Tk
        self._tb_spec = NavigationToolbar2Tk(self._cv_spec, f_spec, pack_toolbar=False)
        self._tb_spec.update()
        self._tb_spec.pack(side=tk.BOTTOM, fill=tk.X)

        cw_spec = self._cv_spec.get_tk_widget()
        cw_spec.pack(side=tk.TOP, fill=tk.BOTH, expand=True)

        # Bar chart frame
        f_bar = ttk.Frame(left_paned)
        left_paned.add(f_bar, minsize=150, stretch='always')
        self._fig_bar = plt.Figure(facecolor='#f8f8f8', tight_layout=True)
        self._ax_bar  = self._fig_bar.add_subplot(111)
        self._cv_bar  = FigureCanvasTkAgg(self._fig_bar, master=f_bar)
        cw_bar = self._cv_bar.get_tk_widget()
        cw_bar.pack(fill=tk.BOTH, expand=True)

        # Quality card — right panel
        f_card = ttk.Frame(bot)
        bot.add(f_card, minsize=180, stretch='never')
        # Set 70/30 split after the window has been rendered
        def _set_sash(*_):
            total = self._bot_paned.winfo_width()
            if total > 10:
                self._bot_paned.sash_place(0, int(total * 0.70), 0)
        bot.bind('<Configure>', _set_sash, add='+')
        self._fig_card = plt.Figure(facecolor='#f8f8f8')
        self._fig_card.set_constrained_layout(True)
        gs_card = self._fig_card.add_gridspec(2, 1, height_ratios=[1.4, 1], hspace=0.15)
        self._ax_card     = self._fig_card.add_subplot(gs_card[0])  # top: metabolite info
        self._ax_card_bot = self._fig_card.add_subplot(gs_card[1])  # bottom: per-group table
        self._cv_card  = FigureCanvasTkAgg(self._fig_card, master=f_card)
        cw_card = self._cv_card.get_tk_widget()
        cw_card.pack(fill=tk.BOTH, expand=True)
        self._card_row_tips    = {}   # populated in _draw_detail
        self._card_tooltip_win = None
        self._fig_card.canvas.mpl_connect('motion_notify_event', self._on_card_motion)
        self._fig_card.canvas.mpl_connect('axes_leave_event',    self._hide_card_tooltip)
        # Initial placeholder
        for _ax in (self._ax_card, self._ax_card_bot):
            _ax.axis('off')
        self._ax_card.text(0.5, 0.5, 'Select a metabolite\nto see quality info',
                           ha='center', va='center', fontsize=8, color='gray',
                           transform=self._ax_card.transAxes)

        # Legacy refs
        self._detail_fig    = self._fig_spec
        self._detail_canvas = self._cv_spec

    def _show_placeholder(self):
        if self._tree: self._tree.pack_forget()
        if self._placeholder: self._placeholder.pack(expand=True)

    def _populate_tree(self):
        if self._tree is None or self._placeholder is None:
            return
        self._placeholder.pack_forget()
        self._tree.delete(*self._tree.get_children())
        self._tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        # Update column headers with sort arrow
        _nm = getattr(self, 'norm_var', None)
        _norm = _nm.get() if _nm else 'IS'
        _conc_hdr = ('Mean Conc (mM)' if _norm == 'IS'
                     else 'Mean Area %'  if _norm == 'Total'
                     else 'Mean Area (a.u.)')
        labels = {'peak_num': '#', 'metabolite': 'Metabolite', 'ppm': 'PPM',
                  'conc_mm': _conc_hdr, 'raw_area': 'Mean Area',
                  'snr': 'Mean SNR', 'vip_score': 'VIP', 'status': 'Quality'}
        for cid, lbl in labels.items():
            arrow = (' ▲' if not self._sort_rev else ' ▼') \
                    if cid == self._sort_col else ''
            self._tree.heading(cid, text=lbl + arrow)

        # Search filter
        q = getattr(self, '_search_var', None)
        q = q.get().strip().lower() if q else ''

        def _sort_key(r):
            v = r.get(self._sort_col, 0) or 0
            if self._sort_col == 'metabolite':
                return str(v).lower()
            try: return float(v)
            except Exception: return str(v).lower()

        filtered = [r for r in self._quant_results
                    if not q or q in r.get('metabolite', '').lower()
                    or q in f"{r.get('ppm', 0):.4f}"]
        results = sorted(filtered, key=_sort_key, reverse=self._sort_rev)

        _is_mm = (_norm == 'IS')
        for r in results:
            conc = r.get('conc_mm', float('nan'))
            if not np.isfinite(conc):
                conc_s = 'N/A'
            elif _is_mm:
                conc_s = f'{conc:.4f}'
            else:
                conc_s = f'{conc:.3e}'
            area = r.get('raw_area', 0)
            snr  = r.get('snr', 0)
            stat = r.get('status', 'good')
            sym  = '✓' if stat == 'good' else ('△' if stat == 'warn' else '✗')
            peak_rank = r.get('_peak', {})
            peak_rank = peak_rank.get('rank', '–') if peak_rank else '–'
            vip = r.get('vip_score', float('nan'))
            vip_s = f'{vip:.2f}' if np.isfinite(vip) else '—'
            self._tree.insert(
                '', tk.END,
                iid=r.get('hmdb_id', r['metabolite']),
                tags=(stat,),
                values=(peak_rank,
                        r['metabolite'],
                        f"{r.get('ppm', 0):.4f}",
                        conc_s,
                        f'{area:.4e}',
                        f'{snr:.1f}',
                        vip_s,
                        f'{sym} {stat.capitalize()}'))

    def _sort_tree(self, col):
        if self._sort_col == col:
            self._sort_rev = not self._sort_rev
        else:
            self._sort_col = col
            # Numeric cols default descending, text cols ascending
            self._sort_rev = col not in ('metabolite',)
        if self._quant_results:
            self._populate_tree()

    def _on_tree_select(self, event=None):
        sel = self._tree.selection()
        if not sel: return
        iid = sel[0]
        r = next((x for x in self._quant_results
                  if x.get('hmdb_id', x['metabolite']) == iid), None)
        if r:
            try:
                self._draw_detail(r)
            except Exception as _e:
                import traceback, logging
                logging.getLogger(__name__).error(traceback.format_exc())
                print(f'[_draw_detail error] {_e}')
                traceback.print_exc()

    def _on_tree_motion(self, event):
        """Show tooltip with quality reasons when hovering the Quality column."""
        tree = self._tree
        iid = tree.identify_row(event.y)
        col = tree.identify_column(event.x)  # e.g. '#7'
        # Resolve column name from '#N' index
        col_name = ''
        if col and col.startswith('#'):
            try:
                col_idx = int(col[1:]) - 1
                all_cols = tree['columns']
                col_name = all_cols[col_idx] if 0 <= col_idx < len(all_cols) else ''
            except (ValueError, IndexError):
                pass
        if iid and col_name == 'status':
            if iid == self._tooltip_iid:
                return  # already showing for this row
            r = next((x for x in self._quant_results
                      if x.get('hmdb_id', x.get('metabolite')) == iid), None)
            if r:
                reasons = r.get('_status_reasons', [])
                text = '\n'.join(f'• {s}' for s in reasons) if reasons else '—'
                self._show_tooltip(event, text)
                self._tooltip_iid = iid
                return
        self._hide_tooltip()

    def _show_tooltip(self, event, text):
        self._hide_tooltip()
        x = self._tree.winfo_rootx() + event.x + 12
        y = self._tree.winfo_rooty() + event.y + 16
        self._tooltip_win = tw = tk.Toplevel(self._tree)
        tw.wm_overrideredirect(True)
        tk.Label(tw, text=text, justify=tk.LEFT,
                 background='#ffffcc', relief=tk.SOLID, borderwidth=1,
                 font=('Arial', 8), padx=6, pady=4).pack()
        self._clamp_tooltip(tw, x, y)

    def _hide_tooltip(self, event=None):
        if self._tooltip_win:
            self._tooltip_win.destroy()
            self._tooltip_win = None
        self._tooltip_iid = None

    # ── Card (matplotlib) tooltip ─────────────────────────────────────────────

    def _on_card_motion(self, event):
        if event.inaxes is not self._ax_card:
            self._hide_card_tooltip()
            return
        y_ax = event.ydata  # data coords (axis is off, so 0–1 = axes fraction via transAxes)
        # Convert display coords to axes fraction
        if event.x is None or event.y is None:
            return
        try:
            x_f, y_f = self._ax_card.transAxes.inverted().transform(
                (event.x, event.y))
        except Exception:
            return
        tip = None
        for (y_top, y_bot), text in self._card_row_tips.items():
            if y_bot <= y_f <= y_top:
                tip = text
                break
        if tip:
            self._show_card_tooltip(event, tip)
        else:
            self._hide_card_tooltip()

    def _clamp_tooltip(self, tw, x, y):
        """Clamp tooltip position to stay inside the app root window."""
        tw.update_idletasks()
        tw_w, tw_h = tw.winfo_width(), tw.winfo_height()
        root = self.app.root
        win_x, win_y = root.winfo_rootx(), root.winfo_rooty()
        win_w, win_h = root.winfo_width(), root.winfo_height()
        x = min(x, win_x + win_w - tw_w - 4)
        y = min(y, win_y + win_h - tw_h - 4)
        x = max(x, win_x + 4)
        y = max(y, win_y + 4)
        tw.wm_geometry(f'+{x}+{y}')

    def _show_card_tooltip(self, event, text):
        cw = self._cv_card.get_tk_widget()
        x = cw.winfo_rootx() + int(event.x) + 12
        y = cw.winfo_rooty() + (cw.winfo_height() - int(event.y)) + 4
        if self._card_tooltip_win and self._card_tooltip_win.winfo_exists():
            self._clamp_tooltip(self._card_tooltip_win, x, y)
            return
        self._card_tooltip_win = tw = tk.Toplevel(cw)
        tw.wm_overrideredirect(True)
        tk.Label(tw, text=text, justify=tk.LEFT,
                 background='#ffffcc', relief=tk.SOLID, borderwidth=1,
                 font=('Arial', 8), padx=6, pady=4).pack()
        self._clamp_tooltip(tw, x, y)

    def _hide_card_tooltip(self, event=None):
        if self._card_tooltip_win and self._card_tooltip_win.winfo_exists():
            self._card_tooltip_win.destroy()
        self._card_tooltip_win = None

    # ── Detail plot ───────────────────────────────────────────────────────────

    def _draw_detail(self, r):
        ppm_arr = self.app.ppm
        all_int = self.app.all_intensities
        si      = self.app.samples_info or []

        groups = {}
        n_s = all_int.shape[1] if (all_int is not None and all_int.ndim == 2) else 0
        for i, s in enumerate(si):
            lbl = s.get('label', 'Unknown')
            if str(s.get('type', lbl)).upper() != 'BLK':
                groups.setdefault(lbl, []).append(i)
        if not groups and n_s:
            groups = {'All': list(range(n_s))}

        _app_colors = getattr(self.app, 'group_colors', {})
        cmap = plt.cm.get_cmap('tab10', max(len(groups), 1))
        g_colors = {g: (_app_colors.get(g) or cmap(i))
                    for i, g in enumerate(groups)}

        p         = r.get('_peak') or self._find_peak(r.get('ppm', 0), tol=0.05)
        integ_mode = r.get('_integ_mode', 'Area')
        lorentz_p  = r.get('_lorentz')

        # ── Spectrum overlay ─────────────────────────────────────────────
        ax1 = self._ax_spec
        ax1.clear()
        ax1.set_facecolor('#fafafa')
        if ppm_arr is not None and all_int is not None and p:
            lo_i = min(p.get('start_idx', 0), p.get('end_idx', 0))
            hi_i = max(p.get('start_idx', 0), p.get('end_idx', 0))
            pad  = max(8, (hi_i - lo_i))
            lo_e = max(0, lo_i - pad)
            hi_e = min(len(ppm_arr) - 1, hi_i + pad)
            x_view = ppm_arr[lo_e:hi_e + 1]
            x_reg  = ppm_arr[lo_i:hi_i + 1]

            for g, idxs in groups.items():
                col = g_colors[g]
                ys  = [all_int[lo_e:hi_e+1, i] for i in idxs if i < n_s]
                for y_s in ys:
                    ax1.plot(x_view, y_s, color=col, lw=0.6, alpha=0.35)
                if ys:
                    gm = np.mean(ys, axis=0)
                    ax1.plot(x_view, gm, color=col, lw=1.8, alpha=0.95, label=g)

                    # ── Lorentzian fit curves (aligned per sample) ───────
                    if integ_mode == 'Lorentz':
                        s_idxs = [i for i in idxs if i < n_s]
                        if s_idxs and len(x_reg) >= 4:
                            # Use stored wid from _run if available, else refit
                            if lorentz_p:
                                wid_d = lorentz_p['wid']
                                cen_d = lorentz_p['cen']
                                stored_shifts = lorentz_p.get('shifts', [])
                            else:
                                y_gm_reg = np.mean(
                                    all_int[lo_i:hi_i+1, s_idxs], axis=1)
                                _, cen_d, wid_d = _fit_lorentz_mean(
                                    x_reg, y_gm_reg)
                                stored_shifts = []

                            max_shift = max(
                                abs(float(x_reg[-1] - x_reg[0])) * 0.15,
                                0.005)
                            x_fit = np.linspace(
                                float(x_reg.min()), float(x_reg.max()), 300)

                            # Draw individual aligned fits (thin, transparent)
                            for j, si_idx in enumerate(s_idxs):
                                y_s = all_int[lo_i:hi_i+1, si_idx]
                                if j < len(stored_shifts):
                                    cen_s = cen_d + stored_shifts[si_idx]
                                else:
                                    cen_s = _align_sample_center(
                                        x_reg, y_s, cen_d, max_shift)
                                A_s = _lorentz_amplitude(x_reg, y_s,
                                                         cen_s, wid_d)
                                y_s_fit = A_s * _lorentz_shape(
                                    x_fit, cen_s, wid_d)
                                ax1.plot(x_fit, y_s_fit, color=col,
                                         lw=0.8, ls='--', alpha=0.30)

                            # Draw group-mean aligned fit (bold)
                            y_gm_reg = np.mean(
                                all_int[lo_i:hi_i+1, s_idxs], axis=1)
                            cen_gm = _align_sample_center(
                                x_reg, y_gm_reg, cen_d, max_shift)
                            A_gm = _lorentz_amplitude(
                                x_reg, y_gm_reg, cen_gm, wid_d)
                            y_gm_fit = A_gm * _lorentz_shape(
                                x_fit, cen_gm, wid_d)
                            shift_hz = abs(cen_gm - cen_d) * 600  # ~600 MHz
                            ax1.plot(x_fit, y_gm_fit, color=col,
                                     lw=2.5, ls='--', alpha=0.95,
                                     label=(f'{g} fit  γ={wid_d*1000:.1f} mppm'
                                            f'  Δ={shift_hz:.1f} Hz'))

            # ── MCR-ALS profile overlay ──────────────────────────────────
            mcr_data = r.get('_mcr')
            if r.get('_used_mcr') and mcr_data is not None:
                S_vec = mcr_data['S']          # (n_pts_region,)
                m_lo  = mcr_data['lo_i']
                m_hi  = mcr_data['hi_i']
                x_mcr = ppm_arr[m_lo:m_hi+1]
                if len(x_mcr) == len(S_vec):
                    # Scale S to match mean spectrum amplitude in the region
                    y_mean_reg = np.mean(all_int[m_lo:m_hi+1, :], axis=1)
                    scale = (np.max(y_mean_reg) / (np.max(S_vec) + 1e-30))
                    y_mcr = S_vec * scale
                    ax1.plot(x_mcr, y_mcr, color='#e63946', lw=2.0,
                             ls='-', zorder=5,
                             label='MCR-ALS S (scaled)')
                    # Residual = mean − MCR profile
                    resid = y_mean_reg - y_mcr
                    ax1.plot(x_mcr, resid, color='#888888', lw=1.0,
                             ls=':', zorder=4, label='Residual')
                    ax1.axhline(0, color='#cccccc', lw=0.6, ls='-')
                    # Annotate metrics
                    met = mcr_data.get('metrics', {})
                    lof = met.get('lof', float('nan'))
                    r2  = met.get('r2',  float('nan'))
                    ni  = met.get('n_iter', '?')
                    ax1.text(0.02, 0.97,
                             f'LOF={lof:.2f}%  R²={r2:.4f}  iter={ni}',
                             transform=ax1.transAxes, fontsize=7,
                             va='top', color='#333',
                             bbox=dict(fc='white', alpha=0.7, lw=0))

            # Region fill (group mean, semi-transparent)
            for g, idxs in groups.items():
                s_idxs = [i for i in idxs if i < n_s]
                if s_idxs:
                    y_g = np.mean(all_int[lo_i:hi_i+1, s_idxs], axis=1)
                    ax1.fill_between(x_reg, 0, y_g,
                                     alpha=0.14, color=g_colors.get(g, '#888'))

            # Region boundary lines
            ppm_lo = float(ppm_arr[lo_i])
            ppm_hi = float(ppm_arr[hi_i])
            for xv in (ppm_lo, ppm_hi):
                ax1.axvline(xv, color='#1565C0', lw=1.0, ls='--', alpha=0.6)
            ax1.axvline(p['ppm'], color='#e63946', lw=0.9, ls=':', alpha=0.7)

            # Lock x-axis to view window; set high-ppm on left (NMR convention)
            v_lo = float(x_view.min())
            v_hi = float(x_view.max())
            ax1.set_xlim(v_hi, v_lo)

        ax1.set_xlabel('δ (ppm)', fontsize=8)
        ax1.set_ylabel('Intensity', fontsize=8)
        name  = r['metabolite']
        ppm_s = f"{p['ppm']:.4f}" if p else '?'
        ax1.set_title(f'{name}  {ppm_s} ppm  [{integ_mode}]',
                      fontsize=9, fontweight='bold')
        ax1.legend(fontsize=7, loc='upper right', framealpha=0.7)
        ax1.tick_params(labelsize=7)
        ax1.grid(True, alpha=0.2, ls=':')
        self._cv_spec.draw()

        # ── Bar chart ────────────────────────────────────────────────────
        ax2 = self._ax_bar
        ax2.clear()
        ax2.set_facecolor('#fafafa')
        norm_mode  = self.norm_var.get()
        concs_g    = r.get('_concs_by_group', {})
        # Non-BLK groups first, then BLK at end if present
        g_names    = [g for g in groups if g in concs_g]
        if 'BLK' in concs_g and 'BLK' not in g_names:
            g_names = g_names + ['BLK']
        y_label    = ('Conc (mM)'  if norm_mode == 'IS'
                      else 'Area %' if norm_mode == 'Total'
                      else 'Area (a.u.)')
        if g_names:
            means, sds, colors = [], [], []
            for g in g_names:
                vals = [c for c in concs_g[g] if np.isfinite(c) and c > 0]
                means.append(float(np.mean(vals)) if vals else 0)
                sds.append(float(np.std(vals))   if len(vals) > 1 else 0)
                colors.append(g_colors.get(g, '#888'))
            x_pos  = np.arange(len(g_names))
            hatches = ['///' if g == 'BLK' else '' for g in g_names]
            for xi, (m, e, c, h) in enumerate(zip(means, sds, colors, hatches)):
                ax2.bar(xi, m, yerr=e if e > 0 else None, color=c, alpha=0.55,
                        capsize=5, error_kw={'linewidth': 1.5},
                        edgecolor='black', linewidth=0.8, hatch=h)
            rng = np.random.default_rng(42)
            for i, g in enumerate(g_names):
                vals = [v for v in concs_g.get(g, []) if np.isfinite(v)]
                if vals:
                    jitter = rng.uniform(-0.18, 0.18, len(vals))
                    ax2.scatter(x_pos[i] + jitter, vals,
                                color=colors[i], s=28, alpha=0.9,
                                edgecolors='black', lw=0.5, zorder=4)
            ax2.set_ylim(bottom=0)
            ax2.set_xticks(x_pos)
            ax2.set_xticklabels(g_names, fontsize=8, rotation=20, ha='right')
            ax2.set_ylabel(y_label, fontsize=8)
            ax2.set_title('Mean ± SD per group', fontsize=8)
        else:
            ax2.text(0.5, 0.5, 'No group data', ha='center', va='center',
                     transform=ax2.transAxes, color='gray', fontsize=8)
        ax2.tick_params(labelsize=7)
        ax2.grid(True, axis='y', alpha=0.2, ls=':')
        self._cv_bar.draw()

        # ── Quality card (top) ───────────────────────────────────────────
        ax3 = self._ax_card
        ax3.clear()
        ax3.axis('off')
        conc      = r.get('conc_mm', float('nan'))
        stat      = r.get('status', 'good')
        cv_groups = r.get('cv_by_group', {})
        integ_lbl = {'Area': 'Trapz', 'Lorentz': 'Lorentz Fit'}.get(integ_mode, integ_mode)
        if r.get('_used_mcr'):
            integ_lbl = 'MCR-ALS'
        bg = '#f0fff0' if stat=='good' else '#fffde7' if stat=='warn' else '#fff0f0'
        ax3.set_facecolor(bg)
        ax3.set_title('Peak Info', fontsize=8, fontweight='bold', pad=3)

        ann_score = r.get('_ann_score', 0.0)
        ann_score_col = ('#1a7a1a' if ann_score >= 0.8
                         else '#856404' if ann_score >= 0.5 else '#9a0000')

        # Global SNR (mean across all non-BLK samples)
        _snr_global = r.get('snr', 0)
        _snr_col = ('#1a7a1a' if _snr_global > 10 else
                    '#856404' if _snr_global > 5 else '#9a0000')

        top_card = [
            ('Metabolite',   r['metabolite'],                                    '#333'),
            ('PPM',          f"{p['ppm']:.4f}" if p else '?',                  '#333'),
            ('Width',        f"{p.get('width_ppm',0):.4f} ppm" if p else '?', '#333'),
            ('Annot. Score', f"{ann_score:.3f}",                                ann_score_col),
            ('Integration',  integ_lbl,                                          '#555'),
            ('Norm',         norm_mode,                                          '#555'),
            ('Mean SNR',     f"{_snr_global:.1f}",                              _snr_col),
        ]
        if r.get('_used_mcr') and r.get('_mcr'):
            mcr_m   = r['_mcr'].get('metrics', {})
            lof     = mcr_m.get('lof', float('nan'))
            r2      = mcr_m.get('r2',  float('nan'))
            ni      = mcr_m.get('n_iter', '?')
            lof_col = ('#1a7a1a' if (np.isfinite(lof) and lof < 5)
                       else '#856404' if (np.isfinite(lof) and lof < 15)
                       else '#9a0000')
            r2_col  = ('#1a7a1a' if (np.isfinite(r2) and r2 > 0.99)
                       else '#856404' if (np.isfinite(r2) and r2 > 0.95)
                       else '#9a0000')
            top_card.append(('LOF',   f'{lof:.2f}%' if np.isfinite(lof) else 'N/A', lof_col))
            top_card.append(('R²',    f'{r2:.4f}'   if np.isfinite(r2)  else 'N/A', r2_col))
            top_card.append(('Iters', str(ni),                                       '#555'))
        if np.isfinite(conc):
            if norm_mode == 'IS':
                top_card.append(('Conc (mM)', f'{conc:.4f}', '#1a1a2e'))
            elif norm_mode == 'Total':
                top_card.append(('Area %',    f'{conc:.4f}', '#1a1a2e'))
            else:
                top_card.append(('Area (a.u.)', f'{conc:.3e}', '#555'))

        # Tooltips per row: map (y_top, y_bot) → hint text (axes coords)
        _CARD_TIPS = {
            'Metabolite':   'Name from the annotation database (HMDB/BMRB).',
            'PPM':          'Chemical shift of the detected peak centre (ppm).',
            'Width':        'Peak width at half-maximum (ppm).',
            'Annot. Score': 'Composite annotation score (0–1).\n'
                            'Combines multiplet pattern match + chemical shift\n'
                            'deviation + database confidence.',
            'Integration':  'Method used to compute peak area per sample.',
            'Norm':         'Normalisation applied before concentration calculation.',
            'Mean SNR':     'Mean signal-to-noise ratio across non-BLK samples.\n'
                            'SNR = peak max / noise level estimated at detection.',
            'LOF':          'Lack-of-Fit (MCR-ALS).\n'
                            'LOF = 100 × √(Σ(X−X̂)² / ΣX²)\n'
                            'Measures how well the model reconstructs the data.\n'
                            'Good: < 5%  |  Warn: 5–15%  |  Poor: > 15%',
            'R²':           'Coefficient of determination (MCR-ALS).\n'
                            'R² = 1 − SS_res / SS_tot\n'
                            'Good: > 0.99  |  Warn: 0.95–0.99  |  Poor: < 0.95',
            'Iters':        'Number of MCR-ALS iterations until convergence\n'
                            '(max 200). Fewer iterations = faster convergence.',
            'Conc (mM)':    'Mean concentration across non-BLK samples (mM).\n'
                            'C = (A_met / nH_met) / (A_IS / nH_IS) × C_IS × dil',
            'Area %':       'Mean area as % of total spectrum area (non-BLK).',
            'Area (a.u.)':  'Mean raw trapezoid area (arbitrary units, no IS norm).',
        }
        self._card_row_tips = {}   # (y_top, y_bot) → tip text
        y = 0.97
        row_h = 0.11
        for key, val, col in top_card:
            ax3.text(0.04, y, f'{key}:', fontsize=7.5,
                     fontweight='bold', color='#555',
                     transform=ax3.transAxes, va='top')
            ax3.text(0.50, y, val, fontsize=7.5, color=col,
                     transform=ax3.transAxes, va='top')
            tip = _CARD_TIPS.get(key)
            if tip:
                self._card_row_tips[(y, y - row_h)] = tip
            y -= row_h

        # ── Quality card (bottom) — per-group table ───────────────────────
        ax4 = self._ax_card_bot
        ax4.clear()
        ax4.axis('off')
        ax4.set_facecolor(bg)
        ax4.set_title('Groups', fontsize=7.5, fontweight='bold', pad=2)

        # Header row
        _conc_col_hdr = 'Conc (mM)' if norm_mode == 'IS' else ('Area %' if norm_mode == 'Total' else 'Area')
        hdr_cols = ['Group', _conc_col_hdr, 'CV%', 'SNR', 'Quality']
        hdr_x    = [0.01, 0.22, 0.50, 0.65, 0.80]
        for hx, ht in zip(hdr_x, hdr_cols):
            ax4.text(hx, 0.97, ht, fontsize=6.5, fontweight='bold', color='#333',
                     transform=ax4.transAxes, va='top')
        ax4.plot([0, 1], [0.91, 0.91], color='#aaa', lw=0.6,
                 transform=ax4.transAxes, clip_on=False)

        row_y = 0.87
        concs_g = r.get('_concs_by_group', {})
        _app_colors = getattr(self.app, 'group_colors', {})
        # Build BLK sample indices for SNR computation
        blk_si = [i for i, s in enumerate(si)
                  if str(s.get('type', s.get('label', ''))).upper() == 'BLK']
        # Estimate noise from global peak SNR (recover noise level)
        _global_snr = r.get('snr', 0) or 1
        _p_snr = p
        if _p_snr and ppm_arr is not None and all_int is not None:
            _lo = min(_p_snr.get('start_idx', 0), _p_snr.get('end_idx', 0))
            _hi = max(_p_snr.get('start_idx', 0), _p_snr.get('end_idx', 0))
            _peak_max_global = float(np.max(np.mean(all_int[_lo:_hi+1, :], axis=1))) if n_s else 1
            _noise_est = _peak_max_global / _global_snr if _global_snr > 0 else 1.0
        else:
            _noise_est = 1.0
        all_g = [g for g in groups] + (['BLK'] if 'BLK' in concs_g else [])
        for g in all_g:
            vals = concs_g.get(g, [])
            if not vals:
                continue
            g_mean = float(np.mean(vals))
            g_cv   = cv_groups.get(g, float('nan'))
            # Per-group SNR: mean spectrum of group samples in peak region
            g_idxs = groups.get(g) if g != 'BLK' else blk_si
            if (g_idxs and _p_snr and ppm_arr is not None and all_int is not None
                    and _lo < _hi):
                _g_idxs_valid = [i for i in g_idxs if i < n_s]
                if _g_idxs_valid:
                    g_mean_spec = np.mean(all_int[_lo:_hi+1, :][:, _g_idxs_valid], axis=1)
                    g_snr = float(np.max(g_mean_spec)) / _noise_est if _noise_est > 0 else 0
                else:
                    g_snr = 0.0
            else:
                g_snr = r.get('snr', 0)
            g_cv_v = cv_groups.get(g, float('nan'))
            # Per-group quality: CV% + SNR
            _g_crit = []
            if np.isfinite(g_cv_v):
                _g_crit.append(0 if g_cv_v < 20 else 1 if g_cv_v < 40 else 2)
            if g_snr > 0:
                _g_crit.append(0 if g_snr > 10 else 1 if g_snr > 5 else 2)
            _g_worst = max(_g_crit) if _g_crit else 1
            g_stat = ('Good' if _g_worst == 0 else 'Warn' if _g_worst == 1 else 'Poor')
            g_stat_col = ('#1a7a1a' if g_stat == 'Good'
                          else '#856404' if g_stat == 'Warn' else '#9a0000')
            g_col = _app_colors.get(g, '#333')
            if norm_mode == 'IS':
                conc_str = f'{g_mean:.3f}'
            elif norm_mode == 'Total':
                conc_str = f'{g_mean:.3f}'
            else:
                conc_str = f'{g_mean:.2e}'
            cv_str = f'{g_cv:.1f}%' if np.isfinite(g_cv) else 'N/A'
            row_vals = [g, conc_str, cv_str, f'{g_snr:.0f}', g_stat]
            row_cols = [g_col, '#1a1a2e', '#555', '#555', g_stat_col]
            for hx, rv, rc in zip(hdr_x, row_vals, row_cols):
                ax4.text(hx, row_y, rv, fontsize=6.5, color=rc,
                         transform=ax4.transAxes, va='top')
            row_y -= 0.13

        self._cv_card.draw()

    # ── Integration mode change ───────────────────────────────────────────────

    def _on_integ_change(self, *_):
        if self.integ_var.get() == 'Lorentz':
            self.mcr_var.set(False)
            self._mcr_cb.config(state='disabled')
        else:
            self._mcr_cb.config(state='normal')

    # ── Standard preset ───────────────────────────────────────────────────────

    def _on_std_select(self, event=None):
        p = _STD_PRESETS.get(self.ref_std_var.get(), {})
        if p.get('ppm'): self.ref_ppm_var.set(p['ppm'])
        if p.get('nh'):  self.ref_nh_var.set(p['nh'])

    def _open_ext_is_dialog(self):
        """Open dialog to select External IS samples."""
        si = self.app.samples_info or []
        if not si:
            messagebox.showinfo('External IS', 'Load samples first.')
            return

        dlg = tk.Toplevel(self.frame)
        dlg.title('Select External IS Samples')
        dlg.geometry('320x400')
        dlg.transient(self.frame)
        dlg.grab_set()

        ttk.Label(dlg, text='Select samples to use as External IS reference:',
                  font=('Arial', 9), wraplength=280).pack(pady=(10, 4), padx=10)

        frame_list = ttk.Frame(dlg)
        frame_list.pack(fill=tk.BOTH, expand=True, padx=10, pady=4)
        vsb = ttk.Scrollbar(frame_list)
        vsb.pack(side=tk.RIGHT, fill=tk.Y)
        lb = tk.Listbox(frame_list, selectmode=tk.MULTIPLE,
                        yscrollcommand=vsb.set, font=('Arial', 9))
        lb.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        vsb.config(command=lb.yview)

        for i, s in enumerate(si):
            lbl  = s.get('label', f'Sample {i+1}')
            typ  = s.get('type', '')
            disp = f"{i+1}. {lbl}" + (f"  [{typ}]" if typ else '')
            lb.insert(tk.END, disp)
            if i in self._ext_is_indices:
                lb.selection_set(tk.END)

        # Pre-select BLK samples by default if none selected yet
        if not self._ext_is_indices:
            for i, s in enumerate(si):
                if str(s.get('type', s.get('label', ''))).upper() == 'BLK':
                    lb.selection_set(i)

        btn_row = ttk.Frame(dlg)
        btn_row.pack(fill=tk.X, padx=10, pady=8)

        def _ok():
            self._ext_is_indices = list(lb.curselection())
            n = len(self._ext_is_indices)
            names = ', '.join(str(si[i].get('label', i)) for i in self._ext_is_indices[:3])
            suffix = '…' if n > 3 else ''
            self._ext_is_label.config(
                text=f'{n} sample(s): {names}{suffix}' if n else '(none selected)',
                foreground='#1a7a1a' if n else 'gray')
            dlg.destroy()

        ttk.Button(btn_row, text='OK',     command=_ok).pack(side=tk.RIGHT, padx=4)
        ttk.Button(btn_row, text='Cancel', command=dlg.destroy).pack(side=tk.RIGHT)

    # ── Core quantification ───────────────────────────────────────────────────

    def _run(self):
        # ── Detect which pipeline produced results ────────────────────────────
        _fs_stage   = (getattr(self.app, 'stages', {}) or {}).get('fullspectrum_mcr')
        _fs_regions = getattr(_fs_stage, '_mcr_regions', []) if _fs_stage else []
        _fs_mode    = bool(_fs_regions)   # True = Full Spectrum MCR pipeline

        if not _fs_mode:
            # Legacy annotation pipeline
            if not hasattr(self.annotation_stage, '_last_results_args') or \
                    not self.annotation_stage._last_results_args:
                messagebox.showinfo(
                    'Info',
                    'No results found.\n\n'
                    'Run "Full Spectrum MCR" (step 2) or\n'
                    'use the advanced Annotation stage first.')
                return
            args    = self.annotation_stage._last_results_args or {}
            results = args.get('results', [])
            if not results:
                messagebox.showinfo('Info', 'Annotation results are empty.')
                return
        else:
            # Full Spectrum MCR mode: results built entirely from MCR confirmed assignments
            results = []

        _integ      = self.integ_var.get()
        use_area    = (_integ == 'Area')
        use_lorentz = (_integ == 'Lorentz')
        proton_corr = self.proton_corr_var.get()
        use_mcr     = self.mcr_var.get()
        use_blk_sub = self.blk_sub_var.get()
        norm_mode   = self.norm_var.get()

        # Confirm External IS usage
        if self.ext_is_var.get() and self._ext_is_indices:
            if not messagebox.askyesno(
                    'External IS — Confirm',
                    'External IS mode is active.\n\n'
                    'Please confirm that the IS concentration and nH are the same\n'
                    'for both the External IS samples and the analytical samples.\n\n'
                    'Proceed with quantification?'):
                return

        # Resolve IS reference
        ref_peak = None
        try:
            rank = int(self.ref_rank_var.get())
            ref_peak = next((p for p in (self.peak_stage.peaks or [])
                             if p.get('rank') == rank), None)
        except (ValueError, TypeError):
            pass
        if ref_peak is None:
            try:
                ref_peak = self._find_peak(
                    float(self.ref_ppm_var.get()), tol=0.05)
            except ValueError:
                pass
        self.ref_peak = ref_peak   # store for Peak View IS label

        try:   ref_conc = float(self.ref_conc_var.get())
        except ValueError: ref_conc = 1.0
        try:   ref_nh = max(1, int(self.ref_nh_var.get()))
        except ValueError: ref_nh = 9

        try:
            _spec_mhz = float(self.annotation_stage.spectrometer_var.get())
        except Exception:
            _spec_mhz = 600.0

        ppm_arr = self.app.ppm
        all_int = self.app.all_intensities
        si      = self.app.samples_info or []
        if ppm_arr is None or all_int is None or all_int.ndim < 2:
            messagebox.showinfo('Info', 'No spectral data loaded.')
            return

        n_s = all_int.shape[1]

        # Build groups (non-BLK for statistics; BLK tracked separately)
        groups = {}
        blk_indices = []
        for i, s in enumerate(si):
            lbl = s.get('label', 'Unknown')
            if i >= n_s:
                continue
            if str(s.get('type', lbl)).upper() == 'BLK':
                blk_indices.append(i)
            else:
                groups.setdefault(lbl, []).append(i)
        if not groups:
            groups = {'All': list(range(n_s))}
        non_blk_indices = [i for g_idxs in groups.values() for i in g_idxs]

        # Per-group dilution factors
        _app_dil = getattr(self.app, 'group_dilution_factors', {})
        # Build per-sample dilution factor array
        _sample_dil = np.ones(n_s)
        for i, s in enumerate(si):
            if i < n_s:
                lbl = s.get('label', 'Unknown')
                _sample_dil[i] = _app_dil.get(lbl, 1.0)

        # IS area per sample (or fixed from External IS samples)
        use_ext_is  = self.ext_is_var.get() and bool(self._ext_is_indices)
        ref_areas   = None
        if ref_peak is not None:
            lo_r = min(ref_peak.get('start_idx', 0), ref_peak.get('end_idx', 0))
            hi_r = max(ref_peak.get('start_idx', 0), ref_peak.get('end_idx', 0))
            if use_ext_is:
                # Fixed reference: mean IS area across External IS samples
                ext_areas = []
                for s in self._ext_is_indices:
                    if s < n_s:
                        a = abs(float(_trapz(all_int[lo_r:hi_r+1, s],
                                             ppm_arr[lo_r:hi_r+1])))
                        ext_areas.append(a / ref_nh)
                if ext_areas:
                    _fixed_ref = float(np.mean(ext_areas))
                    ref_areas = [_fixed_ref] * n_s
                else:
                    use_ext_is = False
            if not use_ext_is:
                ref_areas = []
                for s in range(n_s):
                    a = abs(float(_trapz(all_int[lo_r:hi_r+1, s],
                                         ppm_arr[lo_r:hi_r+1])))
                    ref_areas.append(a / ref_nh)

        # ── Resolve one winner metabolite per detected peak ───────────────────
        # Rule: for every peak_rank, at most ONE metabolite is quantified.
        # Priority per peak_rank:
        #   1. Metabolite whose parent row is marked Good  (_quality_marks)
        #   2. If no Good mark exists, skip that peak entirely
        #      (user has not decided yet — don't guess)
        # Exception: if NO quality marks exist at all (fresh run), use the
        #            highest-score candidate for each peak as a convenience.
        quality_marks = getattr(self.annotation_stage, '_quality_marks', {}) or {}
        child_qm      = getattr(self.annotation_stage, '_child_quality_marks', {}) or {}
        has_any_marks = bool(quality_marks) or bool(child_qm)

        # Index results by peak_rank → list of hits
        by_peak = {}
        for r in results:
            mid = r.get('hmdb_id') or r.get('bmrb_id') or r.get('id', r.get('name', 'unknown'))
            r['_mid'] = mid
            pr = r.get('peak_rank')
            by_peak.setdefault(pr, []).append(r)

        # For each peak, pick the winning hit
        winning_hits = []   # list of result dicts that survived selection
        for pr, candidates in by_peak.items():
            if has_any_marks:
                # Only accept a hit if its metabolite is marked Good for this peak
                good_hits = [
                    h for h in candidates
                    if quality_marks.get((h['_mid'], pr)) == 'good'
                ]
                if not good_hits:
                    # No one was marked Good for this peak → skip it
                    continue
                # Among Good hits for this peak, keep the one with the highest score
                best = max(good_hits,
                           key=lambda h: float(h.get('composite_score',
                                                      h.get('multiplet_score', 0)) or 0))
                winning_hits.append(best)
            else:
                # No marks at all → take the highest-score candidate (convenience)
                best = max(candidates,
                           key=lambda h: float(h.get('composite_score',
                                                      h.get('multiplet_score', 0)) or 0))
                winning_hits.append(best)

        if not winning_hits and not _fs_mode:
            messagebox.showwarning(
                'No Good Assignments',
                'No peaks are marked as Good in Annotation Results.\n\n'
                'Open Annotation Results, select the correct metabolite '
                'for each peak and press Ctrl+1 (Good) before quantifying.')
            return

        # Build met_map: one metabolite → exactly ONE hit (best peak)
        # If the same metabolite won multiple peaks, pick the single best:
        # criterion = fewest competitors at that peak_rank, then highest score.
        # Count how many metabolites share each peak_rank across all results
        peak_competitor_count = {}
        for r in results:
            pr = r.get('peak_rank')
            if pr is not None:
                peak_competitor_count[pr] = peak_competitor_count.get(pr, 0) + 1

        tmp_map = {}
        for h in winning_hits:
            mid = h['_mid']
            tmp_map.setdefault(mid, {'name': h.get('name', mid), 'hits': []})
            tmp_map[mid]['hits'].append(h)

        met_map = {}
        for mid, info in tmp_map.items():
            if len(info['hits']) == 1:
                met_map[mid] = {'name': info['name'], 'hits': info['hits']}
            else:
                # Multiple Good peaks for this metabolite → pick the single best
                best = min(
                    info['hits'],
                    key=lambda h: (
                        peak_competitor_count.get(h.get('peak_rank'), 1),   # fewer competitors first
                        -float(h.get('composite_score',
                                     h.get('multiplet_score', 0)) or 0),   # higher score first
                    ))
                met_map[mid] = {'name': info['name'], 'hits': [best]}

        raw_areas = {}
        meta_info = {}

        # ── Inject confirmed MCR components as individual analytes ──────────────
        # Covers both: (a) peak-detection peaks with MCR annotation, and
        #              (b) full-spectrum MCR virtual peaks.
        _mcr_overridden_peaks = set()  # peak ranks whose area is handled by MCR
        _all_mcr_peaks = list(self.peak_stage.peaks or []) + list(_fs_regions)
        for pk in _all_mcr_peaks:
            mcr_ann   = pk.get('mcr_annotation')
            if not mcr_ann:
                continue
            confirmed = mcr_ann.get('confirmed_assignments', {})
            if not confirmed:
                continue
            accepted_ks = [k for k, v in confirmed.items() if v and v.get('accepted')]
            if not accepted_ks:
                continue

            K_ann    = mcr_ann['K']
            S_mat    = mcr_ann['S']           # (n_pts_reg, K)
            C_mat    = mcr_ann['C']           # (n_samples_ann, K)
            ppm_reg  = mcr_ann['ppm_region']  # (n_pts_reg,)
            cands    = mcr_ann.get('candidates', [])
            assigns  = mcr_ann.get('assignments', [])
            K_actual = min(K_ann, S_mat.shape[1])

            for k in accepted_ks:
                if k >= K_actual:
                    continue
                cv        = confirmed[k]
                ci        = assigns[k][0] if k < len(assigns) else 0
                cand      = cands[ci] if ci < len(cands) else {}
                cid       = cv.get('hmdb_id') or cand.get('hmdb_id') or \
                            cand.get('bmrb_id') or f'mcr_{pk["rank"]}_{k}'
                cname     = cv.get('metabolite') or cand.get('name') or f'MCR C{k+1}'

                # Area per sample = ∫S[:,k] dppm × C[s,k]
                s_area_scale = abs(float(_trapz(S_mat[:, k], ppm_reg)))
                if C_mat.shape[0] == n_s:
                    a_vec = C_mat[:, k] * (s_area_scale if s_area_scale > 1e-15 else 1.0)
                else:
                    # MCR was run on fewer samples (e.g., mean only) — use mean C
                    c_mean_k = float(np.mean(C_mat[:, k]))
                    a_vec    = np.full(n_s, c_mean_k * (s_area_scale if s_area_scale > 1e-15 else 1.0))
                a_vec = np.abs(a_vec)

                # Proton correction using annotation hit if available
                _nh_k = 1
                if cid in met_map and met_map[cid].get('hits'):
                    h0      = met_map[cid]['hits'][0]
                    det_ppm = float(h0.get('peak_ppm', h0.get('ppm', pk['ppm'])))
                    try:
                        _spec_mhz_l = float(self.annotation_stage.spectrometer_var.get())
                    except Exception:
                        _spec_mhz_l = 600.0
                    _nh_k = max(1, _effective_nh(h0, det_ppm, _spec_mhz_l))
                if proton_corr and _nh_k > 0:
                    a_vec = a_vec / _nh_k

                raw_areas[cid] = a_vec
                meta_info[cid] = {
                    'name':          cname,
                    'hits':          met_map.get(cid, {}).get('hits', []),
                    '_peak':         pk,
                    '_used_mcr':     True,
                    '_mcr':          {
                        'S':       S_mat[:, k],
                        'lo_i':    int(np.argmin(np.abs(ppm_arr - ppm_reg.max()))),
                        'hi_i':    int(np.argmin(np.abs(ppm_arr - ppm_reg.min()))),
                        'metrics': mcr_ann.get('metrics', {}),
                    },
                    '_lorentz':      None,
                    '_ann_score':    cv.get('corr', 0.0),
                    '_nh':           _nh_k,
                    '_blk_mean_area': 0.0,
                    '_mcr_component': True,
                }
                _mcr_overridden_peaks.add(pk['rank'])
                # Remove from met_map so normal loop doesn't reprocess it
                met_map.pop(cid, None)

        # Remove any met_map entry whose peak was fully handled by MCR
        met_map = {mid: info for mid, info in met_map.items()
                   if info.get('hits') and
                   info['hits'][0].get('peak_rank') not in _mcr_overridden_peaks}

        _lorentz_params = {}
        _mcr_info       = {}

        for mid, info in met_map.items():
            # Per-sample areas (sum over all hits for this metabolite)
            s_areas = np.zeros(n_s)
            found   = False
            for hit in info['hits']:
                p = self._find_peak(hit.get('peak_ppm', hit.get('ppm', 0)))
                if p is None:
                    continue
                found = True
                lo_i = min(p.get('start_idx', 0), p.get('end_idx', 0))
                hi_i = max(p.get('start_idx', 0), p.get('end_idx', 0))
                detected_ppm = float(hit.get('peak_ppm', hit.get('ppm', p.get('ppm', 0))))
                nh = _effective_nh(hit, detected_ppm, _spec_mhz)
                nh = max(0.01, nh)

                if use_area and 'area_per_sample' in p:
                    a_vec = np.array(p['area_per_sample'])
                    if len(a_vec) < n_s:
                        a_vec = np.pad(a_vec, (0, n_s - len(a_vec)))
                    elif len(a_vec) > n_s:
                        a_vec = a_vec[:n_s]
                elif use_lorentz and (hi_i - lo_i) >= 1:
                    x_r      = ppm_arr[lo_i:hi_i + 1]
                    # Step 1: fit Lorentzian on mean → optimised shape
                    y_mean_r = np.mean(all_int[lo_i:hi_i+1, :], axis=1)
                    _, cen_l, wid_l = _fit_lorentz_mean(x_r, y_mean_r)
                    # Step 2: per-sample alignment + NNLS
                    #   Each sample may have a micro-shift in chemical shift
                    #   (pH, T, ionic-strength).  Find each sample's peak centre
                    #   within ±max_shift of the mean centre, then evaluate the
                    #   Lorentzian at that shifted position before NNLS.
                    #   area = A * π * wid  (analytical Lorentzian area).
                    max_shift = max(abs(float(x_r[-1] - x_r[0])) * 0.15,
                                   0.005)   # ≤15 % of window, min 0.005 ppm
                    shifts = []
                    a_list = []
                    for s in range(n_s):
                        y_s   = all_int[lo_i:hi_i+1, s]
                        cen_s = _align_sample_center(x_r, y_s, cen_l,
                                                     max_shift_ppm=max_shift)
                        A_s   = _lorentz_amplitude(x_r, y_s, cen_s, wid_l)
                        a_list.append(A_s * (np.pi * wid_l))
                        shifts.append(cen_s - cen_l)
                    a_vec = np.array(a_list)
                    _lorentz_params[mid] = {
                        'cen':    cen_l, 'wid': wid_l,
                        'shifts': shifts,            # per-sample δ shift (ppm)
                    }
                elif use_mcr and (hi_i - lo_i) >= 3:
                    X = all_int[lo_i:hi_i+1, :]  # (pts, samples)
                    try:
                        C, S_mcr, mcr_metrics = _mcr_als(X, n_components=1)
                        # S_mcr is unit-norm; scale C so output is in area units
                        # (same units as trapz) by multiplying by ∫S·dppm
                        s_area_scale = abs(float(
                            _trapz(S_mcr[:, 0], ppm_arr[lo_i:hi_i+1])))
                        a_vec = C[:, 0] * (s_area_scale if s_area_scale > 0 else 1.0)
                        _mcr_info[mid] = {
                            'S':       S_mcr[:, 0],
                            'lo_i':    lo_i,
                            'hi_i':    hi_i,
                            'metrics': mcr_metrics,
                        }
                    except Exception:
                        a_vec = np.array([
                            abs(float(_trapz(all_int[lo_i:hi_i+1, s],
                                             ppm_arr[lo_i:hi_i+1])))
                            for s in range(n_s)])
                else:
                    a_vec = np.array([
                        abs(float(_trapz(all_int[lo_i:hi_i+1, s],
                                         ppm_arr[lo_i:hi_i+1])))
                        for s in range(n_s)])

                # ── Per-sample region overrides (from Peak View adjustments) ──
                sample_regions = p.get('sample_regions', {})
                if sample_regions:
                    mcr_s   = _mcr_info.get(mid)
                    s_vec   = mcr_s['S']       if mcr_s else None
                    o_lo_i  = mcr_s['lo_i']    if mcr_s else lo_i
                    o_hi_i  = mcr_s['hi_i']    if mcr_s else hi_i
                    s_scale = (abs(float(_trapz(s_vec, ppm_arr[o_lo_i:o_hi_i+1])))
                               if s_vec is not None else 1.0)

                    for s_idx, adj in sample_regions.items():
                        if not isinstance(s_idx, int) or s_idx >= n_s:
                            continue
                        lo_s = adj.get('start_ppm', ppm_arr[lo_i])
                        hi_s = adj.get('end_ppm',   ppm_arr[hi_i])
                        lo_s, hi_s = min(lo_s, hi_s), max(lo_s, hi_s)
                        sm = (ppm_arr >= lo_s) & (ppm_arr <= hi_s)
                        if not sm.any():
                            continue
                        col_s  = all_int[sm, s_idx]
                        ppm_s  = ppm_arr[sm]

                        if use_mcr and s_vec is not None:
                            s_lo = max(0, np.where(sm)[0].min() - o_lo_i)
                            s_hi = min(len(s_vec) - 1,
                                       np.where(sm)[0].max() - o_lo_i)
                            if s_hi > s_lo:
                                sv   = s_vec[s_lo:s_hi+1]
                                cv   = col_s[:len(sv)]
                                den  = float(sv @ sv)
                                C_s  = max(0.0, float(sv @ cv) / den) if den > 1e-12 else 0.0
                                a_vec[s_idx] = C_s * (s_scale if s_scale > 1e-12 else 1.0)
                            else:
                                a_vec[s_idx] = abs(float(_trapz(col_s, ppm_s))) if col_s.size > 1 else 0.0
                        elif use_lorentz:
                            try:
                                _, cen_l2, wid_l2 = _fit_lorentz_mean(ppm_s, col_s)
                                A_s2 = _lorentz_amplitude(ppm_s, col_s, cen_l2, wid_l2)
                                a_vec[s_idx] = float(A_s2) * (np.pi * float(wid_l2))
                            except Exception:
                                a_vec[s_idx] = abs(float(_trapz(col_s, ppm_s))) if col_s.size > 1 else 0.0
                        else:
                            a_vec[s_idx] = abs(float(_trapz(col_s, ppm_s))) if col_s.size > 1 else 0.0

                if proton_corr:
                    a_vec = a_vec / nh
                # Blank correction: subtract mean of BLK samples
                _blk_mean_area = 0.0
                if use_blk_sub and blk_indices:
                    _blk_mean_area = float(np.mean([a_vec[i] for i in blk_indices
                                                    if i < len(a_vec)]))
                    a_vec = a_vec - _blk_mean_area
                s_areas += a_vec
                # Best annotation score for this metabolite
                _ann_score = max(
                    (float(h.get('composite_score', h.get('multiplet_score', 0)) or 0)
                     for h in info['hits']), default=0.0)
                meta_info[mid] = {'name': info['name'], 'hits': info['hits'],
                                  '_peak': p, '_used_mcr': use_mcr and found,
                                  '_lorentz': _lorentz_params.get(mid),
                                  '_mcr': _mcr_info.get(mid),
                                  '_ann_score': _ann_score,
                                  '_nh': nh,
                                  '_blk_mean_area': _blk_mean_area}

            if not found:
                continue
            raw_areas[mid] = s_areas   # shape (n_s,)

        if not raw_areas:
            if _fs_mode:
                messagebox.showinfo(
                    'Info',
                    'Nenhum componente MCR foi aceito.\n\n'
                    'Abra a janela MCR Deconvolution, selecione as regiões\n'
                    'e clique em "✓ Aceitar" nos componentes desejados.')
            else:
                messagebox.showinfo('Info', 'No peaks matched annotation results.')
            return

        # PQN
        if norm_mode == 'PQN':
            mean_areas = {mid: float(np.mean(v)) for mid, v in raw_areas.items()}
            ref_for_pqn = dict(mean_areas)
            normed, self._pqn_factor = _pqn(mean_areas, ref_for_pqn)
            for mid in raw_areas:
                if mid in normed:
                    scale = normed[mid] / (mean_areas[mid] + 1e-12)
                    raw_areas[mid] = raw_areas[mid] * scale
        elif norm_mode == 'Total':
            totals = np.sum(np.stack(list(raw_areas.values())), axis=0)
            totals[totals == 0] = 1
            for mid in raw_areas:
                raw_areas[mid] = raw_areas[mid] / totals * 100

        # Store run-time parameters needed for per-sample update later
        self._last_norm_mode      = norm_mode
        self._last_ref_areas      = list(ref_areas) if ref_areas is not None else None
        self._last_ref_conc       = ref_conc
        self._last_sample_dil     = np.array(_sample_dil, dtype=float)
        self._last_groups         = dict(groups)
        self._last_blk_indices    = list(blk_indices) if blk_indices else []
        self._last_non_blk_indices = list(non_blk_indices) if non_blk_indices else []

        # Compute concentrations per sample
        self._quant_results = []
        for mid, s_areas in raw_areas.items():
            m    = meta_info.get(mid, {})
            p    = m.get('_peak')

            # Per-sample conc (IS ratio × C_IS × dilution_factor)
            if norm_mode == 'IS' and ref_areas is not None:
                s_concs = np.array([
                    (s_areas[s] / ref_areas[s] * ref_conc * _sample_dil[s]
                     if ref_areas[s] > 0 else float('nan'))
                    for s in range(n_s)])
            else:
                s_concs = np.array(s_areas, dtype=float) * _sample_dil

            # CV and mean per group (non-BLK only)
            cv_by_group    = {}
            concs_by_group = {}
            for g, idxs in groups.items():
                vals = [float(s_concs[i]) for i in idxs
                        if i < n_s and np.isfinite(s_concs[i]) and s_concs[i] > 0]
                cv_by_group[g]    = _cv(vals)
                concs_by_group[g] = vals

            # BLK group (reference, separate from statistics)
            if blk_indices:
                blk_vals = [float(s_concs[i]) for i in blk_indices
                            if i < n_s and np.isfinite(s_concs[i]) and s_concs[i] > 0]
                if blk_vals:
                    concs_by_group['BLK'] = blk_vals
                    cv_by_group['BLK']    = _cv(blk_vals)

            # Overall mean (across non-BLK samples only)
            all_vals = [v for g, vv in concs_by_group.items()
                        if g != 'BLK' for v in vv
                        if np.isfinite(v) and v > 0]
            mean_conc = float(np.mean(all_vals)) if all_vals else float('nan')

            # Status: combined LOF + R² + CV% + SNR
            _mcr_met  = (m.get('_mcr') or {}).get('metrics', {})
            _lof      = _mcr_met.get('lof', float('nan'))
            _r2       = _mcr_met.get('r2',  float('nan'))
            cvs_finite = [v for g, v in cv_by_group.items()
                          if g != 'BLK' and np.isfinite(v)]
            worst_cv   = max(cvs_finite) if cvs_finite else float('nan')
            # Mean SNR across non-BLK samples in peak region
            _mean_snr = p.get('snr', 0) if p else 0
            if p and ppm_arr is not None and all_int is not None:
                _lo_i = min(p.get('start_idx', 0), p.get('end_idx', 0))
                _hi_i = max(p.get('start_idx', 0), p.get('end_idx', 0))
                _noise_lvl = p.get('noise', None)
                if _noise_lvl is None and p.get('snr', 0) > 0:
                    _peak_max_all = float(np.max(np.mean(all_int[_lo_i:_hi_i+1, :], axis=1)))
                    _noise_lvl = _peak_max_all / p['snr']
                if _noise_lvl and _noise_lvl > 0 and non_blk_indices:
                    _snrs = []
                    for _si in non_blk_indices:
                        if _si < n_s:
                            _pm = float(np.max(all_int[_lo_i:_hi_i+1, _si]))
                            _snrs.append(_pm / _noise_lvl)
                    if _snrs:
                        _mean_snr = float(np.mean(_snrs))

            # Status: combined LOF + R² + CV% + SNR (with reasons)
            _criteria = []
            _reasons  = []
            if np.isfinite(worst_cv):
                _s = 0 if worst_cv < 20 else 1 if worst_cv < 40 else 2
                _criteria.append(_s)
                _lbl = 'Good' if _s == 0 else 'Warn' if _s == 1 else 'Poor'
                _thr = '< 20%' if _s == 0 else '20–40%' if _s == 1 else '> 40%'
                _reasons.append(f'CV%: {worst_cv:.1f}%  →  {_lbl} ({_thr})')
            if np.isfinite(_lof):
                _s = 0 if _lof < 5 else 1 if _lof < 15 else 2
                _criteria.append(_s)
                _lbl = 'Good' if _s == 0 else 'Warn' if _s == 1 else 'Poor'
                _thr = '< 5%' if _s == 0 else '5–15%' if _s == 1 else '> 15%'
                _reasons.append(f'LOF: {_lof:.1f}%  →  {_lbl} ({_thr})')
            if np.isfinite(_r2):
                _s = 0 if _r2 > 0.99 else 1 if _r2 > 0.95 else 2
                _criteria.append(_s)
                _lbl = 'Good' if _s == 0 else 'Warn' if _s == 1 else 'Poor'
                _thr = '> 0.99' if _s == 0 else '0.95–0.99' if _s == 1 else '< 0.95'
                _reasons.append(f'R²: {_r2:.4f}  →  {_lbl} ({_thr})')
            if _mean_snr > 0:
                _s = 0 if _mean_snr > 10 else 1 if _mean_snr > 5 else 2
                _criteria.append(_s)
                _lbl = 'Good' if _s == 0 else 'Warn' if _s == 1 else 'Poor'
                _thr = '> 10' if _s == 0 else '5–10' if _s == 1 else '< 5'
                _reasons.append(f'SNR: {_mean_snr:.1f}  →  {_lbl} ({_thr})')
            _worst = max(_criteria) if _criteria else 1
            status = ('good' if _worst == 0 else 'warn' if _worst == 1 else 'poor')
            if not _reasons:
                _reasons = ['All parameters within good range']

            self._quant_results.append({
                'metabolite':        m.get('name', mid),
                'hmdb_id':           mid,
                'ppm':               p['ppm'] if p else 0.0,
                'n_peaks':           len(m.get('hits', [])),
                'raw_area':          float(np.mean(s_areas)),
                'corr_area':         float(np.mean(s_areas)),
                'conc_mm':           mean_conc,
                'cv_by_group':       cv_by_group,
                'snr':               _mean_snr,
                'status':            status,
                '_status_reasons':   _reasons,
                '_peak':             p,
                '_areas_per_sample': s_areas.tolist(),
                '_concs_per_sample': s_concs.tolist(),
                '_concs_by_group':   concs_by_group,
                '_used_mcr':         m.get('_used_mcr', False),
                '_lorentz':          m.get('_lorentz'),
                '_mcr':              m.get('_mcr'),
                '_integ_mode':       _integ,
                '_ann_score':        m.get('_ann_score', 0.0),
                '_nh':               m.get('_nh', 1.0),
                '_blk_mean_area':    m.get('_blk_mean_area', 0.0),
                '_proton_corr':      proton_corr,
                '_use_blk_sub':      use_blk_sub,
            })

        # Add IS peak as analyte (concentration in analytical samples)
        if ref_peak is not None and norm_mode == 'IS' and ref_areas is not None:
            lo_r = min(ref_peak.get('start_idx', 0), ref_peak.get('end_idx', 0))
            hi_r = max(ref_peak.get('start_idx', 0), ref_peak.get('end_idx', 0))
            is_areas_raw = np.array([
                abs(float(_trapz(all_int[lo_r:hi_r+1, s], ppm_arr[lo_r:hi_r+1])))
                for s in range(n_s)])
            # IS-as-analyte: dilution factor NOT applied — IS was added at known
            # concentration directly to the NMR tube; dil corrects the sample
            # matrix, not the IS amount.  Result should equal ref_conc (QC check).
            is_concs = np.array([
                ((is_areas_raw[s] / ref_nh) / ref_areas[s] * ref_conc
                 if ref_areas[s] > 0 else float('nan'))
                for s in range(n_s)])
            is_cv_by_group    = {}
            is_concs_by_group = {}
            for g, idxs in groups.items():
                vals = [float(is_concs[i]) for i in idxs
                        if i < n_s and np.isfinite(is_concs[i]) and is_concs[i] > 0]
                is_cv_by_group[g]    = _cv(vals)
                is_concs_by_group[g] = vals
            is_all_vals = [v for g, vv in is_concs_by_group.items()
                           if g != 'BLK' for v in vv if np.isfinite(v) and v > 0]
            is_mean_conc = float(np.mean(is_all_vals)) if is_all_vals else float('nan')
            is_cvs = [v for v in is_cv_by_group.values() if np.isfinite(v)]
            is_worst_cv = max(is_cvs) if is_cvs else float('nan')
            is_status = ('good' if np.isfinite(is_worst_cv) and is_worst_cv < 20
                         else 'warn' if np.isfinite(is_worst_cv) and is_worst_cv < 40
                         else 'poor')
            _is_name = self.ref_std_var.get() or 'IS'
            self._quant_results.append({
                'metabolite':        f'{_is_name} [IS]',
                'hmdb_id':           '__IS__',
                'ppm':               ref_peak.get('ppm', 0.0),
                'n_peaks':           1,
                'raw_area':          float(np.mean(is_areas_raw)),
                'corr_area':         float(np.mean(is_areas_raw)),
                'conc_mm':           is_mean_conc,
                'cv_by_group':       is_cv_by_group,
                'snr':               ref_peak.get('snr', 0),
                'status':            is_status,
                '_peak':             ref_peak,
                '_concs_per_sample': is_concs.tolist(),
                '_concs_by_group':   is_concs_by_group,
                '_used_mcr':         False,
                '_lorentz':          None,
                '_mcr':              None,
                '_integ_mode':       _integ,
                '_ann_score':        1.0,
                '_is_is':            True,
            })

        self._quant_results.sort(
            key=lambda r: r['conc_mm'] if np.isfinite(r['conc_mm']) else 0,
            reverse=True)

        note = (f' PQN×{self._pqn_factor:.3f}' if norm_mode == 'PQN' else '')
        mcr_note = (' +MCR' if use_mcr else ' +Lorentz' if use_lorentz else '')
        self.run_status.config(
            text=f'{len(self._quant_results)} metabolites '
                 f'[{norm_mode}{note}{mcr_note}]',
            foreground='green')
        self.btn_csv.config(state='normal')
        self.btn_metaboanalyst.config(state='normal')
        self._status_ok(
            f'Quantification: {len(self._quant_results)} metabolites')

        self._compute_vip_scores()

        if self._right_widget:
            self._populate_tree()
            children = self._tree.get_children()
            if children:
                self._tree.selection_set(children[0])
                self._tree.focus(children[0])
                self._on_tree_select()

    # ── VIP scores ───────────────────────────────────────────────────────────

    def _compute_vip_scores(self):
        """Compute PLS-DA VIP scores from current _quant_results and store
        in each result dict as 'vip_score'."""
        if not self._quant_results:
            return

        si      = self.app.samples_info or []
        results = self._quant_results

        # Build per-sample concentration matrix (n_samples × n_metabolites)
        # Use _concs_per_sample stored in each result
        n_s = max((len(r.get('_concs_per_sample', [])) for r in results), default=0)
        if n_s < 3:
            for r in results:
                r['vip_score'] = float('nan')
            return

        X = np.array([r.get('_concs_per_sample', [float('nan')] * n_s)
                      for r in results], dtype=float).T   # (n_s, n_met)

        # Build group label vector — exclude BLK, encode groups as integers
        blk_idx = set(getattr(self, '_last_blk_indices', []))
        groups  = getattr(self, '_last_groups', {})

        # Map group name → integer label
        non_blk_groups = sorted(g for g in groups if g != 'BLK')
        if len(non_blk_groups) < 2:
            # Only 1 group → VIP undefined
            for r in results:
                r['vip_score'] = float('nan')
            return

        g_label = {g: i for i, g in enumerate(non_blk_groups)}
        y_full  = np.full(n_s, float('nan'))
        for g, idxs in groups.items():
            if g == 'BLK':
                continue
            lbl = g_label.get(g, 0)
            for i in idxs:
                if i < n_s:
                    y_full[i] = lbl

        # Keep only non-BLK samples with finite labels
        mask = np.isfinite(y_full)
        if mask.sum() < 3:
            for r in results:
                r['vip_score'] = float('nan')
            return

        X_sub = X[mask, :]
        y_sub = y_full[mask]

        n_comp = min(2, len(non_blk_groups) - 1, X_sub.shape[0] - 1, X_sub.shape[1])
        n_comp = max(1, n_comp)

        vip = _pls_vip(X_sub, y_sub, n_components=n_comp)

        for r, v in zip(results, vip):
            r['vip_score'] = float(v) if np.isfinite(v) else float('nan')

    # ── Per-sample area update (from Peak View manual adjustment) ────────────

    def update_sample_area(self, peak_obj, sample_idx, lo_ppm, hi_ppm):
        """Called by PeakSampleView after the user manually adjusts a region.

        Recomputes the area for sample_idx using the SAME method that was used
        in _run (trapz / Lorentz / MCR) but on the new [lo_ppm, hi_ppm] region.
        Then recalculates CV%, mean_conc, status and refreshes the tree row.
        """
        if not self._quant_results:
            return

        # Find the result (identity check first, ppm fallback)
        r = next((x for x in self._quant_results
                  if x.get('_peak') is peak_obj), None)
        if r is None:
            peak_ppm = peak_obj.get('ppm', None)
            if peak_ppm is not None:
                r = next((x for x in self._quant_results
                          if abs(x.get('ppm', float('nan')) - peak_ppm) < 0.002), None)
        if r is None:
            return

        all_int = self.app.all_intensities
        ppm_arr = self.app.ppm
        n_s     = all_int.shape[1] if all_int is not None else 0

        if '_areas_per_sample' not in r:
            r['_areas_per_sample'] = [r.get('raw_area', 0.0)] * n_s

        # ── Recompute area using original integration method ──────────────────
        integ_mode  = r.get('_integ_mode', 'Area')
        used_mcr    = r.get('_used_mcr', False)
        nh          = r.get('_nh', 1.0)
        blk_mean    = r.get('_blk_mean_area', 0.0)
        proton_corr = r.get('_proton_corr', False)
        use_blk_sub = r.get('_use_blk_sub', False)

        # Build index slice for new region
        lo_mask = ppm_arr >= min(lo_ppm, hi_ppm)
        hi_mask = ppm_arr <= max(lo_ppm, hi_ppm)
        mask    = lo_mask & hi_mask
        if not mask.any():
            return
        idxs    = np.where(mask)[0]
        lo_i_n  = int(idxs.min())
        hi_i_n  = int(idxs.max())
        col     = all_int[lo_i_n:hi_i_n+1, sample_idx]
        ppm_sub = ppm_arr[lo_i_n:hi_i_n+1]

        if used_mcr:
            # Use existing pure spectrum S from MCR; fit amplitude for this
            # sample in the new region via least-squares (no negative constraint
            # since region may shift slightly).
            mcr_info = r.get('_mcr')
            s_vec = mcr_info.get('S') if mcr_info else None
            orig_lo = mcr_info.get('lo_i', 0) if mcr_info else 0
            orig_hi = mcr_info.get('hi_i', 0) if mcr_info else 0
            if s_vec is not None:
                # Map new indices to positions within the original S vector
                s_lo = max(0, lo_i_n - orig_lo)
                s_hi = min(len(s_vec) - 1, hi_i_n - orig_lo)
                if s_hi > s_lo:
                    s_sub = s_vec[s_lo:s_hi+1]
                    c_sub = col[:len(s_sub)]
                    denom = float(s_sub @ s_sub)
                    C_s   = max(0.0, float(s_sub @ c_sub) / denom) if denom > 1e-12 else 0.0
                    s_area_scale = abs(float(_trapz(s_vec,
                                                    ppm_arr[orig_lo:orig_hi+1])))
                    area_raw = C_s * (s_area_scale if s_area_scale > 1e-12 else 1.0)
                else:
                    area_raw = abs(float(_trapz(col, ppm_sub))) if col.size > 1 else 0.0
            else:
                area_raw = abs(float(_trapz(col, ppm_sub))) if col.size > 1 else 0.0

        elif integ_mode == 'Lorentz':
            # Re-fit Lorentzian on this sample's new region
            try:
                _, cen_l, wid_l = _fit_lorentz_mean(ppm_sub, col)
                A_s = _lorentz_amplitude(ppm_sub, col, cen_l, wid_l)
                area_raw = float(A_s) * (np.pi * float(wid_l))
            except Exception:
                area_raw = abs(float(_trapz(col, ppm_sub))) if col.size > 1 else 0.0

        else:
            # Area (trapz)
            area_raw = abs(float(_trapz(col, ppm_sub))) if col.size > 1 else 0.0

        # Apply same post-processing as _run
        new_area = area_raw
        if proton_corr and nh > 0:
            new_area /= nh
        if use_blk_sub:
            new_area -= blk_mean

        r['_areas_per_sample'][sample_idx] = new_area

        s_areas = np.array(r['_areas_per_sample'], dtype=float)

        # Re-apply same normalisation that was used
        norm_mode = r.get('_integ_mode', 'Area')   # not norm_mode; keep via stored key below
        # We need the normalization mode used at run time
        norm_mode_used = getattr(self, '_last_norm_mode', self.norm_var.get())
        ref_areas_used = getattr(self, '_last_ref_areas', None)
        ref_conc_used  = getattr(self, '_last_ref_conc',  1.0)
        _dil           = getattr(self, '_last_sample_dil', np.ones(n_s))

        if norm_mode_used == 'IS' and ref_areas_used is not None:
            s_concs = np.array([
                (s_areas[s] / ref_areas_used[s] * ref_conc_used * _dil[s]
                 if ref_areas_used[s] > 0 else float('nan'))
                for s in range(n_s)])
        else:
            s_concs = s_areas * _dil

        # Rebuild group stats
        groups     = getattr(self, '_last_groups', {})
        blk_indices = getattr(self, '_last_blk_indices', [])

        cv_by_group    = {}
        concs_by_group = {}
        for g, idxs in groups.items():
            vals = [float(s_concs[i]) for i in idxs
                    if i < n_s and np.isfinite(s_concs[i]) and s_concs[i] > 0]
            cv_by_group[g]    = _cv(vals)
            concs_by_group[g] = vals

        if blk_indices:
            blk_vals = [float(s_concs[i]) for i in blk_indices
                        if i < n_s and np.isfinite(s_concs[i]) and s_concs[i] > 0]
            if blk_vals:
                concs_by_group['BLK'] = blk_vals
                cv_by_group['BLK']    = _cv(blk_vals)

        all_vals = [v for g, vv in concs_by_group.items()
                    if g != 'BLK' for v in vv if np.isfinite(v) and v > 0]
        mean_conc = float(np.mean(all_vals)) if all_vals else float('nan')

        # SNR
        non_blk_indices = getattr(self, '_last_non_blk_indices', list(range(n_s)))
        p = r.get('_peak')
        _mean_snr = p.get('snr', 0) if p else 0
        if p and ppm_arr is not None and all_int is not None:
            _lo_i = min(p.get('start_idx', 0), p.get('end_idx', 0))
            _hi_i = max(p.get('start_idx', 0), p.get('end_idx', 0))
            _noise_lvl = p.get('noise', None)
            if _noise_lvl is None and p.get('snr', 0) > 0:
                _peak_max_all = float(np.max(np.mean(all_int[_lo_i:_hi_i+1, :], axis=1)))
                _noise_lvl = _peak_max_all / p['snr']
            if _noise_lvl and _noise_lvl > 0 and non_blk_indices:
                _snrs = [float(np.max(all_int[_lo_i:_hi_i+1, _si])) / _noise_lvl
                         for _si in non_blk_indices if _si < n_s]
                if _snrs:
                    _mean_snr = float(np.mean(_snrs))

        # Status
        cvs_finite = [v for g, v in cv_by_group.items()
                      if g != 'BLK' and np.isfinite(v)]
        worst_cv   = max(cvs_finite) if cvs_finite else float('nan')
        _mcr_met   = (r.get('_mcr') or {}).get('metrics', {})
        _lof       = _mcr_met.get('lof', float('nan'))
        _r2        = _mcr_met.get('r2',  float('nan'))

        _criteria, _reasons = [], []
        if np.isfinite(worst_cv):
            _s = 0 if worst_cv < 20 else 1 if worst_cv < 40 else 2
            _criteria.append(_s)
            _lbl = 'Good' if _s == 0 else 'Warn' if _s == 1 else 'Poor'
            _reasons.append(f'CV%: {worst_cv:.1f}%  →  {_lbl}')
        if np.isfinite(_lof):
            _s = 0 if _lof < 5 else 1 if _lof < 15 else 2
            _criteria.append(_s)
            _lbl = 'Good' if _s == 0 else 'Warn' if _s == 1 else 'Poor'
            _reasons.append(f'LOF: {_lof:.1f}%  →  {_lbl}')
        if np.isfinite(_r2):
            _s = 0 if _r2 > 0.99 else 1 if _r2 > 0.95 else 2
            _criteria.append(_s)
            _lbl = 'Good' if _s == 0 else 'Warn' if _s == 1 else 'Poor'
            _reasons.append(f'R²: {_r2:.4f}  →  {_lbl}')
        if _mean_snr > 0:
            _s = 0 if _mean_snr > 10 else 1 if _mean_snr > 5 else 2
            _criteria.append(_s)
            _lbl = 'Good' if _s == 0 else 'Warn' if _s == 1 else 'Poor'
            _reasons.append(f'SNR: {_mean_snr:.1f}  →  {_lbl}')
        _worst = max(_criteria) if _criteria else 1
        status = 'good' if _worst == 0 else 'warn' if _worst == 1 else 'poor'
        if not _reasons:
            _reasons = ['All parameters within good range']

        # Update result
        r['raw_area']          = float(np.mean(s_areas))
        r['conc_mm']           = mean_conc
        r['cv_by_group']       = cv_by_group
        r['snr']               = _mean_snr
        r['status']            = status
        r['_status_reasons']   = _reasons
        r['_concs_per_sample'] = s_concs.tolist()
        r['_concs_by_group']   = concs_by_group

        # Refresh tree row
        if self._right_widget:
            self._refresh_tree_row(r)

    def _refresh_tree_row(self, r):
        """Update the single tree row that corresponds to result r."""
        tree = self._tree
        iid = r.get('hmdb_id', r['metabolite'])
        if not tree.exists(iid):
            return
        _nm   = getattr(self, 'norm_var', None)
        _norm = _nm.get() if _nm else 'IS'
        conc  = r.get('conc_mm', float('nan'))
        if not np.isfinite(conc):
            conc_s = 'N/A'
        elif _norm == 'IS':
            conc_s = f'{conc:.4f}'
        else:
            conc_s = f'{conc:.3e}'
        stat = r.get('status', 'good')
        sym  = '✓' if stat == 'good' else ('△' if stat == 'warn' else '✗')
        peak_rank = r.get('_peak', {})
        peak_rank = peak_rank.get('rank', '–') if peak_rank else '–'
        vip = r.get('vip_score', float('nan'))
        vip_s = f'{vip:.2f}' if np.isfinite(vip) else '—'
        tree.item(iid, tags=(stat,), values=(
            peak_rank,
            r['metabolite'],
            f"{r.get('ppm', 0):.4f}",
            conc_s,
            f"{r['raw_area']:.4e}",
            f"{r['snr']:.1f}",
            vip_s,
            f'{sym} {stat.capitalize()}',
        ))

    # ── Export ────────────────────────────────────────────────────────────────

    def _export(self, mode):
        if not self._quant_results:
            messagebox.showinfo('Export', 'No results to export.')
            return

        si      = self.app.samples_info or []
        n_s     = (self.app.all_intensities.shape[1]
                   if self.app.all_intensities is not None else 0)
        metabolites = [r['metabolite'] for r in self._quant_results]

        if mode == 'csv':
            path = filedialog.asksaveasfilename(
                defaultextension='.csv',
                filetypes=[('CSV', '*.csv')],
                initialfile='quantification_results.csv')
            if not path: return
            try:
                with open(path, 'w', newline='', encoding='utf-8') as f:
                    w = csv.writer(f)
                    vip_row = ['VIP', ''] + [
                        f"{r.get('vip_score', float('nan')):.2f}"
                        if np.isfinite(r.get('vip_score', float('nan'))) else '—'
                        for r in self._quant_results]
                    w.writerow(['Sample', 'Group'] + metabolites)
                    w.writerow(vip_row)
                    for s_idx in range(n_s):
                        sname  = si[s_idx].get('name',  f'S{s_idx+1}') if s_idx < len(si) else f'S{s_idx+1}'
                        slabel = si[s_idx].get('label', 'Unknown')      if s_idx < len(si) else 'Unknown'
                        row = [sname, slabel]
                        for r in self._quant_results:
                            concs = r.get('_concs_per_sample', [])
                            val   = concs[s_idx] if s_idx < len(concs) else float('nan')
                            row.append(f'{val:.6f}' if np.isfinite(val) else 'NA')
                        w.writerow(row)
                self._status_ok(f'CSV → {os.path.basename(path)}')
                messagebox.showinfo('Export', f'Saved:\n{path}')
            except Exception as e:
                messagebox.showerror('Export Error', str(e))

        elif mode == 'metaboanalyst':
            path = filedialog.asksaveasfilename(
                defaultextension='.csv',
                filetypes=[('CSV', '*.csv')],
                initialfile='metaboanalyst_input.csv')
            if not path: return
            try:
                names  = [s.get('name',  f'S{i+1}') for i, s in enumerate(si)]
                labels = [s.get('label', 'Unknown') for s in si]
                with open(path, 'w', newline='', encoding='utf-8') as f:
                    w = csv.writer(f)
                    w.writerow(['Sample'] + names)
                    w.writerow(['Label']  + labels)
                    for r in self._quant_results:
                        concs = r.get('_concs_per_sample', [])
                        vals  = [f'{c:.6e}' if np.isfinite(c) else 'NA'
                                 for c in concs]
                        w.writerow([r['metabolite']] + vals)
                self._status_ok(f'MetaboAnalyst → {os.path.basename(path)}')
                messagebox.showinfo('Export', f'Saved:\n{path}')
            except Exception as e:
                messagebox.showerror('Export Error', str(e))