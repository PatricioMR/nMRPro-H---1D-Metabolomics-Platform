# gui/notation/deconvolution/deconv_list_panel.py
"""
Left panel of the Deconvolution Tool.

Tree layout (show='tree headings'):
  #0 column  = "Region"  → shows region label + expand/collapse arrow
  data cols  = #  |  PPM  |  Start  |  End  |  SNR  |  W  |  Status

  ▼ ⚠ Region 1                     (parent — collapsible)
        3   3.2100  3.2050  3.2150  12.4  0.005  ⚠ Undef
  ▼ Region 2
        7   1.3950  1.3900  1.4000   8.1  0.006  Undef
  ▼ ✅ Region 1  (after deconv)
        —   3.2180  ...                    ⚠ Undef
        —   3.2040  ...                    ● Good

Rules:
  • Parent #0 text = "Region N"  (no number in the # column)
  • Parent data columns are ALL EMPTY except Status = n peaks
  • ⚠ on parent  → region contains a manually-Undef peak (from Peak List)
  • ⚠ on child   → child status is Undefined (not yet resolved)
  • Green child  → only after marking Good (Ctrl+1)
  • Ctrl+1/2/3   → Good / Undefined / Poor on selected child
  • Ctrl+click   → multi-select regions
  • Ctrl+G       → group selected regions into one merged entry
"""
import tkinter as tk
from tkinter import ttk, messagebox

STATUS_GOOD      = 'Good'
STATUS_UNDEFINED = 'Undefined'
STATUS_POOR      = 'Poor'

STATUS_COLORS = {
    STATUS_GOOD:      '#1a7a1a',
    STATUS_UNDEFINED: '#7a6000',
    STATUS_POOR:      '#9a0000',
}
STATUS_SYMBOL = {
    STATUS_GOOD:      '● Good',
    STATUS_UNDEFINED: '⚠ Undef',
    STATUS_POOR:      '✗ Poor',
}


class DeconvListPanel:
    def __init__(self, parent, controller,
                 on_select_callback, on_apply_callback, on_save_callback,
                 on_apply_all_callback=None):
        self.parent          = parent
        self.controller      = controller
        self.on_select       = on_select_callback
        self.on_apply        = on_apply_callback
        self.on_save         = on_save_callback
        self.on_apply_all_cb = on_apply_all_callback

        self._current_region = None
        self._current_child  = None
        self._row_map        = {}   # iid → (region_idx, peak_idx, row_type)

        self.create_widgets()
        self.refresh_list()
        self._bind_keys()

    # ── Widgets ───────────────────────────────────────────────────────────────

    def create_widgets(self):
        self.frame = ttk.Frame(self.parent, width=540)
        self.frame.pack(side=tk.LEFT, fill=tk.Y, padx=5, pady=5)
        self.frame.pack_propagate(False)

        ttk.Label(self.frame, text="Peaks for Deconvolution",
                  font=("Arial", 11, "bold")).pack(pady=5)

        self.info_label = ttk.Label(self.frame, text="", foreground="gray")
        self.info_label.pack(pady=2)

        # ── Treeview ──────────────────────────────────────────────────────────
        tree_frame = ttk.Frame(self.frame)
        tree_frame.pack(fill=tk.BOTH, expand=True, pady=5)

        vsb = ttk.Scrollbar(tree_frame, orient=tk.VERTICAL)
        hsb = ttk.Scrollbar(tree_frame, orient=tk.HORIZONTAL)

        self.tree = ttk.Treeview(
            tree_frame,
            columns=('num', 'ppm', 'start', 'end', 'snr', 'width', 'status'),
            show='tree headings',
            selectmode='extended',   # Ctrl+click multi-select
            yscrollcommand=vsb.set,
            xscrollcommand=hsb.set)
        vsb.config(command=self.tree.yview)
        hsb.config(command=self.tree.xview)
        self.tree.grid(row=0, column=0, sticky='nsew')
        vsb.grid(row=0, column=1, sticky='ns')
        hsb.grid(row=1, column=0, sticky='ew')
        tree_frame.grid_rowconfigure(0, weight=1)
        tree_frame.grid_columnconfigure(0, weight=1)

        self.tree.heading('#0', text='Region')
        self.tree.column('#0', width=110, minwidth=80, stretch=False)

        for cid, hd, w in [
            ('num',    '#',      48),
            ('ppm',    'PPM',    82),
            ('start',  'Start',  82),
            ('end',    'End',    82),
            ('snr',    'SNR',    58),
            ('width',  'W',      62),
            ('status', 'Status', 90),
        ]:
            self.tree.heading(cid, text=hd)
            self.tree.column(cid, width=w, anchor=tk.CENTER, minwidth=35)

        # Row tags
        self.tree.tag_configure('region_overlap',
                                background='#fff3cd', foreground='#856404')
        self.tree.tag_configure('region_manual',
                                background='#fff0f8', foreground='#880055')
        self.tree.tag_configure('region_done',
                                background='#f0f0f0', foreground='#444')
        self.tree.tag_configure('region_saved',
                                background='#e8f5e9', foreground='#1b5e20')
        self.tree.tag_configure('region_grouped',
                                background='#e3f2fd', foreground='#0d47a1')
        self.tree.tag_configure('child_good',
                                background='#c8f7c5', foreground='#1a7a1a')
        self.tree.tag_configure('child_undefined',
                                background='#fef9c3', foreground='#7a6000')
        self.tree.tag_configure('child_poor',
                                background='#ffd6d6', foreground='#9a0000')
        self.tree.tag_configure('child_queued',
                                background='#e8f4ff', foreground='#0055aa')

        self.tree.bind('<<TreeviewSelect>>', self._on_tree_select)
        self.tree.bind('<Double-1>',         self._on_double_click)
        self.tree.bind('<Control-g>',        lambda e: self._group_selected())
        self.tree.bind('<Control-G>',        lambda e: self._group_selected())

        # ── Parameters ────────────────────────────────────────────────────────
        ttk.Separator(self.frame, orient='horizontal').pack(fill=tk.X, pady=6)
        ttk.Label(self.frame, text="Deconvolution Parameters",
                  font=("Arial", 10, "bold")).pack(pady=(0, 4))

        pf = ttk.Frame(self.frame)
        pf.pack(fill=tk.X, padx=5)
        for row, (lbl, attr, val, wtype) in enumerate([
            ("Min SNR:",         "min_snr_var",   2.5,          "entry"),
            ("Max Peaks:",       "max_peaks_var", 8,            "spin"),
            ("Peak Model:",      "model_var",     "Lorentzian", "combo"),
            ("Min Width (ppm):", "min_width_var", 0.001,        "entry"),
        ]):
            ttk.Label(pf, text=lbl).grid(
                row=row, column=0, sticky=tk.W, pady=2, padx=4)
            if wtype == "entry":
                var = tk.DoubleVar(value=val)
                ttk.Entry(pf, textvariable=var, width=10).grid(
                    row=row, column=1, pady=2, padx=4)
            elif wtype == "spin":
                var = tk.IntVar(value=val)
                ttk.Spinbox(pf, from_=1, to=15,
                            textvariable=var, width=9).grid(
                    row=row, column=1, pady=2, padx=4)
            elif wtype == "combo":
                var = tk.StringVar(value=val)
                cb_model = ttk.Combobox(
                    pf, textvariable=var,
                    values=["Lorentzian", "Gaussian", "Pseudo-Voigt",
                                   "Skewed-Lorentzian", "Onion (Auto-BIC)"],
                    width=9, state="readonly")
                cb_model.grid(row=row, column=1, pady=2, padx=4)
                # Quando o modelo muda, re-deconvolve automaticamente
                cb_model.bind('<<ComboboxSelected>>', self._on_model_changed)
            setattr(self, attr, var)

        # Samples Edit button — right of Min Width row
        ttk.Button(pf, text='👥 Samples Edit',
                   command=self._open_samples_dialog
                   ).grid(row=3, column=2, padx=(8, 4), pady=2, sticky='w')

        # Advanced per-model parameters (dialog)
        ttk.Button(pf, text='⚙ Parameters',
                   command=self._open_model_params_dialog
                   ).grid(row=3, column=3, padx=(2, 4), pady=2, sticky='w')

        # Advanced params — not shown inline, exposed via Parameters dialog
        self.detect_shoulders_var = tk.BooleanVar(value=True)
        self.shoulder_snr_var     = tk.DoubleVar(value=0.40)
        self.n_boot_var           = tk.IntVar(value=50)
        self._params_dlg          = None

        # ── Buttons ───────────────────────────────────────────────────────────
        ttk.Separator(self.frame, orient='horizontal').pack(fill=tk.X, pady=6)

        self.apply_btn = ttk.Button(
            self.frame, text="🔧 Deconvolve Selected  (Enter)",
            command=self._apply_selected, state="disabled")
        self.apply_btn.pack(fill=tk.X, padx=5, pady=2)

        self.group_btn = ttk.Button(
            self.frame, text="🔗 Group Selected  (Ctrl+G)",
            command=self._group_selected, state="disabled")
        self.group_btn.pack(fill=tk.X, padx=5, pady=2)

        ttk.Label(
            self.frame,
            text="Ctrl+click rows  →  Ctrl+G to group  →  Deconvolve",
            font=("Arial", 7), foreground="gray").pack(pady=(0, 2))

        self.apply_all_btn = ttk.Button(
            self.frame, text="⚡ Deconvolve All",
            command=self._apply_all, state="disabled")
        self.apply_all_btn.pack(fill=tk.X, padx=5, pady=2)

        self.revert_btn = ttk.Button(
            self.frame, text="↩ Revert Selected Region",
            command=self._revert_selected, state="disabled")
        self.revert_btn.pack(fill=tk.X, padx=5, pady=2)

        self.revert_all_btn = ttk.Button(
            self.frame, text="↩ Revert All",
            command=self._revert_all, state="disabled")
        self.revert_all_btn.pack(fill=tk.X, padx=5, pady=2)

        self.save_btn = ttk.Button(
            self.frame, text="💾 Save Sub-peaks to Peak List",
            command=self.on_save, state="disabled")
        self.save_btn.pack(fill=tk.X, padx=5, pady=2)

        ttk.Button(
            self.frame, text="↺ Reset Parameters",
            command=self._reset_params).pack(fill=tk.X, padx=5, pady=2)

        ttk.Label(
            self.frame,
            text="Ctrl+1 Good  ·  Ctrl+2 Undefined  ·  Ctrl+3 Poor\n"
                 "Ctrl+R Reset view  ·  Enter Deconvolve",
            font=("Arial", 7), foreground="gray").pack(pady=4)

        self.status_label = ttk.Label(
            self.frame, text="No region selected",
            foreground="gray", font=("Arial", 8))
        self.status_label.pack(pady=2)

    # ── Key bindings ──────────────────────────────────────────────────────────

    def _bind_keys(self):
        self.tree.bind('<Up>',     self._key_up)
        self.tree.bind('<Down>',   self._key_down)
        self.tree.bind('<Return>', self._key_enter)

    def _key_up(self, event):
        sel = self.tree.selection()
        if sel:
            prev = self.tree.prev(sel[0])
            if prev:
                self.tree.selection_set(prev)
                self.tree.focus(prev)
                self._on_tree_select(None)
        return "break"

    def _key_down(self, event):
        sel = self.tree.selection()
        if sel:
            nxt = self.tree.next(sel[0])
            if not nxt:
                ch = self.tree.get_children(sel[0])
                nxt = ch[0] if ch else None
            if nxt:
                self.tree.selection_set(nxt)
                self.tree.focus(nxt)
                self._on_tree_select(None)
        return "break"

    def _key_enter(self, event):
        if (self._current_region is not None
                and str(self.apply_btn['state']) == 'normal'):
            self._apply_selected()

    # ── Tree population ───────────────────────────────────────────────────────

    def refresh_list(self):
        self._row_map = {}
        self.tree.delete(*self.tree.get_children(""))

        regions     = self.controller.get_regions()
        valid_count = 0

        for i, r in enumerate(regions):
            data = self.controller.get_region_data(i)
            if not data or len(data['ppm']) < 3:
                continue
            valid_count += 1

            done         = r['status'] == 'deconvolved'
            result       = self.controller.results.get(i, {})
            is_saved     = result.get('_saved', False)
            region_peaks = r.get('peaks', [])
            is_grouped   = any(p.get('_grouped_from') for p in region_peaks)

            has_manual = any(
                not p.get('from_overlap_search', True)
                for p in region_peaks)

            if done and is_saved:
                p_sym        = '💾'
                p_tag        = 'region_saved'
                p_status_col = 'saved'
            elif done:
                p_sym        = '✅'
                p_tag        = 'region_done'
                p_status_col = 'deconvolved'
            elif is_grouped:
                p_sym        = '🔗'
                p_tag        = 'region_grouped'
                p_status_col = f'{len(region_peaks)} pk (grouped)'
            elif has_manual:
                p_sym        = '⚠'
                p_tag        = 'region_manual'
                p_status_col = f'{len(region_peaks)} pk'
            else:
                p_sym        = ''
                p_tag        = 'region_overlap'
                p_status_col = f'{len(region_peaks)} pk'

            p_label = f'{p_sym} Region {valid_count}'.strip()
            p_iid   = f'region_{i}'

            try:
                self.tree.insert(
                    '', tk.END, iid=p_iid,
                    text=p_label,
                    values=('', '', '', '', '', '', p_status_col),
                    open=True,
                    tags=(p_tag,))
            except Exception:
                pass
            self._row_map[p_iid] = (i, -1, 'region')

            if done and result.get('peaks'):
                for j, p in enumerate(result['peaks']):
                    c_iid  = f'row_{i}_{j}'
                    status = p.get('status', STATUS_UNDEFINED)
                    if status == STATUS_GOOD:
                        c_tag   = 'child_good'
                        st_cell = '● Good'
                    elif status == STATUS_POOR:
                        c_tag   = 'child_poor'
                        st_cell = '✗ Poor'
                    else:
                        c_tag   = 'child_undefined'
                        st_cell = '⚠ Undef'

                    pk_num = p.get('rank', f'{valid_count}.{j+1}')
                    try:
                        self.tree.insert(
                            p_iid, tk.END, iid=c_iid,
                            text='',
                            values=(
                                pk_num,
                                f"{p['ppm']:.4f}",
                                f"{p.get('start_ppm', p['ppm']):.4f}",
                                f"{p.get('end_ppm',   p['ppm']):.4f}",
                                f"{p.get('snr', 0):.1f}",
                                f"{p.get('width', p.get('width_ppm', 0)):.4f}",
                                st_cell),
                            tags=(c_tag,))
                    except Exception:
                        pass
                    self._row_map[c_iid] = (i, j, 'child')

            else:
                for j, p in enumerate(region_peaks):
                    c_iid       = f'row_{i}_{j}'
                    from_search = p.get('from_overlap_search', True)
                    status      = p.get('status', STATUS_UNDEFINED)
                    if status == STATUS_POOR:
                        c_tag   = 'child_poor'
                        st_cell = '✗ Poor'
                    elif not from_search:
                        c_tag   = 'child_queued'
                        st_cell = '⚠ Undef'
                    else:
                        c_tag   = 'child_undefined'
                        st_cell = 'Undef'
                    try:
                        self.tree.insert(
                            p_iid, tk.END, iid=c_iid,
                            text='',
                            values=(
                                p.get('rank', '—'),
                                f"{p['ppm']:.4f}",
                                f"{p.get('start_ppm', p['ppm']):.4f}",
                                f"{p.get('end_ppm',   p['ppm']):.4f}",
                                f"{p.get('snr', 0):.1f}",
                                f"{p.get('width_ppm', 0):.4f}",
                                st_cell),
                            tags=(c_tag,))
                    except Exception:
                        pass
                    self._row_map[c_iid] = (i, j, 'peak')

        self.info_label.config(text=f"{valid_count} peak(s) in queue")

        has_any = any(
            p.get('status') in (STATUS_GOOD, STATUS_UNDEFINED, STATUS_POOR)
            for res in self.controller.results.values()
            for p in res.get('peaks', []))
        self.save_btn.config(state='normal' if has_any else 'disabled')

        has_done = any(r['status'] == 'deconvolved' for r in regions)
        self.revert_all_btn.config(state='normal' if has_done else 'disabled')
        if self._current_region is not None and self._current_region < len(regions):
            self.revert_btn.config(state='normal' if regions[self._current_region]['status'] == 'deconvolved' else 'disabled')
        else:
            self.revert_btn.config(state='disabled')

    # ── Selection ─────────────────────────────────────────────────────────────

    def _on_tree_select(self, event):
        sel = self.tree.selection()
        if not sel:
            return

        # Count region-level rows selected → enable group button
        n_regions = sum(
            1 for s in sel
            if self._row_map.get(s, (None, None, ''))[2] == 'region')
        self.group_btn.config(
            state='normal' if n_regions >= 2 else 'disabled')

        # Use last item for display
        iid  = sel[-1]
        info = self._row_map.get(iid)
        if info is None:
            return
        region_idx, peak_idx, row_type = info
        self._current_region = region_idx
        self.apply_btn.config(state='normal')
        self.apply_all_btn.config(state='normal')

        if row_type == 'child':
            self._current_child = iid
            result = self.controller.results.get(region_idx, {})
            peaks  = result.get('peaks', [])
            if peak_idx < len(peaks):
                p = peaks[peak_idx]
                self.status_label.config(
                    text=f"#{p.get('rank','?')}  {p['ppm']:.4f} ppm  "
                         f"SNR {p.get('snr',0):.1f}  "
                         f"{p.get('status', STATUS_UNDEFINED)}",
                    foreground=STATUS_COLORS.get(
                        p.get('status', STATUS_UNDEFINED), 'gray'))
                self.on_select(region_idx, child_index=peak_idx)
                return
        else:
            self._current_child = None

        regions = self.controller.get_regions()
        if region_idx < len(regions):
            r = regions[region_idx]
            self.status_label.config(
                text=f"Region {region_idx+1}: {r['status']}",
                foreground='green' if r['status'] == 'deconvolved' else 'blue')
            self.revert_btn.config(state='normal' if r['status'] == 'deconvolved' else 'disabled')
        self.on_select(region_idx)

    def _on_right_click(self, event):
        row = self.tree.identify_row(event.y)
        if not row:
            return
        self.tree.selection_set(row)
        info = self._row_map.get(row)
        if info is None:
            return
        region_idx, peak_idx, row_type = info

        menu = tk.Menu(self.tree, tearoff=0)

        if row_type == 'region':
            regions = self.controller.get_regions()
            done    = (region_idx < len(regions) and
                       regions[region_idx]['status'] == 'deconvolved')
            if done:
                menu.add_command(
                    label='↩ Restore original peak',
                    command=lambda ri=region_idx: self._restore_peak(ri))
            else:
                menu.add_command(
                    label='🔧 Deconvolve',
                    command=lambda: self._apply_selected())
            menu.add_separator()
            menu.add_command(
                label='🗑 Remove from queue',
                command=lambda ri=region_idx: self._remove_peak(ri))

        elif row_type == 'child':
            menu.add_command(label='● Mark Good',
                command=lambda: self.set_child_status(STATUS_GOOD))
            menu.add_command(label='⚠ Mark Undefined',
                command=lambda: self.set_child_status(STATUS_UNDEFINED))
            menu.add_command(label='✗ Mark Poor',
                command=lambda: self.set_child_status(STATUS_POOR))

        try:
            menu.tk_popup(event.x_root, event.y_root)
        finally:
            menu.grab_release()

    def _restore_peak(self, region_idx):
        """Undo deconvolution: remove result, restore original peak status."""
        self.controller.restore_peak(region_idx)
        self.refresh_list()
        self.status_label.config(
            text=f'Peak {region_idx+1} restored to original.',
            foreground='#555')

    def _remove_peak(self, region_idx):
        """Remove peak from the deconvolution queue entirely."""
        if region_idx < len(self.controller.peaks):
            self.controller.peaks.pop(region_idx)
            self.controller.results.pop(region_idx, None)
        self.refresh_list()

    def _on_double_click(self, event):
        sel = self.tree.selection()
        if sel:
            info = self._row_map.get(sel[0])
            if info and info[2] == 'region':
                self._apply_selected()

    # ── Group selected regions ────────────────────────────────────────────────

    def _group_selected(self):
        """Merge ≥2 selected region rows into one entry spanning all their
        boundaries.  User then clicks Deconvolve manually.
        On Save, all original peaks from _grouped_from are removed.
        """
        sel = self.tree.selection()
        # Collect only top-level region rows
        region_idxs = []
        for iid in sel:
            info = self._row_map.get(iid)
            if info and info[2] == 'region':
                region_idxs.append(info[0])
        region_idxs = list(dict.fromkeys(region_idxs))  # dedupe, keep order

        if len(region_idxs) < 2:
            messagebox.showinfo(
                'Group Peaks',
                'Ctrl+click 2 or more region rows to select,\n'
                'then press Ctrl+G.')
            return

        ctrl = self.controller
        # Gather all peak dicts from the selected regions
        sel_peaks = []
        for ri in region_idxs:
            meta = ctrl._region_meta
            if ri < len(meta):
                sel_peaks.extend(meta[ri].get('peaks', []))

        if not sel_peaks:
            return

        # Compute merged boundary
        lo  = min(min(p.get('start_ppm', p['ppm']),
                      p.get('end_ppm',   p['ppm'])) for p in sel_peaks)
        hi  = max(max(p.get('start_ppm', p['ppm']),
                      p.get('end_ppm',   p['ppm'])) for p in sel_peaks)

        # Build merged peak
        merged = {
            'ppm':           (lo + hi) / 2,
            'start_ppm':     hi,   # NMR axis: higher ppm = left
            'end_ppm':       lo,
            'height':        max(p['height'] for p in sel_peaks),
            'snr':           max(p.get('snr', 0) for p in sel_peaks),
            'width_ppm':     hi - lo,
            'width_at_half': hi - lo,
            'rank':          sel_peaks[0].get('rank', '?'),
            'overlapping':   True,
            'from_overlap_search': True,
            '_grouped_from': [p['ppm'] for p in sel_peaks],
        }

        # Add merged peak via controller (peak-centric API)
        ctrl.peaks.append(merged)

        # Remove the individual regions (reverse order to keep indices valid)
        for ri in sorted(region_idxs, reverse=True):
            if ri < len(ctrl.peaks) - 1:  # -1 because we just appended merged
                ctrl.peaks.pop(ri)
            ctrl.results.pop(ri, None)
            if hasattr(ctrl, 'excluded_samples'):
                ctrl.excluded_samples.pop(ri, None)

        self.refresh_list()

        # Select the new merged entry
        new_idx = len(ctrl.peaks) - 1
        new_iid = f'region_{new_idx}'
        # Find it by scanning _row_map (index may have shifted)
        for iid, info in self._row_map.items():
            if info[2] == 'region' and info[0] == new_idx:
                new_iid = iid
                break
        if self.tree.exists(new_iid):
            self.tree.selection_set(new_iid)
            self.tree.focus(new_iid)
            self.tree.see(new_iid)

        self.status_label.config(
            text=f'Grouped {len(region_idxs)} peaks → 1 entry. '
                 f'Now click Deconvolve.',
            foreground='#1565c0')

    # ── Status assignment ─────────────────────────────────────────────────────

    def set_child_status(self, status):
        if not self._current_child:
            return
        info = self._row_map.get(self._current_child)
        if info is None or info[2] != 'child':
            return
        ri, pi, _ = info
        result = self.controller.results.get(ri, {})
        peaks  = result.get('peaks', [])
        if pi < len(peaks):
            peaks[pi]['status'] = status
            self.refresh_list()
            if self.tree.exists(self._current_child):
                self.tree.selection_set(self._current_child)
                self.tree.focus(self._current_child)

    # ── Apply / Save ──────────────────────────────────────────────────────────

    def _apply_selected(self):
        if self._current_region is None:
            return
        regions = self.controller.get_regions()
        # Only warn if deconvolved AND has actual sub-peak results
        _r = regions[self._current_region] if self._current_region < len(regions) else {}
        _has_results = bool(self.controller.results.get(self._current_region, {}).get('peaks'))
        if _r.get('status') == 'deconvolved' and _has_results:
            if not messagebox.askyesno(
                    "Re-deconvolve?",
                    "This region was already deconvolved.\n"
                    "This will replace the previous result.\n\nContinue?"):
                return
        self.on_apply(self._current_region, self._get_params())
        self.refresh_list()

    def _apply_all(self):
        regions = self.controller.get_regions()
        pending = [i for i, r in enumerate(regions)
                   if r['status'] != 'deconvolved']
        if not pending:
            messagebox.showinfo("Info", "All regions already deconvolved.")
            return
        if not messagebox.askyesno(
                "Deconvolve All",
                f"Deconvolve {len(pending)} pending region(s)?\n"
                "A progress window will appear.\n\nContinue?"):
            return
        params = self._get_params()
        if self.on_apply_all_cb:
            self.on_apply_all_cb(pending, params)
        else:
            self.controller.deconvolve_all(params)
            self.refresh_list()

    def _revert_selected(self):
        if self._current_region is not None:
            self._restore_peak(self._current_region)

    def _revert_all(self):
        if messagebox.askyesno("Revert All", "Are you sure you want to revert all deconvolved regions to their original state?"):
            regions = self.controller.get_regions()
            for i in range(len(regions)):
                if regions[i]['status'] == 'deconvolved':
                    self.controller.restore_peak(i)
            self.refresh_list()
            self.status_label.config(text="All regions reverted.", foreground="#555")

    def _on_model_changed(self, event=None):
        """Quando o modelo muda, re-deconvolve o pico actual automaticamente."""
        # Refresh the Parameters dialog if it is open
        try:
            if self._params_dlg and self._params_dlg.winfo_exists():
                self._populate_params_dialog()
        except Exception:
            pass
        if self._current_region is None:
            return
        # Verificar se este pico já tem resultado
        has_result = bool(
            self.controller.results.get(self._current_region, {}).get('peaks'))
        if not has_result:
            return   # ainda não foi deconvolvido — nada a fazer
        # Re-deconvolver automaticamente sem pedir confirmação
        self.on_apply(self._current_region, self._get_params())
        self.refresh_list()

    def _get_params(self):
        return {
            'min_snr':            self.min_snr_var.get(),
            'max_peaks':          self.max_peaks_var.get(),
            'model':              self.model_var.get(),
            'min_width':          self.min_width_var.get(),
            'detect_shoulders':   self.detect_shoulders_var.get(),
            'shoulder_snr_factor':self.shoulder_snr_var.get(),
            'n_boot':             self.n_boot_var.get(),
        }

    def _reset_params(self):
        self.min_snr_var.set(2.5)
        self.max_peaks_var.set(8)
        self.model_var.set("Lorentzian")
        self.min_width_var.set(0.001)
        self.detect_shoulders_var.set(True)
        self.shoulder_snr_var.set(0.40)
        self.n_boot_var.set(50)
        self.status_label.config(text="Parameters reset", foreground="orange")

    def get_params(self):
        return self._get_params()

    # ── Parameters dialog ─────────────────────────────────────────────────────

    def _open_model_params_dialog(self):
        """Open (or raise) the advanced parameters dialog."""
        if self._params_dlg is not None:
            try:
                if self._params_dlg.winfo_exists():
                    self._params_dlg.lift()
                    self._params_dlg.focus_force()
                    return
            except Exception:
                pass
        dlg = tk.Toplevel(self.frame.winfo_toplevel())
        self._params_dlg = dlg
        dlg.title("Advanced Parameters")
        dlg.resizable(False, False)
        dlg.transient(self.frame.winfo_toplevel())
        # No grab_set — non-blocking

        self._params_dlg_frame = ttk.Frame(dlg, padding=10)
        self._params_dlg_frame.pack(fill=tk.BOTH, expand=True)
        self._populate_params_dialog()

        def _on_close():
            self._params_dlg = None
            dlg.destroy()
        dlg.protocol('WM_DELETE_WINDOW', _on_close)

        dlg.update_idletasks()
        x = self.frame.winfo_rootx() + self.frame.winfo_width() + 10
        y = self.frame.winfo_rooty() + 200
        dlg.geometry(f'+{x}+{y}')

    def _populate_params_dialog(self):
        """Rebuild the content of the Parameters dialog for the current model."""
        if self._params_dlg is None:
            return
        f = self._params_dlg_frame
        for w in f.winfo_children():
            w.destroy()
        model = self.model_var.get()

        ttk.Label(f, text=f"Model: {model}",
                  font=("Arial", 10, "bold")).pack(anchor=tk.W, pady=(0, 6))

        # ── Shoulder detection (all models) ───────────────────────────────────
        sh = ttk.LabelFrame(f, text="Shoulder Detection", padding=6)
        sh.pack(fill=tk.X, pady=(0, 6))

        ttk.Checkbutton(sh, text="Detect shoulders (inflection points)",
                        variable=self.detect_shoulders_var).grid(
            row=0, column=0, columnspan=2, sticky=tk.W, pady=2)

        ttk.Label(sh, text="SNR factor:").grid(
            row=1, column=0, sticky=tk.W, padx=(18, 4), pady=2)
        ttk.Entry(sh, textvariable=self.shoulder_snr_var, width=7).grid(
            row=1, column=1, sticky=tk.W, pady=2)
        ttk.Label(sh,
                  text="How tall a shoulder must be relative to noise×SNR.\n"
                       "0.1 = strict  ·  0.4 = default  ·  0.8 = very sensitive",
                  font=("Arial", 8), foreground="gray").grid(
            row=2, column=0, columnspan=2, sticky=tk.W, padx=(18, 0))

        # ── Model-specific section ─────────────────────────────────────────────
        if model == "Pseudo-Voigt":
            mv = ttk.LabelFrame(f, text="Pseudo-Voigt", padding=6)
            mv.pack(fill=tk.X, pady=(0, 6))
            ttk.Label(mv, text="Initial η  (0 = Gaussian · 1 = Lorentzian):").grid(
                row=0, column=0, sticky=tk.W, padx=4, pady=2)
            if not hasattr(self, 'eta_init_var'):
                self.eta_init_var = tk.DoubleVar(value=0.5)
            ttk.Entry(mv, textvariable=self.eta_init_var, width=7).grid(
                row=0, column=1, sticky=tk.W, padx=4, pady=2)

        elif model == "Onion (Auto-BIC)":
            mv = ttk.LabelFrame(f, text="Onion — Bootstrap", padding=6)
            mv.pack(fill=tk.X, pady=(0, 6))
            ttk.Label(mv, text="Bootstrap samples:").grid(
                row=0, column=0, sticky=tk.W, padx=4, pady=2)
            ttk.Spinbox(mv, from_=10, to=500, increment=10,
                        textvariable=self.n_boot_var, width=7).grid(
                row=0, column=1, sticky=tk.W, padx=4, pady=2)
            ttk.Label(mv, text="More samples → more accurate, slower",
                      font=("Arial", 8), foreground="gray").grid(
                row=1, column=0, columnspan=2, sticky=tk.W, padx=4)

        ttk.Button(f, text="Close",
                   command=lambda: self._params_dlg.destroy() or
                   setattr(self, '_params_dlg', None)
                   ).pack(anchor=tk.E, pady=(8, 0))

    # ── Samples dialog ────────────────────────────────────────────────────────

    def _open_samples_dialog(self):
        """Checklist to include/exclude samples for the selected peak."""
        ri  = self._current_region
        app = getattr(self, '_app', None)
        if app is None or ri is None:
            return
        si   = getattr(app, 'samples_info', [])
        excl = set(self.controller.get_excluded_samples(ri))

        dlg = tk.Toplevel(self.frame.winfo_toplevel())
        dlg.title('Sample Inclusion')
        dlg.geometry('320x420')
        dlg.resizable(True, True)
        dlg.transient(self.frame.winfo_toplevel())
        dlg.grab_set()

        ttk.Label(dlg,
                  text='Uncheck to exclude sample (artefact).\n'
                       'Excluded regions are zeroed on Save.',
                  foreground='gray', font=('Arial', 8)
                  ).pack(pady=(8, 4), padx=10, anchor='w')

        cf = ttk.Frame(dlg)
        cf.pack(fill=tk.BOTH, expand=True, padx=10, pady=4)
        canvas = tk.Canvas(cf, borderwidth=0, highlightthickness=0)
        vsb    = ttk.Scrollbar(cf, orient=tk.VERTICAL, command=canvas.yview)
        inner  = ttk.Frame(canvas)
        inner.bind('<Configure>',
                   lambda e: canvas.configure(
                       scrollregion=canvas.bbox('all')))
        canvas.create_window((0, 0), window=inner, anchor='nw')
        canvas.configure(yscrollcommand=vsb.set)
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        vsb.pack(side=tk.RIGHT, fill=tk.Y)

        vars_ = []
        for i, s in enumerate(si):
            stype = s.get('type', s.get('label', 'Sample'))
            if str(stype).upper() == 'BLK':
                continue
            var = tk.BooleanVar(value=(i not in excl))
            vars_.append((i, var))
            row = ttk.Frame(inner)
            row.pack(fill=tk.X, pady=1)
            ttk.Checkbutton(
                row, variable=var,
                text=f"{s.get('name', 'S'+str(i))}  ({s.get('label', '')})"
            ).pack(side=tk.LEFT, padx=4)

        br = ttk.Frame(dlg)
        br.pack(fill=tk.X, padx=10, pady=4)
        ttk.Button(br, text='All',
                   command=lambda: [v.set(True)  for _, v in vars_]
                   ).pack(side=tk.LEFT, padx=2)
        ttk.Button(br, text='None',
                   command=lambda: [v.set(False) for _, v in vars_]
                   ).pack(side=tk.LEFT, padx=2)

        def _ok():
            new_excl = {i for i, v in vars_ if not v.get()}
            self.controller.set_excluded_samples(ri, new_excl)
            dlg.destroy()

        bf = ttk.Frame(dlg)
        bf.pack(fill=tk.X, padx=10, pady=8)
        ttk.Button(bf, text='Apply', command=_ok).pack(side=tk.LEFT, padx=4)
        ttk.Button(bf, text='Cancel', command=dlg.destroy).pack(side=tk.LEFT)