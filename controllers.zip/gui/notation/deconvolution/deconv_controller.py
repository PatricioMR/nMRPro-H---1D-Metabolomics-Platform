# gui/notation/deconvolution/deconv_controller.py
"""
Peak-centric Deconvolution Controller.

Key design principle:
  processor.peaks is NEVER modified during deconvolution.
  Results are stored in self.results only.
  processor.peaks is updated ONLY when the user confirms Save in DeconvWindow.
"""
import numpy as np
from .deconv_algorithm import deconvolve_region as deconvolve_algorithm

CONTEXT_PPM = 0.08  # display context around each peak


def _local_align_to_ref(y_samples, ref_idx):
    """
    Locally aligns the columns of y_samples by finding integer shifts 
    that maximize cross-correlation to a reference sample.
    """
    n_pts, n_samples = y_samples.shape
    if n_pts < 10 or n_samples < 2:
        return y_samples.copy()

    ref_sig = y_samples[:, ref_idx]
    aligned = np.zeros_like(y_samples)
    aligned[:, ref_idx] = ref_sig

    # Maximum allowed shift: 20% of the window
    max_shift = max(1, n_pts // 5)

    for k in range(n_samples):
        if k == ref_idx:
            continue
        sig = y_samples[:, k]
        corr = np.correlate(ref_sig, sig, mode='full')
        lag0 = len(sig) - 1

        search_start = max(0, lag0 - max_shift)
        search_end = min(len(corr), lag0 + max_shift + 1)

        best_local_idx = int(np.argmax(corr[search_start:search_end]))
        best_lag = (search_start + best_local_idx) - lag0

        if best_lag == 0:
            aligned[:, k] = sig
        else:
            shifted = np.empty_like(sig)
            if best_lag > 0:
                shifted[:best_lag] = sig[0]
                shifted[best_lag:] = sig[:-best_lag]
            else:
                s = -best_lag
                shifted[-s:] = sig[-1]
                shifted[:-s] = sig[s:]
            aligned[:, k] = shifted

    return aligned


class DeconvController:
    def __init__(self, processor):
        self.processor = processor
        self.peaks = []  # peak dicts queued for deconvolution
        self.results = {}  # peak_idx → result dict
        self.params_used = {}  # peak_idx → params dict
        # excluded_samples: peak_idx → set of sample indices to exclude
        self.excluded_samples = {}

    # ── Peak management ───────────────────────────────────────────────────────

    def set_peaks(self, peaks):
        self.peaks = list(peaks)
        self.results = {}
        self.excluded_samples = {}

    def get_peaks(self):
        return self.peaks

    def add_peak(self, peak, target_ppm=None):
        for i, p in enumerate(self.peaks):
            if abs(p['ppm'] - peak['ppm']) < 0.001:
                return i, self._find_sub(i, target_ppm)
        self.peaks.append(peak)
        return len(self.peaks) - 1, 0

    def _find_sub(self, peak_idx, target_ppm):
        if target_ppm is None:
            return 0
        subs = self.results.get(peak_idx, {}).get('peaks', [])
        if not subs:
            return 0
        return min(range(len(subs)),
                   key=lambda j: abs(subs[j]['ppm'] - target_ppm))

    def set_excluded_samples(self, peak_idx, excluded):
        """Set which sample indices to exclude for peak[peak_idx]."""
        self.excluded_samples[peak_idx] = set(excluded)

    def get_excluded_samples(self, peak_idx):
        return self.excluded_samples.get(peak_idx, set())

    # ── Spectrum extraction ───────────────────────────────────────────────────

    def get_peak_data(self, peak_idx, context_ppm=None):
        """Spectrum slice around peak[peak_idx] using processor.mean_intensity."""
        if peak_idx >= len(self.peaks):
            return None
        p = self.peaks[peak_idx]
        ctx = context_ppm if context_ppm is not None else CONTEXT_PPM
        lo = min(p.get('start_ppm', p['ppm']),
                 p.get('end_ppm', p['ppm'])) - ctx
        hi = max(p.get('start_ppm', p['ppm']),
                 p.get('end_ppm', p['ppm'])) + ctx
        if (hi - lo) < 0.1:
            mid = (lo + hi) / 2
            lo, hi = mid - 0.05, mid + 0.05
        mask = (self.processor.ppm >= lo) & (self.processor.ppm <= hi)
        ppm = self.processor.ppm[mask]
        y = self.processor.mean_intensity[mask]
        if len(ppm) < 3:
            return None
        return {'ppm': ppm, 'intensity': y, 'lo': lo, 'hi': hi}

    def get_mean_excluding(self, peak_idx):
        """Compute mean excluding excluded_samples for peak[peak_idx].
        Returns processor.mean_intensity if no exclusions or no raw data."""
        excluded = self.get_excluded_samples(peak_idx)
        if not excluded:
            return self.processor.mean_intensity
        app = getattr(self.processor, 'app', None)
        raw = getattr(app, 'all_intensities', None)
        si = getattr(app, 'samples_info', [])
        if raw is None or raw.ndim < 2:
            return self.processor.mean_intensity
        # Build group mean from non-BLK, non-excluded samples
        from collections import defaultdict
        groups = defaultdict(list)
        for i, s in enumerate(si):
            stype = s.get('type', s.get('label', 'Sample'))
            if str(stype).upper() != 'BLK' \
                    and not s.get('excluded', False) \
                    and i not in excluded \
                    and i < raw.shape[1]:
                groups[s.get('label', 'unknown')].append(i)
        if not groups:
            return self.processor.mean_intensity
        gmeans = np.stack(
            [np.mean(raw[:, idxs], axis=1) for idxs in groups.values()],
            axis=1)
        return np.mean(gmeans, axis=1)

    # ── Deconvolution ─────────────────────────────────────────────────────────

    def deconvolve_peak(self, peak_idx, params):
        """
        Run deconvolution for peak[peak_idx].
        Stores result in self.results — does NOT touch processor.peaks.
        Respects excluded_samples by recomputing mean without them.
        """
        if peak_idx >= len(self.peaks):
            return None
        p = self.peaks[peak_idx]

        # Fit window = peak boundaries (tight)
        fit_lo = min(p.get('start_ppm', p['ppm']),
                     p.get('end_ppm', p['ppm']))
        fit_hi = max(p.get('start_ppm', p['ppm']),
                     p.get('end_ppm', p['ppm']))
        if (fit_hi - fit_lo) < 0.01:
            mid = (fit_lo + fit_hi) / 2
            fit_lo, fit_hi = mid - 0.005, mid + 0.005

        # Use mean excluding removed samples
        mean_vec = self.get_mean_excluding(peak_idx)
        mask = (self.processor.ppm >= fit_lo) & (self.processor.ppm <= fit_hi)
        x = self.processor.ppm[mask]
        y = mean_vec[mask]
        if len(x) < 5:
            return None

        app = getattr(self.processor, 'app', None)
        raw = getattr(app, 'all_intensities', None)

        if raw is not None and raw.ndim >= 2:
            si_list = getattr(app, 'samples_info', [])
            excl = set(self.get_excluded_samples(peak_idx))
            # also exclude samples deselected in the visualization panel
            excl |= {k for k, s in enumerate(si_list)
                     if s.get('excluded', False)}
            valid_cols = [k for k in range(raw.shape[1]) if k not in excl]
            if not valid_cols:
                valid_cols = list(range(raw.shape[1]))

            y_samples_full = raw[mask, :]

            # Find the best reference sample among valid samples (one with highest peak)
            max_vals = np.max(y_samples_full[:, valid_cols], axis=0)
            best_valid_local_idx = int(np.argmax(max_vals))
            ref_idx = valid_cols[best_valid_local_idx]

            # Align samples for per-sample NNLS only — do NOT change y used for the
            # main fit so that the displayed spectrum (proc.mean_intensity) and the
            # fitted curves share the same amplitude scale.
            y_samples_aligned = _local_align_to_ref(y_samples_full, ref_idx)
            y_samples = y_samples_aligned

            # y stays as the mean of valid (non-excluded) samples in original scale
            y = np.mean(y_samples_full[:, valid_cols], axis=1)
        else:
            y_samples = None

        self.params_used[peak_idx] = params
        p_full = dict(params)
        p_full['noise_std'] = getattr(self.processor, 'noise_std', None)
        result = deconvolve_algorithm(
            x, y, p_full,
            progress_callback=params.get('_progress_cb'),
            y_samples=y_samples)

        if result and result.get('peaks'):
            ns = max(getattr(self.processor, 'noise_std', 1e-10), 1e-10)
            r2_region = result.get('r_squared', None)
            bic_region = result.get('bic', None)

            excl_list = sorted(self.get_excluded_samples(peak_idx))
            # Deconv R² threshold — from app if available, else default 0.95
            _app = getattr(self.processor, 'app', None)
            _deconv_r2 = float(getattr(_app, '_deconv_r2_min', 0.95))

            for sp in result['peaks']:
                sp['deconvolved'] = False
                sp['is_sub_peak'] = True
                sp['overlapping'] = False
                sp['parent_ppm'] = p['ppm']
                sp['excluded_samples'] = excl_list
                if r2_region is not None: sp.setdefault('r_squared', r2_region)
                if bic_region is not None: sp.setdefault('bic', bic_region)
                # Pre-assign status based on deconv R²:
                # Poor  → R² below threshold or unknown
                # None  → good fit, user reviews in Peak List
                r2_sp = sp.get('r_squared', r2_region)
                if r2_sp is None or float(r2_sp) < _deconv_r2:
                    sp['status'] = 'Poor'
                else:
                    sp['status'] = None  # user assigns Good/Undefined
                w = sp.get('width', sp.get('width_ppm', 0.005))
                sp['width_ppm'] = float(w)
                sp['width_at_half'] = float(w)
                sp.setdefault('start_ppm', sp['ppm'] + 2 * w)
                sp.setdefault('end_ppm', sp['ppm'] - 2 * w)
                sp.setdefault('snr', sp['height'] / ns)
                sp.setdefault('prominence', sp['height'] * 0.5)

            # Build lightweight sibling list — stored on each sub-peak so
            # PeakSampleView can reconstruct the full deconvolution in context
            # without needing a reference back to the controller.
            _sub_keys = ('ppm', 'width', 'width_ppm', 'height',
                         'height_per_sample', 'area_per_sample',
                         'model', 'eta', 'gamma',
                         'start_ppm', 'end_ppm')
            region_sub_peaks = [
                {k: sp[k] for k in _sub_keys if k in sp}
                for sp in result['peaks']
            ]
            for sp in result['peaks']:
                sp['region_sub_peaks'] = region_sub_peaks
                sp['region_ppm']       = x       # full ppm axis of the fitted region
                sp['region_intensity'] = y        # real mean spectrum of the region

            self.peaks[peak_idx]['_deconvolved'] = True
            result.update({
                'peak_ppm': p['ppm'],
                'region_ppm': x,
                'region_intensity': y,
                'params_used': params,
                'excluded_samples': list(self.get_excluded_samples(peak_idx)),
            })
            self.results[peak_idx] = result

        return result

    def restore_peak(self, peak_idx):
        """Undo deconvolution for peak[peak_idx].
        Removes result and clears _deconvolved flag.
        The original peak stays in self.peaks untouched.
        """
        if peak_idx in self.results:
            del self.results[peak_idx]
        if peak_idx < len(self.peaks):
            self.peaks[peak_idx].pop('_deconvolved', None)
            self.peaks[peak_idx].pop('has_sub_peaks', None)
            self.peaks[peak_idx].pop('deconvolved', None)

    def deconvolve_all(self, params):
        done = []
        for i, p in enumerate(self.peaks):
            if not p.get('_deconvolved'):
                r = self.deconvolve_peak(i, params)
                if r:
                    done.append(r)
        return done

    def get_all_sub_peaks(self):
        return [sp for res in self.results.values()
                for sp in res.get('peaks', [])]

    # ── Backward-compat shims ─────────────────────────────────────────────────

    def _find_child(self, peak_idx, target_ppm):
        return self._find_sub(peak_idx, target_ppm)

    @property
    def regions(self):
        return [(p.get('end_ppm', p['ppm']), p.get('start_ppm', p['ppm']))
                for p in self.peaks]

    @property
    def _region_meta(self):
        out = []
        for i, p in enumerate(self.peaks):
            res = self.results.get(i, {})
            out.append({
                'start': max(p.get('start_ppm', p['ppm']),
                             p.get('end_ppm', p['ppm'])),
                'end': min(p.get('start_ppm', p['ppm']),
                           p.get('end_ppm', p['ppm'])),
                'status': 'deconvolved' if p.get('_deconvolved') else 'pending',
                'n_peaks': len(res.get('peaks', [])) if p.get('_deconvolved') else 1,
                'peaks': [p],
            })
        return out

    def get_regions(self):
        """Shim for DeconvListPanel — returns region-style dicts."""
        out = []
        for i, p in enumerate(self.peaks):
            res = self.results.get(i, {})
            out.append({
                'status': 'deconvolved' if p.get('_deconvolved') else 'pending',
                'n_peaks': len(res.get('peaks', [])),
                'peaks': [p],
            })
        return out

    def get_region_data(self, region_idx, context_ppm=None):
        """Shim for DeconvListPanel — returns spectrum slice for region."""
        return self.get_peak_data(region_idx, context_ppm)

    def set_regions(self, regions):
        """Convert (lo,hi) region tuples into sub-regions of ≤ 3 peaks each.
        Each sub-region gets one representative entry (tallest peak) whose
        start_ppm/end_ppm span the sub-region so deconvolution fits all peaks
        inside it.
        """
        _MAX = 3
        new_peaks = []
        for lo, hi in regions:
            lo, hi = min(lo, hi), max(lo, hi)
            matched = sorted(
                [p for p in (self.processor.peaks or []) if lo <= p['ppm'] <= hi],
                key=lambda p: p['ppm'])
            if matched:
                n = len(matched)
                for i in range(0, n, _MAX):
                    chunk = matched[i:i + _MAX]
                    sub_lo = lo if i == 0 else (matched[i - 1]['ppm'] + matched[i]['ppm']) / 2
                    last   = min(i + _MAX, n) - 1
                    sub_hi = hi if (i + _MAX >= n) else (matched[last]['ppm'] + matched[last + 1]['ppm']) / 2
                    rep = max(chunk, key=lambda p: p.get('height', 0))
                    rp = dict(rep)
                    rp['start_ppm'] = sub_hi
                    rp['end_ppm']   = sub_lo
                    rp['overlapping'] = True
                    rp['_grouped_from'] = [p['ppm'] for p in chunk]
                    new_peaks.append(rp)
            else:
                new_peaks.append({
                    'ppm': (lo + hi) / 2, 'start_ppm': hi, 'end_ppm': lo,
                    'height': 1.0, 'snr': 1.0,
                    'width_ppm': hi - lo, 'width_at_half': hi - lo,
                    'rank': '?', 'overlapping': True,
                    'from_overlap_search': True,
                })
        self.set_peaks(new_peaks)