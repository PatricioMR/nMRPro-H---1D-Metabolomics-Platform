# gui/project_manager.py
"""
NMRAnalysis Project Manager.

Saves and restores the full application state to a .nmrproj file (pickle).
Auto-saves every 5 minutes when a project is open.

Saved state:
  - Raw data (ppm, all_intensities, samples_info, group_colors, source file path)
  - Peak detection (noise_std, peaks list, overlapping regions)
  - Deconvolution (queued peaks, results)
  - Annotation stage (db_path, results)
  - UI state (active stage, axes settings, plot settings)
"""
import os
import pickle
import threading
import time
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

PROJECT_EXT   = '.nmrproj'
AUTOSAVE_SECS = 300  # 5 minutes


def _safe_var(obj, attr):
    """Return the value of a tkinter Variable attribute, or None if missing."""
    try:
        return getattr(obj, attr).get()
    except Exception:
        return None


def _set_var(obj, attr, value):
    """Set a tkinter Variable attribute if it exists and value is not None."""
    if value is None:
        return
    try:
        getattr(obj, attr).set(value)
    except Exception:
        pass


class ProjectManager:
    def __init__(self, app):
        self.app          = app
        self._project_path = None   # current open project file
        self._dirty        = False  # unsaved changes
        self._autosave_job = None

    # ── Path helpers ──────────────────────────────────────────────────────────

    @property
    def project_path(self):
        return self._project_path

    @project_path.setter
    def project_path(self, value):
        self._project_path = value
        title = 'NMR Metabolomics'
        if value:
            title = f'NMR Metabolomics — {os.path.basename(value)}'
        try:
            self.app.root.title(title)
        except Exception:
            pass

    def mark_dirty(self):
        self._dirty = True

    # ── Serialisation ─────────────────────────────────────────────────────────

    def _collect_state(self):
        """Gather everything needed to restore the session."""
        import numpy as np
        app = self.app
        state = {
            'version':         3,
            # Raw data
            'ppm':             app.ppm,
            'all_intensities': app.all_intensities,
            'samples_info':    app.samples_info,
            'group_colors':    app.group_colors,
            'source_file':     app.current_file,
            # UI
            'active_stage':    getattr(app, 'active_stage', 'visualization'),
            'axes_settings':   getattr(app, 'axes_settings', {}),
            'plot_settings':   getattr(app, 'plot_settings', {}),
            'show_legend':     getattr(app, 'show_legend',
                                       tk.BooleanVar()).get(),
        }

        # Peak detection stage
        pd = app.stages.get('peak_detection')
        if pd:
            state['pd'] = {
                'noise_std':        pd.noise_std,
                'noise_source':     getattr(pd, 'noise_source', None),
                'peaks':            list(pd.peaks),
                '_overlaps':        list(getattr(pd, '_overlaps', [])),
                'step1_completed':  getattr(pd, 'step1_completed', False),
                'noise_start_var':  getattr(pd, 'noise_start_var',
                                            tk.DoubleVar()).get(),
                'noise_end_var':    getattr(pd, 'noise_end_var',
                                            tk.DoubleVar()).get(),
                'min_snr_var':      getattr(pd, 'min_snr_var',
                                            tk.DoubleVar()).get(),
                'min_width_var':    getattr(pd, 'min_width_var',
                                            tk.DoubleVar()).get(),
                'prominence_var':   getattr(pd, 'prominence_var',
                                            tk.DoubleVar()).get(),
            }
            ctrl = getattr(pd, '_deconv_controller', None)
            if ctrl:
                state['pd']['deconv'] = {
                    'peaks':            list(ctrl.peaks),
                    'results':          dict(ctrl.results),
                    'excluded_samples': {k: list(v)
                                         for k, v in ctrl.excluded_samples.items()},
                }

        # Annotation stage
        ann = app.stages.get('annotation')
        if ann:
            state['ann'] = {
                'db_path':            getattr(ann, '_db_path', None),
                'last_results_args':  getattr(ann, '_last_results_args', None),
                'annotations':        dict(getattr(ann, 'annotations', {})),
                'tolerance':          _safe_var(ann, 'tolerance_var'),
                'align':              _safe_var(ann, 'align_var'),
                'quality_marks':      dict(getattr(ann, '_quality_marks', {})),
                'child_quality_marks': dict(getattr(ann, '_child_quality_marks', {})),
            }

        # Quantification stage
        qnt = app.stages.get('quantification')
        if qnt:
            state['qnt'] = {
                'quant_results':    list(getattr(qnt, '_quant_results', [])),
                'integ':            _safe_var(qnt, 'integ_var'),
                'norm':             _safe_var(qnt, 'norm_var'),
                'proton_corr':      _safe_var(qnt, 'proton_corr_var'),
                'mcr':              _safe_var(qnt, 'mcr_var'),
                'blk_sub':          _safe_var(qnt, 'blk_sub_var'),
                'ext_is':           _safe_var(qnt, 'ext_is_var'),
                'ext_is_indices':   list(getattr(qnt, '_ext_is_indices', [])),
                'ext_is_label':     (qnt._ext_is_label.cget('text')
                                     if getattr(qnt, '_ext_is_label', None) else ''),
                'ref_ppm':          _safe_var(qnt, 'ref_ppm_var'),
                'ref_nh':           _safe_var(qnt, 'ref_nh_var'),
                'ref_conc':         _safe_var(qnt, 'ref_conc_var'),
                'ref_std':          _safe_var(qnt, 'ref_std_var'),
                'ref_rank':         _safe_var(qnt, 'ref_rank_var'),
                # run-time caches for update_sample_area
                'last_norm_mode':   getattr(qnt, '_last_norm_mode',   None),
                'last_ref_areas':   getattr(qnt, '_last_ref_areas',   None),
                'last_ref_conc':    getattr(qnt, '_last_ref_conc',    None),
                'last_sample_dil':  (getattr(qnt, '_last_sample_dil', None).tolist()
                                     if getattr(qnt, '_last_sample_dil', None) is not None else None),
                'last_groups':      getattr(qnt, '_last_groups',      None),
                'last_blk_indices': getattr(qnt, '_last_blk_indices', None),
                'last_non_blk':     getattr(qnt, '_last_non_blk_indices', None),
            }
            state['group_dilution_factors'] = dict(
                getattr(app, 'group_dilution_factors', {}))
        # Peak list filter state
        state['peak_list_filters'] = dict(getattr(app, '_peak_list_filters', {}))

        # Notation stage (STEP 3 search results in notation panel)
        ns = app.stages.get('notation')
        if ns:
            state['ns'] = {
                'peaks': list(getattr(ns, 'peaks', [])),
            }

        return state

    def _restore_state(self, state):
        """Restore application state from a saved dict."""
        import numpy as np
        app = self.app

        # Raw data
        app.ppm             = state.get('ppm')
        app.all_intensities = state.get('all_intensities')
        app.samples_info    = state.get('samples_info', [])
        app.group_colors    = state.get('group_colors', app.group_colors)
        app.current_file    = state.get('source_file')
        app._peak_list_filters = state.get('peak_list_filters',
                                           getattr(app, '_peak_list_filters', {}))

        # UI settings
        if state.get('axes_settings'):
            app.axes_settings.update(state['axes_settings'])
        if state.get('plot_settings'):
            app.plot_settings.update(state['plot_settings'])
        try:
            app.show_legend.set(state.get('show_legend', True))
        except Exception:
            pass

        # Update file label
        try:
            fname = os.path.basename(app.current_file) if app.current_file else 'No file loaded'
            app.file_label.config(text=fname)
        except Exception:
            pass

        # Refresh sample list in visualization
        try:
            app.stages['visualization'].refresh_sample_list()
            app.btn_select_all.config(state='normal')
            app.btn_clear_all.config(state='normal')
            app.btn_update.config(state='normal')
        except Exception:
            pass

        # Peak detection stage
        pd_state = state.get('pd')
        pd       = app.stages.get('peak_detection')
        if pd_state and pd:
            pd.noise_std       = pd_state.get('noise_std')
            pd.noise_source    = pd_state.get('noise_source')
            pd.peaks           = pd_state.get('peaks', [])
            pd._overlaps       = pd_state.get('_overlaps', [])
            pd.step1_completed = pd_state.get('step1_completed', False)
            try:
                pd.noise_start_var.set(pd_state['noise_start_var'])
                pd.noise_end_var.set(pd_state['noise_end_var'])
                pd.min_snr_var.set(pd_state['min_snr_var'])
                pd.min_width_var.set(pd_state['min_width_var'])
                pd.prominence_var.set(pd_state['prominence_var'])
            except Exception:
                pass
            # ── Restore processor fully ──────────────────────────────────
            if pd.processor and app.ppm is not None:
                try:
                    if pd.noise_std:
                        pd.processor.set_noise(pd.noise_std)
                    pd.processor.ppm   = app.ppm
                    pd.processor.peaks = list(pd.peaks)
                    # Rebuild mean_intensity from group-mean no-BLK
                    from gui.stages.peak_detection_stage import _no_blk_group_mean
                    pd.processor.mean_intensity = _no_blk_group_mean(
                        app.all_intensities, app.samples_info)
                    pd.processor.all_intensities = app.all_intensities
                except Exception as _e:
                    print(f'  processor restore: {_e}')

            # ── Restore UI buttons ────────────────────────────────────────
            try:
                if pd.noise_std is not None:
                    pd.step1_completed = True
                    pd.noise_value_label.config(
                        text=f'Noise Std Dev: {pd.noise_std:.4f}')
                    pd.step1_status.config(
                        text='✅ Completed', foreground='green')
                    pd.btn_detect.config(state='normal')
                if pd.peaks:
                    pd.peaks_count_label.config(
                        text=f'Found {len(pd.peaks)} peaks')
                    pd.step2_status.config(
                        text=f'✅ {len(pd.peaks)} peaks detected',
                        foreground='green')
                    pd.btn_find_overlaps.config(state='normal')
                    try: pd.app.btn_peak_list.config(state='normal')
                    except Exception: pass
                if getattr(pd, '_overlaps', []):
                    n = len(pd._overlaps)
                    pd.btn_open_deconv.config(state='normal')
                    pd.deconv_status.config(
                        text=f'{n} peak(s) queued for deconvolution',
                        foreground='orange')
                    try: pd.app.btn_deconv_shortcut.config(state='normal')
                    except Exception: pass
            except Exception as _e:
                print(f'  UI restore: {_e}')
            # Restore deconv controller
            deconv_state = pd_state.get('deconv')
            if deconv_state and pd._overlaps:
                try:
                    from gui.notation.deconvolution import DeconvController
                    ctrl             = DeconvController(pd.processor)
                    ctrl.peaks       = deconv_state.get('peaks', [])
                    ctrl.results     = deconv_state.get('results', {})
                    ctrl.excluded_samples = {
                        k: set(v)
                        for k, v in deconv_state.get(
                            'excluded_samples', {}).items()}
                    pd._deconv_controller = ctrl
                except Exception as e:
                    print(f'  deconv controller restore: {e}')

        # Annotation stage
        ann_state = state.get('ann')
        ann       = app.stages.get('annotation')
        if ann_state and ann:
            try:
                if ann_state.get('db_path'):
                    ann._db_path = ann_state['db_path']
                if ann_state.get('last_results_args'):
                    ann._last_results_args = ann_state['last_results_args']
                    try:
                        app.btn_annot_shortcut.config(state='normal')
                    except Exception:
                        pass
                if ann_state.get('annotations'):
                    ann.annotations = ann_state['annotations']
                _set_var(ann, 'tolerance_var', ann_state.get('tolerance'))
                _set_var(ann, 'align_var',     ann_state.get('align'))
                # Restore quality marks (parent and child)
                if ann_state.get('quality_marks'):
                    ann._quality_marks = ann_state['quality_marks']
                    # Re-apply annotation_quality into mp dicts so the
                    # results window shows correct colours on reopen
                    _results = (ann._last_results_args or {}).get('results', [])
                    for r in _results:
                        mid = (r.get('hmdb_id') or r.get('bmrb_id')
                               or r.get('id', r.get('name', '')))
                        key = (mid, r.get('peak_rank'))
                        if key in ann._quality_marks:
                            r['annotation_quality'] = ann._quality_marks[key]
                if ann_state.get('child_quality_marks'):
                    ann._child_quality_marks = ann_state['child_quality_marks']
            except Exception as _e:
                print(f'  annotation restore: {_e}')

        # Quantification stage
        qnt_state = state.get('qnt')
        qnt       = app.stages.get('quantification')
        if qnt_state and qnt:
            try:
                results = qnt_state.get('quant_results', [])
                if results:
                    qnt._quant_results = results
                    try:
                        qnt.btn_csv.config(state='normal')
                        qnt.btn_metaboanalyst.config(state='normal')
                    except Exception:
                        pass
                _set_var(qnt, 'integ_var',        qnt_state.get('integ'))
                _set_var(qnt, 'norm_var',          qnt_state.get('norm'))
                _set_var(qnt, 'proton_corr_var',   qnt_state.get('proton_corr'))
                _set_var(qnt, 'mcr_var',           qnt_state.get('mcr'))
                _set_var(qnt, 'blk_sub_var',       qnt_state.get('blk_sub'))
                _set_var(qnt, 'ext_is_var',        qnt_state.get('ext_is'))
                _set_var(qnt, 'ref_ppm_var',       qnt_state.get('ref_ppm'))
                _set_var(qnt, 'ref_nh_var',        qnt_state.get('ref_nh'))
                _set_var(qnt, 'ref_conc_var',      qnt_state.get('ref_conc'))
                _set_var(qnt, 'ref_std_var',       qnt_state.get('ref_std'))
                _set_var(qnt, 'ref_rank_var',      qnt_state.get('ref_rank'))
                # Restore External IS state
                ei = qnt_state.get('ext_is_indices')
                if ei is not None:
                    qnt._ext_is_indices = list(ei)
                lbl = qnt_state.get('ext_is_label', '')
                if lbl and getattr(qnt, '_ext_is_label', None):
                    try: qnt._ext_is_label.config(text=lbl)
                    except Exception: pass
                # Restore run-time caches
                import numpy as _np
                if qnt_state.get('last_norm_mode') is not None:
                    qnt._last_norm_mode = qnt_state['last_norm_mode']
                if qnt_state.get('last_ref_areas') is not None:
                    qnt._last_ref_areas = qnt_state['last_ref_areas']
                if qnt_state.get('last_ref_conc') is not None:
                    qnt._last_ref_conc = qnt_state['last_ref_conc']
                if qnt_state.get('last_sample_dil') is not None:
                    qnt._last_sample_dil = _np.array(qnt_state['last_sample_dil'])
                if qnt_state.get('last_groups') is not None:
                    qnt._last_groups = qnt_state['last_groups']
                if qnt_state.get('last_blk_indices') is not None:
                    qnt._last_blk_indices = qnt_state['last_blk_indices']
                if qnt_state.get('last_non_blk') is not None:
                    qnt._last_non_blk_indices = qnt_state['last_non_blk']
            except Exception as _e:
                print(f'  quantification restore: {_e}')

        # Redraw
        try:
            app.update_plot()
            if pd and pd.peaks:
                pd.color_peaks()
        except Exception as e:
            print(f'  redraw after restore: {e}')

        # Switch to saved active stage
        try:
            stage = state.get('active_stage', 'visualization')
            if stage in app.stages:
                app.switch_stage(stage)
        except Exception:
            pass

    # ── File operations ───────────────────────────────────────────────────────

    def save_project(self, path=None):
        """Save to path. If None, opens Save-As dialog."""
        if path is None:
            path = filedialog.asksaveasfilename(
                title='Save Project',
                defaultextension=PROJECT_EXT,
                filetypes=[('NMR Project', f'*{PROJECT_EXT}'),
                           ('All files', '*.*')])
            if not path:
                return False

        try:
            state = self._collect_state()
            with open(path, 'wb') as f:
                pickle.dump(state, f, protocol=5)
            self.project_path = path
            self._dirty       = False
            self.app.root.after(
                0, lambda: self.app.status_label.config(
                    text=f'Project saved: {os.path.basename(path)}',
                    foreground='green'))
            return True
        except Exception as e:
            messagebox.showerror('Save Error',
                                 f'Could not save project:\n{e}')
            return False

    def open_project(self, path=None):
        """Open a project file, restoring full state."""
        if self._dirty:
            if not messagebox.askyesno(
                    'Unsaved Changes',
                    'Current session has unsaved changes.\n'
                    'Open a new project anyway?'):
                return False

        if path is None:
            path = filedialog.askopenfilename(
                title='Open Project',
                filetypes=[('NMR Project', f'*{PROJECT_EXT}'),
                           ('All files', '*.*')])
            if not path:
                return False

        try:
            self.app.status_label.config(
                text='Loading project…', foreground='blue')
            self.app.root.update_idletasks()

            with open(path, 'rb') as f:
                state = pickle.load(f)

            self._restore_state(state)
            self.project_path = path
            self._dirty       = False
            self.app.status_label.config(
                text=f'Project opened: {os.path.basename(path)}',
                foreground='green')
            self._start_autosave()
            return True
        except Exception as e:
            import traceback; traceback.print_exc()
            messagebox.showerror('Open Error',
                                 f'Could not open project:\n{e}')
            return False

    def save_or_saveas(self):
        """Save to current path, or Save-As if no project open."""
        if self._project_path:
            return self.save_project(self._project_path)
        return self.save_project()

    # ── Auto-save ─────────────────────────────────────────────────────────────

    def _start_autosave(self):
        self._stop_autosave()
        self._schedule_autosave()

    def _stop_autosave(self):
        if self._autosave_job is not None:
            try:
                self.app.root.after_cancel(self._autosave_job)
            except Exception:
                pass
            self._autosave_job = None

    def _schedule_autosave(self):
        self._autosave_job = self.app.root.after(
            AUTOSAVE_SECS * 1000, self._autosave_tick)

    def _autosave_tick(self):
        if self._project_path:
            # Save to a .autosave companion file
            autosave_path = self._project_path + '.autosave'
            try:
                state = self._collect_state()
                with open(autosave_path, 'wb') as f:
                    pickle.dump(state, f, protocol=5)
                self.app.status_label.config(
                    text=f'Auto-saved  {time.strftime("%H:%M")}',
                    foreground='gray')
            except Exception as e:
                print(f'  autosave failed: {e}')
        self._schedule_autosave()  # reschedule