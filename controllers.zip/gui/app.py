# gui/app.py
import tkinter as tk
from tkinter import filedialog, messagebox, colorchooser
from tkinter import ttk
import matplotlib

matplotlib.use('TkAgg')
matplotlib.rcParams['path.simplify'] = True
matplotlib.rcParams['path.simplify_threshold'] = 0.1
matplotlib.rcParams['agg.path.chunksize'] = 10000

matplotlib.use('TkAgg')
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
import os
import sys
import numpy as np

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from data.loader import load_all_samples
from plotting.spectrum import plot_spectrum, plot_multiple_spectra
from gui.stages.visualization_stage import VisualizationStage
from gui.stages.peak_detection_stage import PeakDetectionStage
from gui.stages.annotation_stage import AnnotationStage
from gui.stages.quantification_stage import QuantificationStage
from gui.stages.fullspectrum_mcr_stage import FullSpectrumMCRStage
from gui.stages.statistics_stage import StatisticsStage


class App:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("NMR Metabolomics Viewer")
        self.root.state('zoomed')
        self.screen_width = self.root.winfo_screenwidth()
        self.screen_height = self.root.winfo_screenheight()
        self.root.minsize(1000, 600)

        # ---------- Data shared between stages ----------
        self.current_file = None
        self.samples_info = []
        self.all_intensities = None
        self.ppm = None

        # Group colors configuration
        self.group_colors = {
            'CTRL': '#2E86AB',
            'G1': '#A23B72',
            'G2': '#F18F01',
            'G3': '#17BEBB',
            'BLK': '#C73E1D',
            'Unknown': '#593C8F'
        }
        self.group_dilution_factors = {}   # {group_label: float}

        self.show_legend = tk.BooleanVar(value=True)
        self._project_mgr = None
        self.plot_settings = {
            'background': '#FFFFFF',
            'grid_style': '--',
            'line_width': 0.5,
            'transparency': 0.8,
            'font_size': 10
        }
        self.axes_settings = {
            'x_label': 'δ (ppm)',
            'y_label': 'Intensity',
            'x_lim': None,
            'y_lim': None
        }

        # Shared InteractivePlotManager — used by all stages
        self.plot_manager = None

        # Singleton references for secondary windows
        self._peak_list_win = None
        self._deconv_win = None
        self._annot_win = None

        # UI Elements that will be created in stages
        self.btn_import = None
        self.file_label = None
        self.btn_select_all = None
        self.btn_clear_all = None
        self.btn_update = None

        # ---------- Stage control ----------
        self.active_stage = None
        self.stages = {}

        # Create menu
        self.create_menu()

        # Create stage toolbar and main layout
        self.create_stage_toolbar()
        self.create_main_layout()

        # Initialize stages
        self.initialize_stages()

    def initialize_stages(self):
        """Create all stage instances."""
        self.stages['visualization'] = VisualizationStage(self.left_panel, self)
        self.stages['peak_detection'] = PeakDetectionStage(self.left_panel, self)
        self.stages['annotation'] = AnnotationStage(
            self.left_panel, self,
            peak_stage=self.stages['peak_detection'])

        self.stages['quantification'] = QuantificationStage(
            self.left_panel, self,
            peak_stage=self.stages['peak_detection'],
            annotation_stage=self.stages['annotation'])

        self.stages['fullspectrum_mcr'] = FullSpectrumMCRStage(
            self.left_panel, self,
            annotation_stage=self.stages['annotation'])

        self.stages['statistics'] = StatisticsStage(self.left_panel, self)

        # Activate visualization by default
        self.switch_stage('visualization')

    # ---------- Menu ----------
    def create_menu(self):
        """Create the main menu bar"""
        menubar = tk.Menu(self.root)
        self.root.config(menu=menubar)

        # File menu
        file_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label='File', menu=file_menu)
        file_menu.add_command(label='Save Project…',
                              command=self._save_project_as,
                              accelerator='Ctrl+Shift+S')
        file_menu.add_command(label='Open Project…',
                              command=self._open_project,
                              accelerator='Ctrl+O')
        file_menu.add_separator()
        file_menu.add_command(label='Save',
                              command=self._save,
                              accelerator='Ctrl+S')

        # Edit menu
        edit_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Edit", menu=edit_menu)

        # Groups submenu
        groups_menu = tk.Menu(edit_menu, tearoff=0)
        edit_menu.add_cascade(label="Groups", menu=groups_menu)
        groups_menu.add_command(label="Edit Groups and Colors...", command=self.open_group_editor)

        edit_menu.add_separator()
        edit_menu.add_command(label="Axes Settings...", command=self.open_axes_settings)

        edit_menu.add_separator()
        edit_menu.add_command(
            label="Show/Hide Peak Areas",
            command=self.toggle_peak_areas)

        # Add separator and debug here
        edit_menu.add_separator()
        # ── Plot Settings ──
        plot_settings_menu = tk.Menu(edit_menu, tearoff=0)
        edit_menu.add_cascade(label="Plot Settings", menu=plot_settings_menu)

        plot_settings_menu.add_command(
            label="Background Color...",
            command=self.set_background_color)

        grid_menu = tk.Menu(plot_settings_menu, tearoff=0)
        plot_settings_menu.add_cascade(label="Grid Style", menu=grid_menu)
        for _style, _label in [('--', 'Dashed'), ('-', 'Solid'), (':', 'Dotted'), ('none', 'None')]:
            grid_menu.add_command(
                label=_label,
                command=lambda s=_style: self.set_grid_style(s))

        lw_menu = tk.Menu(plot_settings_menu, tearoff=0)
        plot_settings_menu.add_cascade(label="Line Width", menu=lw_menu)
        for _w in [0.3, 0.5, 0.8, 1.0, 1.5, 2.0]:
            lw_menu.add_command(
                label=str(_w),
                command=lambda v=_w: self.set_line_width(v))

        tr_menu = tk.Menu(plot_settings_menu, tearoff=0)
        plot_settings_menu.add_cascade(label="Transparency", menu=tr_menu)
        for _a in [0.3, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0]:
            tr_menu.add_command(
                label=str(_a),
                command=lambda v=_a: self.set_transparency(v))

        fs_menu = tk.Menu(plot_settings_menu, tearoff=0)
        plot_settings_menu.add_cascade(label="Font Size", menu=fs_menu)
        for _s in [8, 9, 10, 11, 12, 14]:
            fs_menu.add_command(
                label=str(_s),
                command=lambda v=_s: self.set_font_size(v))

        plot_settings_menu.add_separator()
        plot_settings_menu.add_command(
            label="Reset to Default",
            command=self.reset_plot_settings)

        edit_menu.add_separator()
        edit_menu.add_command(label="🔍 Debug Peak Flow", command=self.open_peak_debugger)

        # View menu
        view_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="View", menu=view_menu)

        view_menu.add_checkbutton(label="Show Legend", variable=self.show_legend,
                                  command=self.toggle_legend)

        # Resolving Method
        resolving_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label='🔀 Resolving', menu=resolving_menu)
        resolving_menu.add_command(
            label='Resolving Method…',
            command=self._open_resolving_method)

        # Plot Settings moved to Edit menu

    # ---------- Stage Toolbar ----------
    def create_stage_toolbar(self):
        stage_frame = ttk.Frame(self.root)
        stage_frame.pack(side=tk.TOP, fill=tk.X, padx=5, pady=5)

        style = ttk.Style()
        style.configure('Stage.TButton', font=('Arial', 10))
        style.configure('ActiveStage.TButton', font=('Arial', 10, 'bold'))

        self.btn_visualization = ttk.Button(
            stage_frame, text="1. 📊 Visualization",
            command=lambda: self.switch_stage('visualization'),
            style='ActiveStage.TButton'
        )
        self.btn_visualization.pack(side=tk.LEFT, padx=2)

        self.btn_peak_detection = ttk.Button(
            stage_frame, text="2. 🔍 Peak Detection",
            command=lambda: self.switch_stage('peak_detection'),
            style='Stage.TButton'
        )
        self.btn_peak_detection.pack(side=tk.LEFT, padx=2)

        self.btn_annotation = ttk.Button(
            stage_frame, text="3. 🧪 Annotation",
            command=lambda: self.switch_stage('annotation'),
            style='Stage.TButton'
        )
        self.btn_annotation.pack(side=tk.LEFT, padx=2)

        self.btn_mcr_analysis = ttk.Button(
            stage_frame, text="4. 🔬 MCR Analysis",
            command=lambda: self.switch_stage('fullspectrum_mcr'),
            style='Stage.TButton'
        )
        self.btn_mcr_analysis.pack(side=tk.LEFT, padx=2)

        self.btn_quantification = ttk.Button(
            stage_frame, text="5. ⚗ Quantification",
            command=lambda: self.switch_stage('quantification'),
            style='Stage.TButton'
        )
        self.btn_quantification.pack(side=tk.LEFT, padx=2)

        self.btn_statistics = ttk.Button(
            stage_frame, text="6. 📊 Statistics",
            command=lambda: self.switch_stage('statistics'),
            style='Stage.TButton'
        )
        self.btn_statistics.pack(side=tk.LEFT, padx=2)

    def switch_stage(self, stage_name):
        """Switch between analysis stages."""
        if self.active_stage == stage_name:
            return

        # Deactivate current stage
        if self.active_stage and self.active_stage in self.stages:
            self.stages[self.active_stage].on_deactivate()

        for name, btn in {
            'visualization':   self.btn_visualization,
            'fullspectrum_mcr': self.btn_mcr_analysis,
            'peak_detection':  self.btn_peak_detection,
            'annotation':      self.btn_annotation,
            'quantification':  self.btn_quantification,
            'statistics':      self.btn_statistics,
        }.items():
            btn.configure(
                style='ActiveStage.TButton'
                if name == stage_name else 'Stage.TButton')

        # Activate new stage
        self.active_stage = stage_name
        self.stages[stage_name].on_activate()

    # ---------- Main Layout ----------
    def create_main_layout(self):
        self.main_container = ttk.Frame(self.root)
        self.main_container.pack(fill=tk.BOTH, expand=True, padx=2, pady=2)

        # Left panel (for stages)
        self.left_panel = ttk.Frame(self.main_container, width=320, relief=tk.SUNKEN, borderwidth=2)
        self.left_panel.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 2), pady=0)
        self.left_panel.pack_propagate(False)

        # Right panel (plot)
        self.right_panel = ttk.Frame(self.main_container)
        self.right_panel.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

        # Matplotlib figure
        self.figure = plt.Figure(figsize=(self.screen_width / 100, self.screen_height / 100),
                                 dpi=100, tight_layout=True)
        self.ax = self.figure.add_subplot(111)
        self.ax.set_facecolor(self.plot_settings['background'])
        self.figure.patch.set_facecolor(self.plot_settings['background'])

        # Bottom button bar — packed BEFORE canvas so tkinter reserves space.
        _btn_bar = ttk.Frame(self.right_panel)
        _btn_bar.pack(side=tk.BOTTOM, fill=tk.X, padx=4, pady=4)

        self.btn_peak_list = ttk.Button(
            _btn_bar, text="📋 Peak List",
            command=self.open_peak_list, state="disabled")
        self.btn_peak_list.pack(side=tk.LEFT, padx=4)

        self.btn_annot_shortcut = ttk.Button(
            _btn_bar, text="🔬 Annotation Results",
            command=self.open_annot_shortcut, state="disabled")
        self.btn_annot_shortcut.pack(side=tk.LEFT, padx=4)

        self.btn_deconv_shortcut = ttk.Button(
            _btn_bar, text="🔀 Deconvolution",
            command=self.open_deconv_shortcut, state="disabled")
        self.btn_deconv_shortcut.pack(side=tk.LEFT, padx=4)

        # Create canvas first
        self.canvas = FigureCanvasTkAgg(self.figure, master=self.right_panel)
        self.canvas.draw()

        # Build toolbar with canvas
        self.toolbar = NavigationToolbar2Tk(self.canvas, self.right_panel)
        self.toolbar.update()

        # Ensure Toolbar is at Bottom and Canvas is at Top expanding
        self.toolbar.pack(side=tk.BOTTOM, fill=tk.X)
        self.canvas.get_tk_widget().pack(side=tk.TOP, fill=tk.BOTH, expand=True)

        # Initialise the shared InteractivePlotManager once.
        # All stages use self.app.plot_manager — no per-stage instance.
        try:
            from plotting.interactive import InteractivePlotManager
            self.plot_manager = InteractivePlotManager(
                self.figure, self.ax, self.canvas, self)
            print('✅ Shared InteractivePlotManager initialised')
        except Exception as e:
            print(f'❌ PlotManager: {e}')

        # Status bar
        status_frame = ttk.Frame(self.root)
        status_frame.pack(side=tk.BOTTOM, fill=tk.X, padx=5, pady=2)
        self.status_label = ttk.Label(status_frame, text="Ready", foreground="gray")
        self.status_label.pack(side=tk.LEFT)
        self.samples_count_label = ttk.Label(status_frame, text="", foreground="gray")
        self.samples_count_label.pack(side=tk.RIGHT)

    # ---------- Axes Settings Dialog ----------
    def open_axes_settings(self):
        if self.ppm is None:
            messagebox.showinfo("Info", "Please load data first.")
            return

        dialog = tk.Toplevel(self.root)
        dialog.title("Axes Settings (NMR: ppm decreases left to right)")
        dialog.geometry("420x400")
        dialog.transient(self.root)
        dialog.grab_set()
        dialog.focus_set()

        main_frame = ttk.Frame(dialog, padding=10)
        main_frame.pack(fill=tk.BOTH, expand=True)

        # Labels
        ttk.Label(main_frame, text="Axis Labels", font=("Arial", 10, "bold")).grid(row=0, column=0, columnspan=2,
                                                                                   pady=5, sticky=tk.W)
        ttk.Label(main_frame, text="X Label:").grid(row=1, column=0, padx=5, pady=2, sticky=tk.W)
        x_label_var = tk.StringVar(value=self.axes_settings['x_label'])
        x_label_entry = ttk.Entry(main_frame, textvariable=x_label_var, width=30)
        x_label_entry.grid(row=1, column=1, padx=5, pady=2, sticky=tk.W)

        ttk.Label(main_frame, text="Y Label:").grid(row=2, column=0, padx=5, pady=2, sticky=tk.W)
        y_label_var = tk.StringVar(value=self.axes_settings['y_label'])
        y_label_entry = ttk.Entry(main_frame, textvariable=y_label_var, width=30)
        y_label_entry.grid(row=2, column=1, padx=5, pady=2, sticky=tk.W)

        ttk.Separator(main_frame, orient='horizontal').grid(row=3, column=0, columnspan=2, pady=10, sticky=tk.EW)

        # Ranges with NMR explanation
        ttk.Label(main_frame, text="Axis Ranges (NMR: ppm decreases left to right)",
                  font=("Arial", 10, "bold")).grid(row=4, column=0, columnspan=2, pady=5, sticky=tk.W)

        ttk.Label(main_frame, text="Left value (max ppm) → Right value (min ppm)",
                  font=("Arial", 9, "italic"), foreground="blue").grid(row=5, column=0, columnspan=2, pady=2,
                                                                       sticky=tk.W)

        # X range (ppm)
        ttk.Label(main_frame, text="X Min (left):").grid(row=6, column=0, padx=5, pady=2, sticky=tk.W)
        x_min_var = tk.StringVar()
        if self.axes_settings['x_lim'] is not None:
            x_min_var.set(f"{self.axes_settings['x_lim'][1]:.4f}")  # Max value (left)
        x_min_entry = ttk.Entry(main_frame, textvariable=x_min_var, width=15)
        x_min_entry.grid(row=6, column=1, padx=5, pady=2, sticky=tk.W)

        ttk.Label(main_frame, text="X Max (right):").grid(row=7, column=0, padx=5, pady=2, sticky=tk.W)
        x_max_var = tk.StringVar()
        if self.axes_settings['x_lim'] is not None:
            x_max_var.set(f"{self.axes_settings['x_lim'][0]:.4f}")  # Min value (right)
        x_max_entry = ttk.Entry(main_frame, textvariable=x_max_var, width=15)
        x_max_entry.grid(row=7, column=1, padx=5, pady=2, sticky=tk.W)

        # Y range (normal)
        ttk.Label(main_frame, text="Y Min (bottom):").grid(row=8, column=0, padx=5, pady=2, sticky=tk.W)
        y_min_var = tk.StringVar()
        if self.axes_settings['y_lim'] is not None:
            y_min_var.set(f"{self.axes_settings['y_lim'][0]:.4f}")
        y_min_entry = ttk.Entry(main_frame, textvariable=y_min_var, width=15)
        y_min_entry.grid(row=8, column=1, padx=5, pady=2, sticky=tk.W)

        ttk.Label(main_frame, text="Y Max (top):").grid(row=9, column=0, padx=5, pady=2, sticky=tk.W)
        y_max_var = tk.StringVar()
        if self.axes_settings['y_lim'] is not None:
            y_max_var.set(f"{self.axes_settings['y_lim'][1]:.4f}")
        y_max_entry = ttk.Entry(main_frame, textvariable=y_max_var, width=15)
        y_max_entry.grid(row=9, column=1, padx=5, pady=2, sticky=tk.W)

        # Buttons
        btn_frame = ttk.Frame(main_frame)
        btn_frame.grid(row=10, column=0, columnspan=2, pady=15)

        def apply_settings():
            # Update labels
            self.axes_settings['x_label'] = x_label_var.get()
            self.axes_settings['y_label'] = y_label_var.get()

            # Parse X range (NMR: min is right, max is left)
            x_left_str = x_min_var.get().strip()  # MAX (left)
            x_right_str = x_max_var.get().strip()  # MIN (right)

            if x_left_str and x_right_str:
                try:
                    x_left = float(x_left_str)  # Max (left)
                    x_right = float(x_right_str)  # Min (right)

                    if x_left <= x_right:
                        messagebox.showerror("Error",
                                             "For NMR spectra, the left value (max ppm) must be greater than the right value (min ppm).")
                        return

                    # Store as (min, max) internally
                    self.axes_settings['x_lim'] = (x_right, x_left)  # (min, max)

                except ValueError:
                    messagebox.showerror("Error", "Invalid number format for X range.")
                    return
            else:
                self.axes_settings['x_lim'] = None

            # Parse Y range (normal: min < max)
            y_min_str = y_min_var.get().strip()
            y_max_str = y_max_var.get().strip()
            if y_min_str and y_max_str:
                try:
                    y_min = float(y_min_str)
                    y_max = float(y_max_str)
                    if y_min >= y_max:
                        messagebox.showerror("Error", "Y min must be less than Y max.")
                        return
                    self.axes_settings['y_lim'] = (y_min, y_max)
                except ValueError:
                    messagebox.showerror("Error", "Invalid number format for Y range.")
                    return
            else:
                self.axes_settings['y_lim'] = None

            self.apply_axes_settings()
            dialog.destroy()

        def reset_to_data():
            if self.ppm is not None and self.all_intensities is not None:
                x_min_var.set(f"{np.max(self.ppm):.4f}")  # Max ppm goes to left field
                x_max_var.set(f"{np.min(self.ppm):.4f}")  # Min ppm goes to right field
                y_min_var.set(f"{np.min(self.all_intensities):.4f}")
                y_max_var.set(f"{np.max(self.all_intensities):.4f}")

        ttk.Button(btn_frame, text="OK", command=apply_settings).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="Cancel", command=dialog.destroy).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="Reset to Data Range", command=reset_to_data).pack(side=tk.LEFT, padx=5)

    def apply_axes_settings(self):
        if hasattr(self, 'ax'):
            self.ax.set_xlabel(self.axes_settings['x_label'], fontsize=self.plot_settings['font_size'])
            self.ax.set_ylabel(self.axes_settings['y_label'], fontsize=self.plot_settings['font_size'])

            if self.axes_settings['x_lim'] is not None:
                x_min, x_max = self.axes_settings['x_lim']
                self.ax.set_xlim(x_min, x_max)

            if self.axes_settings['y_lim'] is not None:
                self.ax.set_ylim(self.axes_settings['y_lim'])

            self.canvas.draw_idle()

    # ---------- Plot settings methods ----------
    def toggle_legend(self):
        if hasattr(self, 'ax'):
            legend = self.ax.get_legend()
            if legend:
                legend.set_visible(self.show_legend.get())
                self.canvas.draw_idle()

    def set_background_color(self):
        color = colorchooser.askcolor(color=self.plot_settings['background'], title="Choose Background Color")
        if color[1]:
            self.plot_settings['background'] = color[1]
            self.ax.set_facecolor(color[1])
            self.figure.patch.set_facecolor(color[1])
            self.canvas.draw_idle()

    def set_grid_style(self, style):
        self.plot_settings['grid_style'] = style
        if hasattr(self, 'ax'):
            if style == 'none':
                self.ax.grid(False)
            else:
                self.ax.grid(True, linestyle=style, alpha=0.7, linewidth=0.5)
            self.canvas.draw_idle()

    def set_line_width(self, width):
        self.plot_settings['line_width'] = width
        self.update_plot()

    def set_transparency(self, alpha):
        self.plot_settings['transparency'] = alpha
        self.update_plot()

    def set_font_size(self, size):
        self.plot_settings['font_size'] = size
        if hasattr(self, 'ax'):
            self.ax.xaxis.label.set_size(size)
            self.ax.yaxis.label.set_size(size)
            self.ax.title.set_size(size + 1)
            self.ax.tick_params(labelsize=size - 1)
            self.canvas.draw_idle()

    def reset_plot_settings(self):
        self.plot_settings = {
            'background': '#FFFFFF',
            'grid_style': '--',
            'line_width': 0.5,
            'transparency': 0.8,
            'font_size': 10
        }
        if hasattr(self, 'ax'):
            self.ax.set_facecolor(self.plot_settings['background'])
            self.figure.patch.set_facecolor(self.plot_settings['background'])
            self.ax.grid(True, linestyle=self.plot_settings['grid_style'], alpha=0.7, linewidth=0.5)
            self.ax.xaxis.label.set_size(self.plot_settings['font_size'])
            self.ax.yaxis.label.set_size(self.plot_settings['font_size'])
            self.ax.tick_params(labelsize=self.plot_settings['font_size'] - 1)
            self.update_plot()

    # ---------- Group editor methods ----------
    # ── Project management ───────────────────────────────────────────────────

    def _init_project_manager(self):
        from gui.project_manager import ProjectManager
        self._project_mgr = ProjectManager(self)
        self.root.bind('<Control-s>', lambda e: self._save())
        self.root.bind('<Control-S>', lambda e: self._save())
        self.root.bind('<Control-o>', lambda e: self._open_project())
        self.root.bind('<Control-O>', lambda e: self._open_project())

    def _save_project_as(self):
        if self._project_mgr:
            self._project_mgr.save_project()

    def _open_project(self):
        if self._project_mgr:
            self._project_mgr.open_project()

    def _save(self):
        if self._project_mgr:
            self._project_mgr.save_or_saveas()

    def open_group_editor(self):
        if not self.samples_info:
            messagebox.showinfo("Info", "Please load data first to see available groups.")
            return

        groups = sorted(set([s['label'] for s in self.samples_info]))
        dialog = tk.Toplevel(self.root)
        dialog.title("Edit Groups and Colors")
        dialog.geometry("640x400")
        dialog.transient(self.root)
        dialog.grab_set()
        dialog.focus_set()

        ttk.Label(dialog, text="Edit group names and colors:", font=("Arial", 10, "bold")).pack(pady=10)

        frame = ttk.Frame(dialog)
        frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=10)

        canvas = tk.Canvas(frame, borderwidth=0, highlightthickness=0)
        scrollbar = ttk.Scrollbar(frame, orient=tk.VERTICAL, command=canvas.yview)
        scrollable_frame = ttk.Frame(canvas)

        scrollable_frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        self.group_entries = {}
        self.group_color_vars = {}
        self.group_dil_vars = {}
        self._color_buttons  = {}   # group → Button widget (for preview update)

        # Single grid frame inside scrollable_frame for perfect column alignment
        grid = ttk.Frame(scrollable_frame)
        grid.pack(fill=tk.X, padx=4, pady=4)

        COL_W = [14, 14, 8, 6, 10]   # column character widths
        for col, (hdr, anchor) in enumerate([
            ('Original Group', tk.W), ('New Name', tk.W),
            ('Color', tk.CENTER), ('Preview', tk.CENTER), ('Dil. Factor', tk.CENTER)
        ]):
            ttk.Label(grid, text=hdr, font=('Arial', 9, 'bold'),
                      width=COL_W[col], anchor=anchor).grid(
                row=0, column=col, padx=6, pady=(0, 4), sticky=tk.W)

        for i, group in enumerate(groups, start=1):
            color = self.group_colors.get(group, '#000000')
            color_var = tk.StringVar(value=color)
            self.group_color_vars[group] = color_var

            ttk.Label(grid, text=group, width=COL_W[0], anchor=tk.W).grid(
                row=i, column=0, padx=6, pady=2, sticky=tk.W)

            name_var = tk.StringVar(value=group)
            ttk.Entry(grid, textvariable=name_var, width=COL_W[1]).grid(
                row=i, column=1, padx=6, pady=2, sticky=tk.W)
            self.group_entries[group] = name_var

            btn = tk.Button(grid, bg=color, width=COL_W[2], height=1,
                            relief=tk.RAISED, bd=2)
            btn.config(command=lambda g=group, v=color_var, b=btn:
                       self.choose_color(g, v, b))
            btn.grid(row=i, column=2, padx=6, pady=2)
            self._color_buttons[group] = btn

            preview = tk.Label(grid, bg=color, width=COL_W[3],
                               relief=tk.SUNKEN, bd=1)
            preview.grid(row=i, column=3, padx=6, pady=2, ipady=8, sticky=tk.EW)
            # Store preview label reference on the color_var for update
            color_var._preview = preview

            dil_var = tk.StringVar(value=str(self.group_dilution_factors.get(group, 1.0)))
            ttk.Entry(grid, textvariable=dil_var, width=COL_W[4]).grid(
                row=i, column=4, padx=6, pady=2, sticky=tk.W)
            self.group_dil_vars[group] = dil_var

        btn_frame = ttk.Frame(dialog)
        btn_frame.pack(fill=tk.X, padx=20, pady=10)

        ttk.Button(btn_frame, text="Save", command=lambda: self.save_group_changes(dialog)).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="Cancel", command=dialog.destroy).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="Reset to Default", command=self.reset_group_colors).pack(side=tk.RIGHT, padx=5)

    def choose_color(self, group, color_var, btn=None):
        current = color_var.get()
        color = colorchooser.askcolor(color=current, title=f"Choose color for {group}")
        if color[1]:
            color_var.set(color[1])
            if btn:
                btn.config(bg=color[1])
            preview = getattr(color_var, '_preview', None)
            if preview:
                preview.config(bg=color[1])

    def save_group_changes(self, dialog):
        group_mapping = {}
        for old, name_var in self.group_entries.items():
            new = name_var.get().strip()
            if new and new != old:
                group_mapping[old] = new

        for old, color_var in self.group_color_vars.items():
            new_color = color_var.get()
            self.group_colors[old] = new_color
            if old in group_mapping:
                self.group_colors[group_mapping[old]] = new_color

        for old, dil_var in getattr(self, 'group_dil_vars', {}).items():
            try:
                factor = float(dil_var.get())
            except ValueError:
                factor = 1.0
            new_name = group_mapping.get(old, old)
            self.group_dilution_factors[new_name] = factor

        if group_mapping:
            for sample in self.samples_info:
                old_label = sample['label']
                if old_label in group_mapping:
                    sample['label'] = group_mapping[old_label]
                    sample['display'] = f"{sample['name']} ({sample['label']})"

        # Refresh visualization stage if active
        if 'visualization' in self.stages:
            self.stages['visualization'].refresh_sample_list()

        self.update_plot()
        dialog.destroy()
        messagebox.showinfo("Success", "Group names and colors updated successfully!")

    def _assign_group_colors(self):
        """Atribui cores a todos os grupos presentes em samples_info.
        Grupos já definidos mantêm a sua cor. Grupos novos recebem cores
        geradas automaticamente a partir de uma paleta variada."""
        import colorsys
        # Paleta base com cores distintas e saturadas
        _PALETTE = [
            '#2E86AB', '#A23B72', '#F18F01', '#17BEBB', '#C73E1D', '#593C8F',
            '#E84855', '#3BB273', '#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4',
            '#FFEAA7', '#DDA0DD', '#98D8C8', '#F7DC6F', '#BB8FCE', '#85C1E9',
            '#F0B27A', '#82E0AA', '#F1948A', '#85929E', '#73C6B6', '#F8C471',
        ]
        groups = sorted(set(s['label'] for s in self.samples_info))
        palette_idx = len([g for g in self.group_colors
                           if g not in ('CTRL', 'G1', 'G2', 'G3', 'BLK', 'Unknown')])
        for group in groups:
            if group not in self.group_colors:
                # Usar paleta circular
                color = _PALETTE[palette_idx % len(_PALETTE)]
                # Verificar se não está em uso
                used = set(self.group_colors.values())
                offset = 0
                while color in used and offset < len(_PALETTE):
                    offset += 1
                    color = _PALETTE[(palette_idx + offset) % len(_PALETTE)]
                self.group_colors[group] = color
                palette_idx += 1

    def reset_group_colors(self):
        self.group_colors = {
            'CTRL': '#2E86AB',
            'G1': '#A23B72',
            'G2': '#F18F01',
            'G3': '#17BEBB',
            'BLK': '#C73E1D',
            'Unknown': '#593C8F'
        }
        if 'visualization' in self.stages:
            self.stages['visualization'].refresh_sample_list()
        if self.samples_info:
            self.update_plot()

    # ---------- Data Import ----------
    def import_data(self):
        """Import NMR spectrum data from CSV file."""
        filepath = filedialog.askopenfilename(
            title="Select spectrum file",
            filetypes=[("CSV files", "*.csv"), ("Text files", "*.txt"), ("All files", "*.*")]
        )

        if not filepath:
            return

        try:
            # Update status
            self.status_label.config(text="Loading file...", foreground="blue")
            self.root.update()

            # Load all samples using the robust loader
            self.ppm, self.all_intensities, sample_names, sample_labels = load_all_samples(filepath)

            # CRITICAL: Create samples_info for BLK identification
            self.samples_info = []
            for i, (name, label) in enumerate(zip(sample_names, sample_labels)):
                _type = 'BLK' if str(label).upper() == 'BLK' else 'Sample'
                self.samples_info.append({
                    'index': i,
                    'name': name,
                    'label': label,
                    'type': _type,
                    'display': f"{name} ({label})"
                })

            print(f"\n📊 Loaded {len(self.samples_info)} samples:")
            for s in self.samples_info:
                print(f"   Sample {s['index']}: {s['name']} - label: '{s['label']}'")

            # Gerar cores automáticas para grupos que não estão em group_colors
            self._assign_group_colors()

            # Clear existing checkboxes in visualization stage
            if 'visualization' in self.stages:
                self.stages['visualization'].refresh_sample_list()
                # Enable buttons in visualization stage
                if hasattr(self.stages['visualization'], 'sample_vars'):
                    self.btn_select_all.config(state="normal")
                    self.btn_clear_all.config(state="normal")
                    self.btn_update.config(state="normal")

            self.current_file = filepath
            if self.file_label:
                self.file_label.config(text=os.path.basename(filepath))

            # Update the plot
            self.update_plot()

            # Update status
            self.status_label.config(text="File loaded successfully", foreground="green")
            self.samples_count_label.config(text=f"{len(self.samples_info)} samples")

            messagebox.showinfo("Success", f"Loaded {len(self.samples_info)} samples successfully!")

        except Exception as e:
            self.status_label.config(text="Error loading file", foreground="red")
            messagebox.showerror("Error", f"Could not load file:\n{str(e)}")
            import traceback
            traceback.print_exc()

    # ---------- Plot Update ----------
    def update_plot(self):
        """Update plot based on current stage and settings."""
        if self.ppm is None or self.all_intensities is None:
            return

        # If in visualization stage, use sample selection
        if self.active_stage == 'visualization':
            stage = self.stages['visualization']
            if hasattr(stage, 'sample_vars') and stage.sample_vars:
                selected = [i for i, var in enumerate(stage.sample_vars) if var.get()]

                if not selected:
                    self.ax.clear()
                    self.ax.set_xlabel(self.axes_settings['x_label'], fontsize=self.plot_settings['font_size'])
                    self.ax.set_ylabel(self.axes_settings['y_label'], fontsize=self.plot_settings['font_size'])
                    if self.plot_settings['grid_style'] != 'none':
                        self.ax.grid(True, linestyle=self.plot_settings['grid_style'], alpha=0.7, linewidth=0.5)
                    self.ax.set_facecolor(self.plot_settings['background'])
                    self.ax.text(0.5, 0.5, 'No samples selected', transform=self.ax.transAxes,
                                 ha='center', va='center', fontsize=14, color='gray')
                    self.canvas.draw()
                    return

                if len(selected) == 1:
                    idx = selected[0]
                    sample = self.samples_info[idx]
                    plot_spectrum(self.ax, self.ppm, self.all_intensities[:, idx],
                                  title=f"Sample: {sample['name']} - Group: {sample['label']}",
                                  color='black', label=sample['display'],
                                  show_legend=self.show_legend.get(),
                                  settings=self.plot_settings)
                else:
                    samples = [self.samples_info[i] for i in selected]
                    names = [s['name'] for s in samples]
                    labels = [s['label'] for s in samples]
                    intensities = self.all_intensities[:, selected]
                    plot_multiple_spectra(self.ax, self.ppm, intensities, names, labels,
                                          self.group_colors, show_legend=self.show_legend.get(),
                                          settings=self.plot_settings)
            else:
                # Fallback: plot all samples
                plot_multiple_spectra(self.ax, self.ppm, self.all_intensities,
                                      [s['name'] for s in self.samples_info],
                                      [s['label'] for s in self.samples_info],
                                      self.group_colors, show_legend=self.show_legend.get(),
                                      settings=self.plot_settings)
        else:
            # In peak_detection / annotation stages, plot all samples
            plot_multiple_spectra(self.ax, self.ppm, self.all_intensities,
                                  [s['name'] for s in self.samples_info],
                                  [s['label'] for s in self.samples_info],
                                  self.group_colors, show_legend=self.show_legend.get(),
                                  settings=self.plot_settings)

        self.apply_axes_settings()
        self.status_label.config(text=f"Showing data")
        self.canvas.draw()

    def _open_resolving_method(self):
        """Open the Overlap Resolving Method window."""
        ann = self.stages.get('annotation')
        metabolites = getattr(ann, '_metabolites', None)
        if not metabolites:
            messagebox.showinfo(
                'Resolving Method',
                'Run annotation search and review results first.\n'
                'Mark peaks as Good (Ctrl+1) in the Annotation Results window.',
                parent=self.root)
            return
        from gui.widgets.resolving_method_window import ResolvingMethodWindow
        ResolvingMethodWindow(
            self.root,
            metabolites=metabolites,
            peaks=ann.peaks,
            ppm=self.ppm,
            all_intensities=self.all_intensities,
            samples_info=getattr(self, 'samples_info', []),
            app=self)

    def open_peak_debugger(self):
        """Open the peak flow debugger for the current stage."""
        if hasattr(self, 'stages') and 'peak_detection' in self.stages:
            notation_stage = self.stages['peak_detection']
            try:
                from ParseHMDBNames import open_debugger
                open_debugger(notation_stage)
            except ImportError:
                messagebox.showerror("Error",
                                     "Debug module not found.\n"
                                     "Please ensure debug_peak_flow.py exists in the project root.")
            except Exception as e:
                messagebox.showerror("Error", f"Could not open debugger:\n{str(e)}")
        else:
            messagebox.showinfo("Info", "Please switch to Metabolites Notation stage first.")

    def toggle_peak_areas(self):
        """Show or hide peak highlight areas from the Edit menu."""
        # Delegate to PeakDetectionStage which owns the peak list
        stage = self.stages.get('peak_detection')
        if stage is None or not stage.peaks:
            return
        stage.toggle_peaks()

    def open_peak_list(self):
        """Open the Peak List window — singleton: reutiliza se já estiver aberta."""
        stage = self.stages.get('peak_detection')
        if stage is None:
            return
        # Also accept peaks injected by MCR Analysis (K=1 regions)
        if not stage.peaks:
            return
        # Reutilizar janela existente se estiver aberta
        if self._peak_list_win is not None:
            try:
                w = self._peak_list_win.win
                if w.winfo_exists():
                    w.deiconify()
                    w.lift()
                    w.focus_force()
                    return
            except Exception:
                pass
        from gui.widgets.peak_list_window import PeakListWindow
        self._peak_list_win = PeakListWindow(
            self.root, stage.peaks,
            self.ppm, self.all_intensities, app=self)
        # Limpar referência quando a janela fechar
        self._peak_list_win.win.protocol(
            'WM_DELETE_WINDOW',
            lambda: (self._peak_list_win.win.destroy(),
                     setattr(self, '_peak_list_win', None)))

    def open_deconv_shortcut(self):
        """Open Deconvolution window.

        After annotation: opens MCRDeconvWindow (MCR results).
        Before annotation: opens legacy DeconvWindow (peak fitting).
        """
        ann_stage  = self.stages.get('annotation')
        pk_stage   = self.stages.get('peak_detection')
        fs_stage   = self.stages.get('fullspectrum_mcr')

        # Priority 1: Full-spectrum MCR results
        _fs_regions = getattr(fs_stage, '_mcr_regions', [])
        # Priority 2: annotation-stage MCR peaks
        _peaks   = pk_stage.peaks if pk_stage else []
        _ann_mcr = [p for p in _peaks
                    if p.get('mcr_annotation', {}).get('K', 1) >= 2]

        if _fs_regions:
            _source_peaks = _fs_regions
            _source_stage = fs_stage
        elif _ann_mcr:
            _source_peaks = _peaks
            _source_stage = ann_stage
        else:
            _source_peaks = None
            _source_stage = None

        if _source_peaks:
            # Singleton MCR window
            if self._deconv_win is not None:
                try:
                    w = self._deconv_win.win
                    if w.winfo_exists():
                        w.deiconify(); w.lift(); w.focus_force()
                        return
                except Exception:
                    pass
            from gui.widgets.mcr_deconv_window import MCRDeconvWindow
            self._deconv_win = MCRDeconvWindow(
                self.root, _source_peaks, self, ann_stage=_source_stage)
        else:
            # Legacy peak-detection deconvolution tool
            if self._deconv_win is not None:
                try:
                    w = self._deconv_win.window
                    if w.winfo_exists():
                        w.deiconify(); w.lift(); w.focus_force()
                        return
                except Exception:
                    pass
            if pk_stage:
                pk_stage.open_deconv_tool()

    def open_annot_shortcut(self):
        """Open Annotation Results — singleton."""
        # Reutilizar janela existente
        if self._annot_win is not None:
            try:
                w = self._annot_win.win
                if w.winfo_exists():
                    w.deiconify()
                    w.lift()
                    w.focus_force()
                    return
            except Exception:
                pass
        stage = self.stages.get('annotation')
        if stage and hasattr(stage, '_last_results_args'):
            args = stage._last_results_args
            if not args:
                return
            pk_stage = self.stages.get('peak_detection')
            from gui.widgets.annotation_results_window import AnnotationResultsWindow
            self._annot_win = AnnotationResultsWindow(
                self.root,
                args['results'],
                pk_stage.peaks if pk_stage else [],
                self.ppm,
                self.all_intensities,
                db_path=args.get('db_path'),
                elapsed=args.get('elapsed', 0),
                app=self,
                saved_quality=dict(getattr(stage, '_quality_marks', {})))
            # Keep the live reference updated so Resolving Method sees
            # the same metabolite dicts that the user is annotating.
            stage._metabolites = self._annot_win.metabolites
            self._annot_win.win.protocol(
                'WM_DELETE_WINDOW',
                lambda: (self._annot_win.win.destroy(),
                         setattr(self, '_annot_win', None)))

    def run(self):
        self._init_project_manager()
        self.root.mainloop()