# gui/widgets/resolving_method_window.py
"""
Overlap Resolving Method.

Algorithm
─────────
Phase 1  – Anchor estimation
    For every metabolite that has at least one "Good" peak with no overlap,
    estimate a relative concentration proxy:
        conc_est = mean( area_anchor_i / protons_i )

Phase 2  – Contribution subtraction
    For every overlapping peak:
        contrib_M = conc_est_M × protons_M_at_this_peak
        residual  = observed_area − Σ contrib_M  (for all M with known conc_est)
        %_M       = contrib_M / observed_area × 100
        %_resid   = residual  / observed_area × 100

Phase 3  (optional, checkbox)  – Iterative refinement
    After Phase 2, any overlapping peak whose ALL known contributions have
    been subtracted now reduces to a single-metabolite residual → new anchor.
    Repeat Phase 1+2 until no new anchors emerge.

Phase 4  – Mark unresolvable
    Metabolites that still have no conc_est after all phases are flagged
    as "✗ Unresolvable".

Status per metabolite
─────────────────────
  ✓ Quantifiable   – has at least 1 unambiguous anchor (Good peak, no overlap)
  ⚠ Resolved       – no direct anchor, but resolved via Phase 3 residual
  ✗ Unresolvable   – no concentration estimate possible
"""
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import numpy as np
import matplotlib
matplotlib.use('TkAgg')
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg


# ── Colour constants ──────────────────────────────────────────────────────────
_COL_ANCHOR    = '#2196F3'   # blue – anchor peak cell
_COL_RESOLVED  = '#4CAF50'   # green – known contribution
_COL_RESIDUAL  = '#FF9800'   # orange – unresolved residual
_COL_UNKNOWN   = '#BDBDBD'   # grey – unresolvable


class ResolvingMethodWindow:

    def __init__(self, parent, metabolites, peaks, ppm,
                 all_intensities, samples_info, app=None):
        self._metabolites   = metabolites
        self._peaks         = peaks
        self._ppm           = ppm
        self._all_int       = all_intensities  # (n_pts, n_samples)
        self._samples_info  = samples_info or []
        self.app            = app

        # Mean spectrum (BLK excluded)
        self._mean_int = self._build_mean()

        # Results – populated by _run()
        self._peak_overlap  = {}   # rank → [met_name, …]
        self._conc_est      = {}   # met_id → float (area/proton proxy)
        self._contributions = {}   # rank → {met_id: pct, '_residual_pct': pct,
                                   #          '_observed': float}
        self._status        = {}   # met_id → 'quantifiable'|'resolved'|'unresolvable'
        self._anchor_peaks  = {}   # met_id → [peak_rank, …]

        self.win = tk.Toplevel(parent)
        self.win.title('Resolving Method — Overlap Decomposition')
        self.win.geometry('1200x620')
        self.win.minsize(900, 460)

        self._iterate_var = tk.BooleanVar(value=True)   # Phase 3 on by default
        self._build_ui()
        self._run()
        self._center()

    # ── Mean spectrum ─────────────────────────────────────────────────────────

    def _build_mean(self):
        if self._all_int is None:
            return None
        si  = self._samples_info
        blk = {i for i, s in enumerate(si)
               if str(s.get('type', '')).upper() == 'BLK'}
        idxs = [i for i in range(self._all_int.shape[1]) if i not in blk]
        if not idxs:
            idxs = list(range(self._all_int.shape[1]))
        return np.mean(self._all_int[:, idxs], axis=1)

    # ── Overlap map ───────────────────────────────────────────────────────────

    def _build_overlap(self):
        om = {}
        for met in self._metabolites:
            for mp in met['matched_peaks']:
                rank = mp.get('peak_rank')
                if rank is not None:
                    om.setdefault(rank, []).append(met['name'])
        self._peak_overlap = om

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _met_by_id(self, mid):
        return next((m for m in self._metabolites if m['id'] == mid), None)

    def _met_by_name(self, name):
        return next((m for m in self._metabolites if m['name'] == name), None)

    def _peak_by_rank(self, rank):
        return next((p for p in self._peaks if p.get('rank') == rank), None)

    def _get_area(self, peak):
        """Trapezoidal area on mean spectrum.
        Uses min/max to handle NMR convention where start_ppm > end_ppm.
        """
        if self._mean_int is None or self._ppm is None:
            return 0.0
        sp = peak.get('start_ppm', peak['ppm'])
        ep = peak.get('end_ppm',   peak['ppm'])
        lo = min(sp, ep)
        hi = max(sp, ep)
        if lo == hi:
            lo -= 0.01; hi += 0.01
        mask = (self._ppm >= lo) & (self._ppm <= hi)
        if mask.sum() < 2:
            return 0.0
        return float(abs(np.trapezoid(self._mean_int[mask], self._ppm[mask])))

    def _get_area_per_sample(self, peak):
        """Trapezoidal area per sample.
        Uses min/max to handle NMR convention where start_ppm > end_ppm.
        """
        if self._all_int is None or self._ppm is None:
            return np.array([])
        sp = peak.get('start_ppm', peak['ppm'])
        ep = peak.get('end_ppm',   peak['ppm'])
        lo = min(sp, ep)
        hi = max(sp, ep)
        if lo == hi:
            lo -= 0.01; hi += 0.01
        mask = (self._ppm >= lo) & (self._ppm <= hi)
        if mask.sum() < 2:
            return np.zeros(self._all_int.shape[1])
        x = self._ppm[mask]
        return np.array([
            float(abs(np.trapezoid(self._all_int[mask, s], x)))
            for s in range(self._all_int.shape[1])
        ])

    def _get_protons(self, met, mp):
        try:
            n = int(mp.get('protons') or 0)
            if n > 0:
                return n
        except (TypeError, ValueError):
            pass
        db_ppm = float(mp.get('db_ppm', 0))
        entry  = next(
            (p for p in met.get('db_peaks', [])
             if abs(p.get('ppm_center', p.get('ppm', 0)) - db_ppm) < 0.02),
            None)
        if entry:
            try:
                n = int(entry.get('protons') or 0)
                if n > 0:
                    return n
            except (TypeError, ValueError):
                pass
        return 1

    # ── Algorithm ─────────────────────────────────────────────────────────────

    def _run(self):
        self._build_overlap()
        self._conc_est.clear()
        self._contributions.clear()
        self._status.clear()
        self._anchor_peaks.clear()

        self._phase1()
        self._phase2()

        if self._iterate_var.get():
            self._phase3()

        self._phase4()
        self._refresh_ui()

    def _phase1(self):
        """Good peaks → concentration estimate.

        Trusts the user's annotation_quality == 'good' marking completely.
        Peaks without overlap are the strongest anchors; overlapping peaks
        that were explicitly assigned to this metabolite (via Resolve window
        or Ctrl+1) are also accepted — their area is the best available
        estimate for this metabolite's contribution.
        """
        for met in self._metabolites:
            mid     = met['id']
            probes  = []
            anchors = []
            for mp in met['matched_peaks']:
                if mp.get('annotation_quality') != 'good':
                    continue
                rank = mp.get('peak_rank')
                peak = self._peak_by_rank(rank)
                if peak is None:
                    continue
                area = self._get_area(peak)
                if area <= 0:
                    continue
                n_h = self._get_protons(met, mp)
                probes.append(area / n_h)
                anchors.append(rank)

            if probes:
                self._conc_est[mid]     = float(np.median(probes))
                self._anchor_peaks[mid] = anchors

    def _phase2(self):
        """Subtract known contributions from overlapping peaks."""
        for rank, met_names in self._peak_overlap.items():
            if len(met_names) <= 1:
                continue
            peak = self._peak_by_rank(rank)
            if peak is None:
                continue
            obs_area = self._get_area(peak)
            if obs_area <= 0:
                continue

            contribs  = {}   # met_id → absolute contribution
            for name in met_names:
                met = self._met_by_name(name)
                if met is None:
                    continue
                mid = met['id']
                if mid not in self._conc_est:
                    continue
                mp = next(
                    (m for m in met['matched_peaks']
                     if m.get('peak_rank') == rank), None)
                if mp is None:
                    continue
                n_h         = self._get_protons(met, mp)
                contribs[mid] = self._conc_est[mid] * n_h

            total_known = sum(contribs.values())
            residual    = max(0.0, obs_area - total_known)

            result = {mid: v / obs_area * 100 for mid, v in contribs.items()}
            result['_residual_pct'] = residual / obs_area * 100
            result['_observed']     = obs_area
            self._contributions[rank] = result

    def _phase3(self):
        """Iterative: residual → new anchor if only 1 unknown metabolite left."""
        changed = True
        while changed:
            changed = False
            for rank, info in list(self._contributions.items()):
                if info.get('_residual_pct', 100) < 5:
                    continue   # already well-resolved
                met_names = self._peak_overlap.get(rank, [])
                unknowns  = [
                    self._met_by_name(n) for n in met_names
                    if self._met_by_name(n) is not None
                    and self._met_by_name(n)['id'] not in self._conc_est
                ]
                if len(unknowns) != 1:
                    continue
                met = unknowns[0]
                mid = met['id']
                mp  = next(
                    (m for m in met['matched_peaks']
                     if m.get('peak_rank') == rank), None)
                if mp is None:
                    continue
                # Residual area for this unknown
                peak     = self._peak_by_rank(rank)
                obs_area = self._get_area(peak) if peak else 0
                known    = sum(
                    self._conc_est[self._met_by_name(n)['id']]
                    * self._get_protons(self._met_by_name(n),
                                        next((m for m in self._met_by_name(n)['matched_peaks']
                                              if m.get('peak_rank') == rank), {}))
                    for n in self._peak_overlap.get(rank, [])
                    if self._met_by_name(n) is not None
                    and self._met_by_name(n)['id'] in self._conc_est
                )
                residual_area = max(0.0, obs_area - known)
                n_h = self._get_protons(met, mp)
                if n_h > 0 and residual_area > 0:
                    new_probe = residual_area / n_h
                    # Merge with existing estimate if any
                    prev = self._conc_est.get(mid)
                    self._conc_est[mid] = (
                        float(np.mean([prev, new_probe])) if prev else new_probe)
                    self._anchor_peaks.setdefault(mid, []).append(rank)
                    changed = True

            if changed:
                self._phase2()  # recompute contributions with new conc_ests

    def _phase4(self):
        """Assign status to every metabolite."""
        for met in self._metabolites:
            mid = met['id']
            if mid in self._conc_est:
                # Anchor with no overlap = strongest (auto or manual)
                unambiguous = [
                    r for r in self._anchor_peaks.get(mid, [])
                    if len([n for n in self._peak_overlap.get(r, [])
                            if n != met['name']]) == 0
                ]
                self._status[mid] = (
                    'quantifiable' if unambiguous else 'resolved')
            else:
                self._status[mid] = 'unresolvable'

    # ── UI ───────────────────────────────────────────────────────────────────

    def _build_ui(self):
        # ── Top control bar ────────────────────────────────────────────────
        ctrl = ttk.Frame(self.win, padding=(6, 4))
        ctrl.pack(side=tk.TOP, fill=tk.X)
        ttk.Label(ctrl, text='Overlap Resolving Method',
                  font=('Arial', 10, 'bold')).pack(side=tk.LEFT)
        ttk.Checkbutton(ctrl, text='Phase 3 (iterative)',
                        variable=self._iterate_var).pack(side=tk.LEFT, padx=12)
        ttk.Button(ctrl, text='▶ Run', command=self._run).pack(
            side=tk.LEFT, padx=4)
        self._summary_lbl = ttk.Label(ctrl, text='', foreground='#555',
                                      font=('Arial', 8))
        self._summary_lbl.pack(side=tk.LEFT, padx=10)
        ttk.Button(ctrl, text='Export CSV',
                   command=self._export).pack(side=tk.RIGHT, padx=4)

        ttk.Separator(self.win, orient='horizontal').pack(fill=tk.X, padx=4)

        # ── Main split ────────────────────────────────────────────────────
        split = tk.PanedWindow(self.win, orient=tk.HORIZONTAL,
                               sashwidth=5, sashrelief=tk.RAISED)
        split.pack(fill=tk.BOTH, expand=True, padx=4, pady=4)

        # Left: metabolite result table
        left = ttk.Frame(split)
        split.add(left, minsize=340, stretch='always')
        self._build_table(left)

        # Right: heatmap
        right = ttk.LabelFrame(split, text='Contribution heatmap', padding=2)
        split.add(right, minsize=520, stretch='always')
        self._build_heatmap_panel(right)

    def _build_table(self, parent):
        ttk.Label(parent,
                  text='Metabolites with overlapping peaks',
                  font=('Arial', 9, 'bold')).pack(anchor=tk.W, padx=4, pady=(2, 0))
        ttk.Label(parent,
                  text='✓ Quantifiable: unique anchor  '
                       '⚠ Resolved: via residual  '
                       '✗ Unresolvable',
                  font=('Arial', 7), foreground='#888').pack(
            anchor=tk.W, padx=4, pady=(0, 0))

        # Anchor summary line (updated in _refresh_ui)
        self._anchor_lbl = ttk.Label(
            parent, text='', font=('Arial', 7), foreground='#1a6e1a')
        self._anchor_lbl.pack(anchor=tk.W, padx=4, pady=(0, 2))

        COLS = [
            ('status',   'Status',        80, tk.CENTER),
            ('name',     'Metabolite',   160, tk.W),
            ('anchors',  'Anchors',       58, tk.CENTER),
            ('n_good',   'Good peaks',    68, tk.CENTER),
            ('rel_conc', 'Rel. conc',     72, tk.CENTER),
        ]
        vsb = ttk.Scrollbar(parent, orient=tk.VERTICAL)
        self._tree = ttk.Treeview(
            parent,
            columns=[c[0] for c in COLS],
            show='headings',
            selectmode='browse',
            yscrollcommand=vsb.set)
        vsb.config(command=self._tree.yview)
        self._tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(4, 0))
        vsb.pack(side=tk.LEFT, fill=tk.Y)

        for cid, heading, width, anchor in COLS:
            self._tree.heading(cid, text=heading)
            self._tree.column(cid, width=width, anchor=anchor,
                              minwidth=30, stretch=(cid == 'name'))

        self._tree.tag_configure('quant', background='#e8ffe8',
                                 font=('Arial', 9, 'bold'))
        self._tree.tag_configure('resolved', background='#fff8e0')
        self._tree.tag_configure('unresolv', background='#ffe8e8',
                                 foreground='#880000')

    def _build_heatmap_panel(self, parent):
        self._hm_fig = plt.Figure(figsize=(7, 4), dpi=100)
        self._hm_fig.patch.set_facecolor('#fafafa')
        self._hm_ax  = self._hm_fig.add_subplot(111)
        self._hm_canvas = FigureCanvasTkAgg(self._hm_fig, master=parent)
        self._hm_canvas.draw()
        self._hm_canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)

        leg = ttk.Frame(parent)
        leg.pack(fill=tk.X)
        for col, label in [(_COL_ANCHOR,   '■ Anchor (est. conc)'),
                           (_COL_RESOLVED, '■ Known contribution'),
                           (_COL_RESIDUAL, '■ Unresolved residual'),
                           (_COL_UNKNOWN,  '■ Unresolvable')]:
            tk.Label(leg, text=label, bg=col, fg='white',
                     font=('Arial', 7), padx=3).pack(side=tk.LEFT, padx=2, pady=2)

    # ── Refresh UI after run ──────────────────────────────────────────────────

    def _refresh_ui(self):
        self._update_anchor_label()
        self._populate_table()
        self._draw_heatmap()
        self._update_summary()

    def _update_summary(self):
        # Count only metabolites involved in overlapping peaks
        ovlp_ids = self._overlapping_met_ids()
        n_q = sum(1 for mid, v in self._status.items()
                  if v == 'quantifiable' and mid in ovlp_ids)
        n_r = sum(1 for mid, v in self._status.items()
                  if v == 'resolved' and mid in ovlp_ids)
        n_u = sum(1 for mid, v in self._status.items()
                  if v == 'unresolvable' and mid in ovlp_ids)
        self._summary_lbl.config(
            text=f"✓ {n_q} quantifiable  ⚠ {n_r} resolved  ✗ {n_u} unresolvable")

    def _overlapping_met_ids(self):
        """IDs of metabolites involved in at least one overlapping peak."""
        ids = set()
        for rank, names in self._peak_overlap.items():
            if len(names) > 1:
                for name in names:
                    met = self._met_by_name(name)
                    if met:
                        ids.add(met['id'])
        return ids

    def _update_anchor_label(self):
        """Show which metabolites are used as pure anchors (only unique Good peaks)."""
        lbl = getattr(self, '_anchor_lbl', None)
        if lbl is None:
            return
        ovlp_ids = self._overlapping_met_ids()
        anchors = []
        for met in self._metabolites:
            mid = met['id']
            if mid in self._conc_est and mid not in ovlp_ids:
                anchors.append(met['name'])
        if anchors:
            txt = 'Anchors (unique peaks): ' + ', '.join(anchors)
        else:
            n_good = sum(1 for m in self._metabolites
                         for mp in m['matched_peaks']
                         if mp.get('annotation_quality') == 'good')
            if n_good == 0:
                txt = '⚠ No Good peaks found — mark peaks as Good in Annotation Results first'
            else:
                txt = f'{n_good} Good peak(s) found but no unique anchors resolved'
        lbl.config(text=txt)

    def _populate_table(self):
        self._tree.delete(*self._tree.get_children(''))

        # Only show metabolites involved in overlapping peaks
        ovlp_ids = self._overlapping_met_ids()
        order = {'quantifiable': 0, 'resolved': 1, 'unresolvable': 2}
        mets  = sorted(
            [m for m in self._metabolites if m['id'] in ovlp_ids],
            key=lambda m: (order.get(self._status.get(m['id'], 'unresolvable'), 2),
                           m['name']))

        for met in mets:
            mid    = met['id']
            status = self._status.get(mid, 'unresolvable')
            ce     = self._conc_est.get(mid)
            n_anch = len(self._anchor_peaks.get(mid, []))
            n_good = sum(1 for mp in met['matched_peaks']
                         if mp.get('annotation_quality') == 'good')
            tag    = {'quantifiable': 'quant',
                      'resolved':     'resolved',
                      'unresolvable': 'unresolv'}.get(status, 'unresolv')
            sym    = {'quantifiable': '✓', 'resolved': '⚠',
                      'unresolvable': '✗'}.get(status, '✗')
            self._tree.insert('', tk.END,
                              tags=(tag,),
                              values=(
                                  sym + ' ' + status.capitalize(),
                                  met['name'],
                                  n_anch,
                                  n_good,
                                  f"{ce:.4g}" if ce else '—',
                              ))

    def _draw_heatmap(self):
        ax = self._hm_ax
        ax.clear()
        ax.set_facecolor('#f8f8f8')

        # Collect overlapping peaks (columns) sorted by descending ppm
        ovlp_ranks = sorted(
            [r for r, ns in self._peak_overlap.items() if len(ns) > 1],
            key=lambda r: (self._peak_by_rank(r) or {}).get('ppm', 0),
            reverse=True)

        if not ovlp_ranks:
            ax.text(0.5, 0.5, 'No overlapping peaks found',
                    transform=ax.transAxes, ha='center', va='center',
                    color='gray', fontsize=10)
            self._hm_canvas.draw_idle()
            return

        # Collect metabolites involved in at least one overlapping peak
        involved_ids = set()
        for rank in ovlp_ranks:
            for name in self._peak_overlap.get(rank, []):
                met = self._met_by_name(name)
                if met:
                    involved_ids.add(met['id'])

        order = {'quantifiable': 0, 'resolved': 1, 'unresolvable': 2}
        involved_mets = sorted(
            [m for m in self._metabolites if m['id'] in involved_ids],
            key=lambda m: (order.get(self._status.get(m['id'], 'unresolvable'), 2),
                           m['name']))

        if not involved_mets:
            ax.text(0.5, 0.5, 'No data', transform=ax.transAxes,
                    ha='center', va='center', color='gray')
            self._hm_canvas.draw_idle()
            return

        n_rows = len(involved_mets)
        n_cols = len(ovlp_ranks)

        # Build colour matrix (RGBA)
        img = np.ones((n_rows, n_cols, 4))  # white background

        for ci, rank in enumerate(ovlp_ranks):
            info = self._contributions.get(rank, {})
            for ri, met in enumerate(involved_mets):
                mid  = met['id']
                name = met['name']
                in_peak = name in self._peak_overlap.get(rank, [])
                if not in_peak:
                    img[ri, ci] = [0.97, 0.97, 0.97, 1]   # very light grey
                    continue
                is_anchor = rank in self._anchor_peaks.get(mid, [])
                if is_anchor:
                    img[ri, ci] = mcolors.to_rgba(_COL_ANCHOR, alpha=0.85)
                elif mid in info:
                    pct = info[mid]
                    # Green scale: 0%=white, 100%=_COL_RESOLVED
                    rc, gc, bc, _ = mcolors.to_rgba(_COL_RESOLVED)
                    t = pct / 100.0
                    img[ri, ci] = [1 - t * (1 - rc),
                                   1 - t * (1 - gc),
                                   1 - t * (1 - bc), 1]
                elif self._status.get(mid) == 'unresolvable':
                    img[ri, ci] = mcolors.to_rgba(_COL_UNKNOWN, alpha=0.70)
                else:
                    # In peak but conc not yet estimated (partially resolved)
                    img[ri, ci] = mcolors.to_rgba(_COL_RESIDUAL, alpha=0.40)

        ax.imshow(img, aspect='auto', interpolation='none',
                  extent=[-0.5, n_cols - 0.5, n_rows - 0.5, -0.5])

        # ── Cell text ─────────────────────────────────────────────────────────
        for ci, rank in enumerate(ovlp_ranks):
            info = self._contributions.get(rank, {})
            for ri, met in enumerate(involved_mets):
                mid  = met['id']
                name = met['name']
                if name not in self._peak_overlap.get(rank, []):
                    continue
                is_anchor = rank in self._anchor_peaks.get(mid, [])
                if is_anchor:
                    txt = 'anchor'
                    col = 'white'
                elif mid in info:
                    txt = f"{info[mid]:.0f}%"
                    col = 'white' if info[mid] > 40 else '#222'
                elif self._status.get(mid) == 'unresolvable':
                    txt = '?'
                    col = '#555'
                else:
                    txt = '…'
                    col = '#555'
                ax.text(ci, ri, txt, ha='center', va='center',
                        fontsize=7, color=col, fontweight='bold')

        # ── Residual row at bottom ────────────────────────────────────────────
        # Shown as a simple annotation per column
        for ci, rank in enumerate(ovlp_ranks):
            info = self._contributions.get(rank, {})
            resid = info.get('_residual_pct', 0)
            if resid > 2:
                ax.text(ci, n_rows - 0.05,
                        f"R:{resid:.0f}%",
                        ha='center', va='top', fontsize=6,
                        color='#c45000', style='italic')

        # ── Axes labels ───────────────────────────────────────────────────────
        ax.set_xticks(range(n_cols))
        col_labels = []
        for rank in ovlp_ranks:
            peak = self._peak_by_rank(rank)
            ppm  = peak['ppm'] if peak else rank
            col_labels.append(f"#{rank}\n{ppm:.3f}")
        ax.set_xticklabels(col_labels, fontsize=7)

        ax.set_yticks(range(n_rows))
        ax.set_yticklabels([m['name'][:22] for m in involved_mets], fontsize=7)

        ax.set_xlabel('Overlapping peaks  (rank / ppm)', fontsize=8)
        ax.set_title('Metabolite contribution per peak  '
                     '(% of observed area)', fontsize=9)
        ax.tick_params(length=0)
        for spine in ax.spines.values():
            spine.set_visible(False)
        ax.set_xlim(-0.5, n_cols - 0.5)
        ax.set_ylim(n_rows - 0.5, -0.5)

        self._hm_fig.tight_layout()
        self._hm_canvas.draw_idle()

    # ── Export ────────────────────────────────────────────────────────────────

    def _export(self):
        import csv
        fn = filedialog.asksaveasfilename(
            title='Export Resolving Results',
            defaultextension='.csv',
            filetypes=[('CSV', '*.csv'), ('All', '*.*')],
            initialfile='resolving_results.csv',
            parent=self.win)
        if not fn:
            return
        try:
            with open(fn, 'w', newline='', encoding='utf-8-sig') as f:
                w = csv.writer(f)
                w.writerow(['Metabolite', 'ID', 'Status',
                            'Anchor peaks', 'Rel. conc estimate',
                            'Peak rank', 'Peak PPM',
                            'Contribution %', 'Residual %'])
                for met in self._metabolites:
                    mid    = met['id']
                    status = self._status.get(mid, '?')
                    ce     = self._conc_est.get(mid, '')
                    for rank, info in self._contributions.items():
                        peak = self._peak_by_rank(rank)
                        if met['name'] not in self._peak_overlap.get(rank, []):
                            continue
                        ppm   = peak['ppm'] if peak else ''
                        pct   = info.get(mid, '')
                        resid = info.get('_residual_pct', '')
                        w.writerow([
                            met['name'], mid, status,
                            '; '.join(str(r) for r in self._anchor_peaks.get(mid, [])),
                            f"{ce:.6g}" if ce else '',
                            rank, f"{ppm:.5f}" if ppm else '',
                            f"{pct:.1f}" if pct != '' else '',
                            f"{resid:.1f}" if resid != '' else '',
                        ])
            messagebox.showinfo('Exported', f"Saved to:\n{fn}", parent=self.win)
        except Exception as e:
            messagebox.showerror('Error', str(e), parent=self.win)

    def _center(self):
        self.win.update_idletasks()
        w  = self.win.winfo_width()
        h  = self.win.winfo_height()
        sw = self.win.winfo_screenwidth()
        sh = self.win.winfo_screenheight()
        self.win.geometry(f'{w}x{h}+{(sw - w) // 2}+{(sh - h) // 2}')
