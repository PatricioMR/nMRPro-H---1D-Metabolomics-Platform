# gui/widgets/peak_resolve_window.py
"""
Peak Overlap Resolver.

Opens when right-clicking a peak that is claimed by multiple metabolites
("🔀 Resolve Peak Overlap").

Layout
------
┌──────────────────────────────────────────────────────────────────┐
│  Header: Peak #N  @  X.XXXX ppm  —  N candidates                │
├───────────────────────────────┬──────────────────────────────────┤
│  Spectrum (matplotlib)        │  Candidates table                │
│  • grey fill  = experimental  │                                  │
│  • grey dashed│= DB position  │  Score columns (see below)       │
│  • coloured   = DB shifted to │                                  │
│    experimental position      │  [★ Assign Selected]  [Cancel]   │
└───────────────────────────────┴──────────────────────────────────┘

Table columns
-------------
  #          rank by resolve score
  Metabolite name
  Δ PPM      distance DB→exp (lower = better)
  DB Mult.   expected multiplicity from DB (s / d / t / q / dd / m …)
  Obs lines  number of visible peaks in the experimental region
  ✓ Mult     whether observed lines match DB expectation
  Met peaks  n_matched / n_total_DB  (how many of this metabolite's
             other DB peaks were also found experimentally)
  Fit        per-peak cosine similarity (exp shape vs DB simulation)
  Assigned   whether this metabolite is already marked Good

Resolve score (0–1):
  0.40 × (1 − Δppm / 0.05)        PPM proximity (penalty caps at 50 mDa)
  0.35 × (n_matched / n_db_total)  fraction of metabolite's DB peaks found
  0.25 × fit                       per-peak spectral shape similarity
"""
import tkinter as tk
from tkinter import ttk, messagebox
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.patches import FancyArrowPatch


_CAND_COLORS = [
    '#e6194b', '#3cb44b', '#4363d8', '#f58231',
    '#911eb4', '#42d4f4', '#f032e6', '#bfef45',
    '#fabed4', '#469990',
]

_MULT_NLINES = {
    's': 1, 'd': 2, 't': 3, 'q': 4, 'p': 5, 'h': 6,
    'dd': 4, 'dt': 6, 'td': 6, 'ddd': 8,
}


def _resolve_score(delta_ppm, n_matched, n_total, fit):
    s_delta = max(0.0, 1.0 - delta_ppm / 0.05)
    s_cov   = n_matched / max(n_total, 1)
    return round(0.40 * s_delta + 0.35 * s_cov + 0.25 * float(fit or 0), 4)


class PeakResolveWindow:
    """
    Parameters
    ----------
    parent         : tk widget
    candidates     : list of (met_dict, mp_dict) – all metabolites that
                     claimed peak_rank, with their specific matched-peak entry
    peak_rank      : int
    peak_ppm       : float  experimental centre
    ppm            : np.ndarray  full ppm axis
    mean_intensity : np.ndarray  mean spectrum over all non-BLK samples
    on_assign      : callable(chosen_met_id, quality_map)
    peaks_list     : list of peak dicts from PeakDetectionStage (optional)
    """

    def __init__(self, parent, candidates, peak_rank, peak_ppm,
                 ppm, mean_intensity, on_assign, peaks_list=None):
        self.candidates     = candidates
        self.peak_rank      = peak_rank
        self.peak_ppm       = peak_ppm
        self.ppm            = ppm
        self.mean_intensity = mean_intensity
        self.on_assign      = on_assign
        self.peaks_list     = peaks_list or []
        self._selected_idx  = None

        self._build_rows()

        self.win = tk.Toplevel(parent)
        self.win.title(
            f"Resolve Peak #{peak_rank}  @  {peak_ppm:.4f} ppm  "
            f"—  {len(candidates)} candidates")
        self.win.geometry('1100x520')
        self.win.minsize(800, 400)
        self.win.grab_set()

        self._build_ui()
        self._populate()
        self._select(0)
        self._center()

    # ── Row data preparation ──────────────────────────────────────────────────

    def _build_rows(self):
        rows = []
        for met, mp in self.candidates:
            n_db      = len(met.get('db_peaks', []))
            n_matched = len(set(round(x['db_ppm'], 3)
                                for x in met.get('matched_peaks', [])))
            delta     = float(mp.get('ppm_diff', 0))

            db_entry  = self._find_db_entry(met, mp)
            fit       = self._peak_cosine(mp, db_entry)

            db_type   = (db_entry.get('type', '') or
                         mp.get('type', '') or '?').lower().strip()
            pred      = mp.get('predicted_lines', [])
            n_db_exp  = len(pred) if pred else _MULT_NLINES.get(db_type, -1)
            n_obs     = self._count_obs_lines(float(mp.get('peak_ppm',
                                                            self.peak_ppm)))
            mult_ok   = self._mult_match(n_db_exp, n_obs)

            score = _resolve_score(delta, n_matched, n_db, fit)
            rows.append({
                'met':       met,
                'mp':        mp,
                'db_entry':  db_entry,
                'delta':     delta,
                'n_matched': n_matched,
                'n_db':      n_db,
                'fit':       fit,
                'db_type':   db_type,
                'n_db_exp':  n_db_exp,
                'n_obs':     n_obs,
                'mult_ok':   mult_ok,
                'score':     score,
                'color':     _CAND_COLORS[len(rows) % len(_CAND_COLORS)],
                'current':   mp.get('annotation_quality') == 'good',
            })
        rows.sort(key=lambda r: r['score'], reverse=True)
        self._rows = rows

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _find_db_entry(self, met, mp):
        db_ppm = float(mp.get('db_ppm', self.peak_ppm))
        return next(
            (p for p in met.get('db_peaks', [])
             if abs(p.get('ppm_center', p.get('ppm', 0)) - db_ppm) < 0.02),
            {'ppm_center': db_ppm, 'ppm_start': db_ppm, 'ppm_end': db_ppm,
             'type': mp.get('type', '?'), 'sticks': []})

    def _peak_cosine(self, mp, db_entry):
        """
        Cosine similarity between the experimental spectrum slice and
        the DB-simulated Lorentzian(s), both aligned to the experimental ppm.
        """
        if self.mean_intensity is None or self.ppm is None:
            return 0.0
        peak_ppm = float(mp.get('peak_ppm', self.peak_ppm))
        db_ppm   = float(mp.get('db_ppm', peak_ppm))
        db_w     = abs(db_entry.get('ppm_end', db_ppm) -
                       db_entry.get('ppm_start', db_ppm))
        win = max(db_w * 3.5, 0.025)

        mask = (self.ppm >= peak_ppm - win) & (self.ppm <= peak_ppm + win)
        if mask.sum() < 5:
            return 0.0
        x     = self.ppm[mask]
        y_exp = self.mean_intensity[mask].astype(float)

        # Build simulated shape aligned to experimental peak
        pred = mp.get('predicted_lines', [])
        if pred:
            sticks = [(float(l['ppm']), float(l['rel_intensity']))
                      for l in pred]
        elif db_entry.get('sticks'):
            offset = peak_ppm - db_ppm
            sticks = [(float(sp) + offset, float(si))
                      for sp, si in db_entry['sticks']]
        else:
            sticks = [(peak_ppm, 1.0)]

        hwhm  = max(db_w / 4.0, 0.0015)
        y_db  = np.zeros_like(x, dtype=float)
        for sp, sr in sticks:
            y_db += sr * hwhm**2 / ((x - sp)**2 + hwhm**2)

        ne = np.linalg.norm(y_exp)
        nd = np.linalg.norm(y_db)
        if ne == 0 or nd == 0:
            return 0.0
        return round(float(np.dot(y_exp / ne, y_db / nd)), 4)

    def _count_obs_lines(self, peak_ppm):
        """Count visible local maxima in experimental spectrum near peak_ppm."""
        if self.mean_intensity is None or self.ppm is None:
            return 0
        win  = 0.05
        mask = (self.ppm >= peak_ppm - win) & (self.ppm <= peak_ppm + win)
        if mask.sum() < 5:
            return 0
        y     = self.mean_intensity[mask]
        y_max = float(np.max(y))
        if y_max <= 0:
            return 0
        thresh = y_max * 0.12  # 12 % of peak max
        # local maxima: point higher than both neighbours
        n = 0
        for i in range(1, len(y) - 1):
            if y[i] > y[i - 1] and y[i] > y[i + 1] and y[i] >= thresh:
                n += 1
        return max(n, 1)

    @staticmethod
    def _mult_match(n_db_exp, n_obs):
        """✓ match  ~  close  ✗ mismatch  ? unknown"""
        if n_db_exp < 0 or n_obs == 0:
            return '?'
        if n_obs == n_db_exp:
            return '✓'
        if abs(n_obs - n_db_exp) == 1:
            return '~'
        return '✗'

    def _sticks_for_plot(self, r, at_db_position=False):
        """Return (sticks, hwhm) for the DB candidate r.
        at_db_position=True → use raw DB ppm (no shift).
        """
        mp       = r['mp']
        db_entry = r['db_entry']
        peak_ppm = float(mp.get('peak_ppm', self.peak_ppm))
        db_ppm   = float(mp.get('db_ppm', self.peak_ppm))
        db_w     = abs(db_entry.get('ppm_end', db_ppm) -
                       db_entry.get('ppm_start', db_ppm))
        hwhm = max(db_w / 4.0, 0.0015)

        pred = mp.get('predicted_lines', [])
        if pred:
            shift = 0.0 if not at_db_position else (db_ppm - peak_ppm)
            sticks = [(float(l['ppm']) + shift, float(l['rel_intensity']))
                      for l in pred]
        elif db_entry.get('sticks'):
            offset = 0.0 if at_db_position else (peak_ppm - db_ppm)
            sticks = [(float(sp) + offset, float(si))
                      for sp, si in db_entry['sticks']]
        else:
            ppm_pos = db_ppm if at_db_position else peak_ppm
            sticks = [(ppm_pos, 1.0)]
        return sticks, hwhm

    # ── UI ───────────────────────────────────────────────────────────────────

    def _build_ui(self):
        hdr = ttk.Frame(self.win, padding=(8, 4))
        hdr.pack(side=tk.TOP, fill=tk.X)
        ttk.Label(hdr,
                  text=(f"Peak #{self.peak_rank}  ·  "
                        f"{self.peak_ppm:.4f} ppm  ·  "
                        f"{len(self._rows)} candidates"),
                  font=('Arial', 10, 'bold')).pack(side=tk.LEFT)
        ttk.Label(hdr,
                  text='Select candidate → plot updates  ·  Double-click or ★ Assign to resolve',
                  font=('Arial', 8), foreground='#555').pack(side=tk.RIGHT, padx=6)

        ttk.Separator(self.win, orient='horizontal').pack(fill=tk.X, padx=4)

        split = tk.PanedWindow(self.win, orient=tk.HORIZONTAL,
                               sashwidth=5, sashrelief=tk.RAISED)
        split.pack(fill=tk.BOTH, expand=True, padx=4, pady=4)

        spec_frame = ttk.LabelFrame(split, text='Peak region', padding=2)
        split.add(spec_frame, minsize=360, stretch='always')
        self._build_plot(spec_frame)

        right = ttk.Frame(split)
        split.add(right, minsize=420, stretch='always')
        self._build_table(right)

    def _build_plot(self, parent):
        self._fig = plt.Figure(figsize=(4.8, 4.2), dpi=100)
        self._fig.patch.set_facecolor('#fafafa')
        self._ax  = self._fig.add_subplot(111)
        self._ax.set_facecolor('#fafafa')
        self._canvas = FigureCanvasTkAgg(self._fig, master=parent)
        self._canvas.draw()
        self._canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)

    def _build_table(self, parent):
        COLS = [
            ('rank',    '#',          28,  tk.CENTER),
            ('name',    'Metabolite', 165, tk.W),
            ('delta',   'Δ PPM',       62, tk.CENTER),
            ('dbtype',  'DB Mult.',    65, tk.CENTER),
            ('obslines','Obs lines',   68, tk.CENTER),
            ('multok',  '✓ Mult',      55, tk.CENTER),
            ('metpks',  'Met peaks',   72, tk.CENTER),
            ('fit',     'Fit',         55, tk.CENTER),
            ('score',   'Score',       58, tk.CENTER),
            ('cur',     'Assigned',    65, tk.CENTER),
        ]
        vsb = ttk.Scrollbar(parent, orient=tk.VERTICAL)
        self.tree = ttk.Treeview(
            parent,
            columns=[c[0] for c in COLS],
            show='headings',
            selectmode='browse',
            yscrollcommand=vsb.set)
        vsb.config(command=self.tree.yview)
        self.tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        vsb.pack(side=tk.LEFT, fill=tk.Y)

        for cid, heading, width, anchor in COLS:
            self.tree.heading(cid, text=heading)
            self.tree.column(cid, width=width, anchor=anchor,
                             minwidth=24, stretch=(cid == 'name'))

        self.tree.tag_configure('best',    background='#e0f0e0', font=('Arial', 9, 'bold'))
        self.tree.tag_configure('normal',  background='white')
        self.tree.tag_configure('current', background='#fff3cd')
        self.tree.tag_configure('bad_mult', foreground='#b30000')
        self.tree.bind('<<TreeviewSelect>>', self._on_tree_sel)
        self.tree.bind('<Double-Button-1>',  lambda e: self._assign())

        # Legend label
        leg = ttk.Frame(parent, padding=(4, 2))
        leg.pack(side=tk.BOTTOM, fill=tk.X, before=self.tree)
        ttk.Label(leg,
                  text=('Δ PPM: shift DB→exp  |  '
                        'Obs lines: visible peaks in spectrum  |  '
                        '✓ Mult: obs matches DB multiplicity  |  '
                        'Met peaks: other peaks of metabolite found  |  '
                        'Fit: shape cosine similarity'),
                  font=('Arial', 7), foreground='#888',
                  wraplength=420, justify=tk.LEFT).pack(
            side=tk.TOP, anchor=tk.W)

        # Bottom bar
        bf = ttk.Frame(parent, padding=(4, 4))
        bf.pack(side=tk.BOTTOM, fill=tk.X)
        ttk.Label(bf,
                  text='Score = 0.40×(1−Δppm/50mDa) + 0.35×(met peaks) + 0.25×fit',
                  font=('Arial', 7), foreground='#888').pack(side=tk.LEFT)
        ttk.Button(bf, text='Cancel',
                   command=self.win.destroy).pack(side=tk.RIGHT, padx=4)
        ttk.Button(bf, text='★ Assign Selected',
                   command=self._assign).pack(side=tk.RIGHT, padx=4)

    # ── Populate ─────────────────────────────────────────────────────────────

    def _populate(self):
        for i, r in enumerate(self._rows):
            tag = ('best' if i == 0 else
                   'current' if r['current'] else 'normal')
            # Highlight bad multiplet mismatch in red text
            if r['mult_ok'] == '✗':
                tag = (tag, 'bad_mult')
            else:
                tag = (tag,)

            n_db_exp_str = (str(r['n_db_exp']) if r['n_db_exp'] > 0
                            else '?')
            self.tree.insert('', tk.END, iid=str(i),
                             tags=tag,
                             values=(
                                 i + 1,
                                 r['met']['name'],
                                 f"{r['delta']:.4f}",
                                 r['db_type'].upper() or '?',
                                 f"{r['n_obs']} (exp {n_db_exp_str})",
                                 r['mult_ok'],
                                 f"{r['n_matched']}/{r['n_db']}",
                                 f"{r['fit']:.3f}",
                                 f"{r['score']:.3f}",
                                 '✓ Yes' if r['current'] else '—',
                             ))

    # ── Plot ─────────────────────────────────────────────────────────────────

    def _draw_plot(self, hl_idx):
        ax = self._ax
        ax.clear()
        ax.set_facecolor('#fafafa')

        margin = 0.14
        vlo = self.peak_ppm - margin
        vhi = self.peak_ppm + margin
        x_sim = np.linspace(vlo, vhi, 800)

        # ── Experimental spectrum ─────────────────────────────────────────────
        y_max = 1.0
        if self.mean_intensity is not None:
            vmask  = (self.ppm >= vlo) & (self.ppm <= vhi)
            x_view = self.ppm[vmask]
            y_view = self.mean_intensity[vmask]
            if len(x_view) >= 2 and np.max(y_view) > 0:
                y_max  = float(np.max(y_view))
                y_n    = y_view / y_max
                ax.fill_between(x_view, 0, y_n,
                                color='#aaaaaa', alpha=0.30, zorder=1,
                                label='Experimental')
                ax.plot(x_view, y_n,
                        color='#444', lw=0.9, alpha=0.75, zorder=2)

        # ── Non-highlighted candidates (tênues) ───────────────────────────────
        for i, r in enumerate(self._rows):
            if i == hl_idx:
                continue
            sticks, hwhm = self._sticks_for_plot(r, at_db_position=False)
            y_db = np.zeros_like(x_sim)
            for sp, sr in sticks:
                y_db += sr * hwhm**2 / ((x_sim - sp)**2 + hwhm**2)
            if y_db.max() > 0:
                y_db /= y_db.max()
            ax.plot(x_sim, y_db,
                    color=r['color'], lw=0.7, alpha=0.22,
                    zorder=3, ls='-')

        # ── Highlighted candidate ─────────────────────────────────────────────
        if 0 <= hl_idx < len(self._rows):
            r   = self._rows[hl_idx]
            col = r['color']
            mp  = r['mp']
            peak_ppm_r = float(mp.get('peak_ppm', self.peak_ppm))
            db_ppm_r   = float(mp.get('db_ppm',   self.peak_ppm))

            # DB position overlay (grey dashed) — "where DB says it should be"
            sticks_db, hwhm = self._sticks_for_plot(r, at_db_position=True)
            y_at_db = np.zeros_like(x_sim)
            for sp, sr in sticks_db:
                y_at_db += sr * hwhm**2 / ((x_sim - sp)**2 + hwhm**2)
            if y_at_db.max() > 0:
                y_at_db /= y_at_db.max()
            ax.fill_between(x_sim, 0, y_at_db,
                            color='#999999', alpha=0.10, zorder=4)
            ax.plot(x_sim, y_at_db,
                    color='#888888', lw=1.0, alpha=0.45, zorder=5,
                    ls='--', label=f"DB position ({db_ppm_r:.4f})")

            # Experimental-aligned overlay (solid, coloured)
            sticks_exp, _ = self._sticks_for_plot(r, at_db_position=False)
            y_at_exp = np.zeros_like(x_sim)
            for sp, sr in sticks_exp:
                y_at_exp += sr * hwhm**2 / ((x_sim - sp)**2 + hwhm**2)
            if y_at_exp.max() > 0:
                y_at_exp /= y_at_exp.max()
            ax.fill_between(x_sim, 0, y_at_exp,
                            color=col, alpha=0.28, zorder=6)
            ax.plot(x_sim, y_at_exp,
                    color=col, lw=2.0, alpha=0.90, zorder=7,
                    label=f"{r['met']['name'][:24]} (aligned)")

            # ── Vertical markers ──────────────────────────────────────────────
            ax.axvline(db_ppm_r, color='#888888', lw=1.0, ls='--',
                       alpha=0.55, zorder=8)
            ax.axvline(peak_ppm_r, color=col, lw=1.2, ls=':',
                       alpha=0.70, zorder=8)

            # ── Δppm annotation arrow ─────────────────────────────────────────
            if abs(peak_ppm_r - db_ppm_r) > 0.0005:
                y_arrow = 1.05
                ax.annotate(
                    '', xy=(peak_ppm_r, y_arrow),
                    xytext=(db_ppm_r,   y_arrow),
                    arrowprops=dict(arrowstyle='<->',
                                    color='#555555', lw=1.2))
                mid = (peak_ppm_r + db_ppm_r) / 2
                ax.text(mid, y_arrow + 0.06,
                        f"Δ {r['delta']:.4f} ppm",
                        ha='center', va='bottom',
                        fontsize=7, color='#333333')

            # ── Multiplicity annotation ───────────────────────────────────────
            db_type_str = r['db_type'].upper() or '?'
            n_exp_str   = (str(r['n_db_exp']) if r['n_db_exp'] > 0 else '?')
            mult_color  = ({'✓': '#1a7a1a', '~': '#7a6000',
                            '✗': '#9a0000', '?': '#777777'}
                           .get(r['mult_ok'], '#777777'))
            ax.text(0.02, 0.97,
                    f"DB: {db_type_str} ({n_exp_str} lines)  "
                    f"obs: {r['n_obs']} lines  {r['mult_ok']}",
                    transform=ax.transAxes,
                    ha='left', va='top', fontsize=8,
                    color=mult_color,
                    bbox=dict(boxstyle='round,pad=0.3',
                              facecolor='white', alpha=0.75, edgecolor='none'))

        ax.axvline(self.peak_ppm, color='#333', lw=0.7,
                   ls=':', alpha=0.4, zorder=2)
        ax.invert_xaxis()
        ax.set_xlim(vhi + 0.01, vlo - 0.01)
        ax.set_ylim(-0.05, 1.25)
        ax.set_xlabel('δ (ppm)', fontsize=8)
        ax.set_ylabel('Intensity (norm.)', fontsize=8)
        ax.tick_params(labelsize=7)
        ax.grid(True, alpha=0.15, ls=':')
        ax.legend(fontsize=7, loc='upper right', framealpha=0.85)
        self._fig.tight_layout()
        self._canvas.draw_idle()

    # ── Selection ─────────────────────────────────────────────────────────────

    def _select(self, idx):
        if idx < 0 or idx >= len(self._rows):
            return
        self._selected_idx = idx
        self.tree.selection_set(str(idx))
        self.tree.see(str(idx))
        self._draw_plot(idx)

    def _on_tree_sel(self, e=None):
        sel = self.tree.selection()
        if not sel:
            return
        try:
            idx = int(sel[0])
        except ValueError:
            return
        if idx != self._selected_idx:
            self._select(idx)

    # ── Assign ────────────────────────────────────────────────────────────────

    def _assign(self):
        idx = self._selected_idx
        if idx is None:
            messagebox.showwarning('No selection',
                                   'Select a metabolite first.',
                                   parent=self.win)
            return
        chosen_id = self._rows[idx]['met']['id']
        quality_map = {r['met']['id']: ('good' if r['met']['id'] == chosen_id
                                        else 'bad')
                       for r in self._rows}
        self.on_assign(chosen_id, quality_map)
        self.win.destroy()

    def _center(self):
        self.win.update_idletasks()
        w  = self.win.winfo_width()
        h  = self.win.winfo_height()
        sw = self.win.winfo_screenwidth()
        sh = self.win.winfo_screenheight()
        self.win.geometry(f'{w}x{h}+{(sw - w) // 2}+{(sh - h) // 2}')
