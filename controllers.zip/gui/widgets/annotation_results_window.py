# gui/widgets/annotation_results_window.py
"""
Metabolite Annotation Results Window.

Layout:
  Left  (A): Hierarchical Treeview
             ├─ Metabolite name  (coverage %, n matched / n total peaks)
             │    ├─ Peak #1  3.2341 ppm  Δ 0.002  ✓ matched
             │    └─ Peak #2  1.4100 ppm  Δ 0.005  ✓ matched
             └─ ...

  Right (B): Fingerprint comparison plot
             • Grey filled area  = experimental spectrum (mean of all samples)
             • Coloured sticks   = DB fingerprint (multiplet centres + heights)
             • Matched sticks    = green;  unmatched = red
             • Info card with coverage %, cosine similarity, n matched
"""
import tkinter as tk
from tkinter import ttk
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg


# ── Local baseline helper ─────────────────────────────────────────────────────

def _local_linear_baseline(y, edge_frac=0.12, percentile=15):
    """
    Estimate a linear baseline from the low-percentile of the edge regions.
    Returns an array the same shape as y, clipped to not exceed y.
    Used to remove broad underlying signals before visualising narrow multiplets.
    """
    n      = len(y)
    n_edge = max(2, int(n * edge_frac))
    bl_l   = float(np.percentile(y[:n_edge],  percentile))
    bl_r   = float(np.percentile(y[-n_edge:], percentile))
    bl     = np.linspace(bl_l, bl_r, n)
    return np.minimum(bl, y)


# ── Multiplet intensity helpers ───────────────────────────────────────────────

def _binomial_coeffs(n):
    """Pascal's triangle row n (0-indexed). Row 1 = [1,1], row 2 = [1,2,1]..."""
    from math import comb
    return [comb(n - 1, k) for k in range(n)]


def _relative_intensities_from_type(mult_type, protons):
    """
    Return normalised relative intensities for a multiplet.
    E.g. triplet → [1, 2, 1] / 4  (sum=1)

    Multiplicity mapping (standard NMR):
      s  = singlet  → [1]
      d  = doublet  → [1, 1]
      t  = triplet  → [1, 2, 1]
      q  = quartet  → [1, 3, 3, 1]
      p  = pentet   → [1, 4, 6, 4, 1]
      dd = dd       → [1, 1, 1, 1]   (approximation)
      m  = multiplet → flat (protons equal height)
    """
    mt = (mult_type or 'm').lower().strip()
    mapping = {
        's':  [1],
        'd':  [1, 1],
        't':  [1, 2, 1],
        'q':  [1, 3, 3, 1],
        'p':  [1, 4, 6, 4, 1],
        'h':  [1, 5, 10, 10, 5, 1],
        'dd': [1, 1, 1, 1],
        'dt': [1, 2, 1, 1, 2, 1],
        'td': [1, 1, 2, 2, 1, 1],
    }
    if mt in mapping:
        coeffs = mapping[mt]
    elif mt == 'm' and protons and protons > 1:
        coeffs = [1] * protons
    else:
        coeffs = [1]
    total = sum(coeffs)
    return [c / total for c in coeffs]  # normalised, sum = 1


def _build_stick_positions(ppm_center, mult_type, protons, j_coupling_hz=None,
                           field_mhz=600.0, ppm_span=None):
    """
    Generate individual stick (ppm, relative_intensity) pairs for a multiplet.
    If J-coupling and field strength are known, space sticks by J/field (in ppm).
    If j_coupling_hz is absent but ppm_span (ppm_end - ppm_start from DB) is
    provided, derive spacing from the observed span.
    Otherwise fall back to a default spacing (~7 Hz at the given field).
    """
    intensities = _relative_intensities_from_type(mult_type, protons)
    n = len(intensities)
    if n == 1:
        return [(ppm_center, intensities[0])]

    # Try to parse J coupling
    j_hz = None
    if j_coupling_hz:
        try:
            j_hz = float(str(j_coupling_hz).split(',')[0].strip())
        except Exception:
            pass

    if j_hz:
        spacing_ppm = j_hz / field_mhz
    elif ppm_span and ppm_span > 1e-4 and n > 1:
        # Derive spacing from the DB-recorded ppm span (ppm_end - ppm_start)
        spacing_ppm = ppm_span / (n - 1)
    else:
        # Default ~7 Hz (typical 3J coupling) at the given field
        spacing_ppm = 7.0 / field_mhz

    # Centre the sticks symmetrically around ppm_center
    total_span = spacing_ppm * (n - 1)
    start_ppm  = ppm_center - total_span / 2
    sticks = [(start_ppm + i * spacing_ppm, intensities[i]) for i in range(n)]
    return sticks


def _rri_score(exp_peaks_in_region, db_sticks, tolerance=0.02):
    """
    Relative Intensity Ratio (RRI) score — how well the experimental
    relative intensities match the DB.

    Returns a score 0–1 (1 = perfect intensity match).
    """
    if len(db_sticks) < 2:
        return None  # singlet: no ratio to compare
    if not exp_peaks_in_region:
        return 0.0

    # For each DB stick, find the closest experimental signal
    db_ints  = []
    exp_ints = []
    for ppm_db, int_db in db_sticks:
        closest = min(exp_peaks_in_region, key=lambda p: abs(p[0] - ppm_db))
        if abs(closest[0] - ppm_db) <= tolerance:
            db_ints.append(int_db)
            exp_ints.append(closest[1])

    if len(db_ints) < 2:
        return None
    db_arr  = np.array(db_ints,  dtype=float)
    exp_arr = np.array(exp_ints, dtype=float)
    # Normalise both to max=1
    db_arr  /= db_arr.max()
    exp_arr /= exp_arr.max() if exp_arr.max() > 0 else 1
    # Mean absolute deviation from ideal ratios (1 = perfect, 0 = terrible)
    mad = float(np.mean(np.abs(db_arr - exp_arr)))
    return max(0.0, 1.0 - mad)


def _peak_shape_score(ppm_arr, intensity_arr, shifted_sticks,
                      center_ppm, db_entry, hwhm_default=0.004):
    """
    Compute how well the experimental spectrum shape overlaps the
    simulated DB multiplet (sum of Lorentzianas at shifted_sticks).

    Returns a score 0–1:
      1.0 = perfect overlap
      The score is cosine similarity between the experimental slice
      and the simulated DB shape over a ±6×HWHM window.
    """
    if not shifted_sticks:
        return None

    db_width = max(
        abs(db_entry.get('ppm_end', center_ppm) -
            db_entry.get('ppm_start', center_ppm)),
        0.002)
    hwhm = max(db_width / 2, hwhm_default)
    win  = hwhm * 16

    lo = center_ppm - win
    hi = center_ppm + win
    mask = (ppm_arr >= lo) & (ppm_arr <= hi)
    if mask.sum() < 3:
        return None

    x   = ppm_arr[mask]
    y_e = intensity_arr[mask].astype(float)

    # Simulated DB shape at same x points
    y_db = np.zeros_like(x)
    for st_ppm, st_rel in shifted_sticks:
        y_db += st_rel * hwhm**2 / ((x - st_ppm)**2 + hwhm**2)

    # Normalise both to unit vectors
    ne = np.linalg.norm(y_e)
    nd = np.linalg.norm(y_db)
    if ne == 0 or nd == 0:
        return 0.0
    return float(np.dot(y_e / ne, y_db / nd))


def _cosine_similarity(exp_ppm, exp_int, db_peaks, tolerance=0.05):
    """
    Compute cosine similarity between experimental spectrum (as a sparse
    vector at detected peak positions) and the DB fingerprint.
    Only considers peaks within the experimental ppm range.
    """
    if not db_peaks:
        return 0.0
    # Build vectors aligned on the DB peak positions
    v_exp, v_db = [], []
    for dp in db_peaks:
        dp_ppm = dp.get('ppm_center', dp.get('ppm', 0))
        # Find closest experimental peak
        diffs = [abs(ep - dp_ppm) for ep in exp_ppm]
        if not diffs:
            continue
        min_diff = min(diffs)
        idx      = diffs.index(min_diff)
        v_db.append(float(dp.get('height', dp.get('intensity', 1.0)) or 1.0))
        v_exp.append(exp_int[idx] if min_diff <= tolerance else 0.0)
    if not v_exp or not any(v_exp) or not any(v_db):
        return 0.0
    v_exp = np.array(v_exp, dtype=float)
    v_db  = np.array(v_db,  dtype=float)
    norm  = np.linalg.norm(v_exp) * np.linalg.norm(v_db)
    return float(np.dot(v_exp, v_db) / norm) if norm > 0 else 0.0


class AnnotationResultsWindow:
    def __init__(self, parent, results, peaks, ppm, all_intensities,
                 db_path, db_conn=None, elapsed=0, app=None,
                 saved_quality=None):
        """
        Parameters
        ----------
        results        : flat list of match dicts from search_task
        peaks          : list of detected peak dicts (from PeakDetectionStage)
        ppm            : np.ndarray  full ppm axis
        all_intensities: np.ndarray  (n_points × n_samples)
        db_path        : path to the sqlite DB (to fetch full fingerprints)
        db_conn        : open sqlite3.Connection  (may be None — reopen if needed)
        elapsed        : float  search time in seconds
        app            : App instance (for group colours)
        saved_quality  : dict {(met_id, peak_rank): 'good'|'bad'} to restore
                         user annotations when the window is reopened.
        """
        self.results         = results
        self.peaks           = peaks
        self.ppm             = ppm
        self.all_intensities = all_intensities
        self.mean_intensity  = np.mean(all_intensities, axis=1)
        self.db_path         = db_path
        self.app             = app
        self._current_met    = None   # currently selected metabolite dict

        # Group results by metabolite
        self.metabolites = self._group_by_metabolite(results)

        # Fetch full DB fingerprints for each metabolite
        self._fetch_fingerprints(db_path)

        # Mark peaks that fall below the detection limit (expected SNR < 3)
        self._compute_detectability()

        # Restore previously saved quality marks (survives window close/reopen)
        if saved_quality:
            self._apply_saved_quality(saved_quality)

        self.win = tk.Toplevel(parent)
        self.win.title(
            f"Annotation Results  —  {len(self.metabolites)} metabolites  "
            f"({elapsed:.1f}s)")
        self.win.geometry("1300x650")
        self.win.minsize(900, 500)

        self._iid_to_row   = {}   # piid → (rank, met, mp, det_pk)
        self._iid_to_child = {}   # ciid → (met, dp_dict)
        self._compute_overlap()
        self._auto_mark_good()
        self._build_peak_assignments()
        self._build()
        self._populate()
        self._center()

    def _apply_saved_quality(self, saved_quality):
        """Re-apply persisted quality marks to the freshly built metabolites."""
        for met in self.metabolites:
            for mp in met['matched_peaks']:
                key = (met['id'], mp.get('peak_rank'))
                if key in saved_quality:
                    mp['annotation_quality'] = saved_quality[key]

    # ── Data preparation ──────────────────────────────────────────────────────

    def _group_by_metabolite(self, results):
        """
        Group flat match rows by metabolite ID.
        Returns list of dicts: {id, name, matched_peaks, coverage, ...}
        """
        groups = {}
        for r in results:
            mid  = (r.get('hmdb_id') or r.get('bmrb_id') or r.get('id', '?'))
            name = r.get('name', '?')
            if mid not in groups:
                groups[mid] = {
                    'id':            mid,
                    'name':          name,
                    'matched_peaks': [],   # (peak_ppm, db_ppm, ppm_diff, peak_rank)
                    'db_peaks':      [],   # full DB fingerprint (fetched later)
                    'coverage':      0.0,
                    'cosine':        0.0,
                    'source':        r.get('database', r.get('source', '?')),
                }
            dp_ppm = r.get('ppm_center', r.get('ppm', 0))
            pl     = r.get('predicted_lines', [])
            # Multiplet centre = intensity-weighted mean of matched lines.
            # This correctly handles doublet (1:1), triplet (1:2:1), etc.
            if len(pl) > 1:
                tot_rel = sum(l.get('rel_intensity', 1.0) for l in pl)
                if tot_rel > 0:
                    obs_centre = sum(l['ppm'] * l.get('rel_intensity', 1.0)
                                     for l in pl) / tot_rel
                else:
                    obs_centre = (pl[0]['ppm'] + pl[-1]['ppm']) / 2
                ppm_diff   = abs(obs_centre - dp_ppm)
                peak_ppm   = obs_centre
            else:
                peak_ppm  = r.get('peak_ppm', 0)
                ppm_diff  = r.get('ppm_diff', abs(peak_ppm - dp_ppm))
            groups[mid]['matched_peaks'].append({
                'peak_ppm':        peak_ppm,
                'peak_rank':       r.get('peak_rank', '?'),
                'db_ppm':          dp_ppm,
                'ppm_diff':        ppm_diff,
                'protons':         r.get('protons', ''),
                'type':            r.get('type', r.get('match_type', '')),
                'predicted_lines': pl,
                'multiplet_score': r.get('multiplet_score', 0.0),
                'composite_score': r.get('composite_score', 0.0),
                'multiplet_detail':r.get('multiplet_detail', ''),
                'j_coupling':      r.get('j_coupling', ''),
            })
            # Track best composite score for metabolite sorting
            cs = r.get('composite_score', 0)
            if cs > groups[mid].get('best_score', 0):
                groups[mid]['best_score'] = cs
        return list(groups.values())

    def _fetch_fingerprints(self, db_path):
        """Fetch fingerprint peaks. Supports BMRB (shifts_1h) and HMDB (multiplets) schemas."""
        import sqlite3
        if not db_path or not str(db_path).endswith('.db'):
            # No SQLite database available (e.g., built-in CSV library) —
            # populate db_peaks from the matched peak ranges already in results.
            for met in self.metabolites:
                if not met['db_peaks']:
                    met['db_peaks'] = [
                        {'ppm_center': mp['db_ppm'],
                         'ppm_start':  mp['db_ppm'] - 0.005,
                         'ppm_end':    mp['db_ppm'] + 0.005,
                         'type':       mp.get('type', ''),
                         'protons':    1}
                        for mp in met['matched_peaks']
                    ]
                n_db = len(met['db_peaks'])
                n_matched = len(set(round(mp['db_ppm'], 3)
                                    for mp in met['matched_peaks']))
                met['coverage'] = (n_matched / n_db * 100) if n_db else 0.0
                # Cosine falls back to coverage fraction when no spectral DB
                met['cosine'] = met['coverage'] / 100.0
            return
        try:
            conn = sqlite3.connect(db_path)
            conn.row_factory = sqlite3.Row
            cur  = conn.cursor()
            tables = {r[0] for r in cur.execute(
                "SELECT name FROM sqlite_master WHERE type='table'"
            ).fetchall()}
            is_bmrb = 'shifts_1h' in tables
            for met in self.metabolites:
                mid = met['id']
                if is_bmrb:
                    cur.execute(
                        "SELECT ppm AS ppm_center, ppm AS ppm_start,"
                        " ppm AS ppm_end, '' AS protons,"
                        " multiplicity AS type, j_coupling, atom_name"
                        " FROM shifts_1h WHERE bmrb_id = ?"
                        " ORDER BY ppm DESC", (mid,))
                    rows = [dict(r) for r in cur.fetchall()]
                    if 'transitions' in tables:
                        for dp in rows:
                            cur.execute(
                                "SELECT ppm, intensity FROM transitions"
                                " WHERE bmrb_id = ? AND ABS(ppm - ?) < 0.15"
                                " ORDER BY ppm DESC", (mid, dp['ppm_center']))
                            tr = cur.fetchall()
                            if tr:
                                dp['sticks'] = [(r['ppm'], r['intensity'] or 1.0)
                                                for r in tr]
                    met['db_peaks'] = rows
                else:
                    cur.execute(
                        "SELECT ppm_center, ppm_start, ppm_end, protons, type, j_coupling "
                        "FROM multiplets WHERE hmdb_id = ? "
                        "ORDER BY ppm_center DESC", (met['id'],))
                    rows = [dict(r) for r in cur.fetchall()]
                    if not rows:
                        cur.execute(
                            "SELECT ppm AS ppm_center, ppm AS ppm_start,"
                            " ppm AS ppm_end, '' AS protons, 'peak' AS type"
                            " FROM peaks WHERE hmdb_id = ? ORDER BY ppm DESC",
                            (met['id'],))
                        rows = [dict(r) for r in cur.fetchall()]
                    met['db_peaks'] = rows

                # Compute coverage: what fraction of DB peaks are matched
                n_db      = len(met['db_peaks'])
                n_matched = len(set(
                    round(mp['db_ppm'], 3)
                    for mp in met['matched_peaks']))
                met['coverage'] = (n_matched / n_db * 100) if n_db else 0.0

                # Build stick positions + attach scorer predicted_lines
                _mp_by_dbppm = {round(mp['db_ppm'], 3): mp
                                for mp in met['matched_peaks']}
                for dp in met['db_peaks']:
                    dp_key = round(dp.get('ppm_center', dp.get('ppm', 0)), 3)
                    sticks = _build_stick_positions(
                        dp.get('ppm_center', dp.get('ppm', 0)),
                        dp.get('type', 'm'),
                        dp.get('protons', 1),
                        dp.get('j_coupling'))
                    dp['sticks'] = sticks
                    mp_ref = _mp_by_dbppm.get(dp_key)
                    dp['predicted_lines'] = (
                        mp_ref.get('predicted_lines', []) if mp_ref else [])

                # Per-peak shape score: for each matched peak, compute how
                # well the experimental shape overlaps the simulated DB multiplet.
                # Score = max(individual peak scores) * 0.7
                #       + mean(other peak scores)  * 0.3
                # → one perfect match already gives a high score.
                peak_scores = []
                ppm_arr = self.ppm
                int_arr = self.mean_intensity
                has_spec = (ppm_arr is not None and int_arr is not None
                            and len(ppm_arr) > 10)
                for mp in met['matched_peaks']:
                    db_ppm   = mp['db_ppm']
                    # Always find closest db_peak (no hard threshold)
                    db_entry = (min(met['db_peaks'],
                                    key=lambda p: abs(p.get('ppm_center',
                                        p.get('ppm', 0)) - db_ppm))
                                if met['db_peaks'] else None) or \
                               {'ppm_center': db_ppm,
                                'ppm_start': db_ppm, 'ppm_end': db_ppm}
                    # Build sticks — prefer real transitions, then reconstruct
                    pred_lines = mp.get('predicted_lines') or []
                    if pred_lines:
                        shifted = [(l['ppm'], l['rel_intensity'])
                                   for l in pred_lines]
                    else:
                        sticks = db_entry.get('sticks') or []
                        if not sticks:
                            mult = db_entry.get('type', 's') or 's'
                            try:    protons = int(db_entry.get('protons') or 1)
                            except: protons = 1
                            sticks = _build_stick_positions(
                                db_ppm, mult, protons, db_entry.get('j_coupling'))
                        if not sticks:
                            sticks = [(db_ppm, 1.0)]
                        offset  = mp['peak_ppm'] - db_ppm
                        shifted = [(sp + offset, si) for sp, si in sticks]
                    if not has_spec:
                        peak_scores.append(
                            max(0.0, 1.0 - mp.get('ppm_diff', 0) / 0.05))
                        continue
                    pk = next((p for p in self.peaks
                               if abs(p['ppm'] - mp['peak_ppm']) < 0.01), None)
                    hwhm = (max(pk.get('width_ppm',
                                pk.get('width_at_half', 0.004)), 0.002) / 2
                            if pk else 0.004)
                    ps = _peak_shape_score(
                        ppm_arr, int_arr, shifted,
                        mp['peak_ppm'], db_entry, hwhm_default=hwhm)
                    if ps is None:
                        ps = max(0.0, 1.0 - mp.get('ppm_diff', 0) / 0.05)
                    if ps is not None:
                        peak_scores.append(ps)

                if peak_scores:
                    best  = max(peak_scores)
                    rest  = sorted(peak_scores)[:-1]  # all but best
                    mean_rest = float(np.mean(rest)) if rest else best
                    # Best peak dominates (70%), others contribute (30%)
                    met['cosine'] = best * 0.70 + mean_rest * 0.30
                else:
                    met['cosine'] = met['coverage'] / 100.0

                # RRI across matched multiplets
                exp_peaks_region = []
                if has_spec and self.peaks:
                    for p in self.peaks:
                        idx = int(np.argmin(np.abs(ppm_arr - p['ppm'])))
                        exp_peaks_region.append(
                            (p['ppm'], float(int_arr[idx])))
                rri_scores = []
                for dp in met['db_peaks']:
                    rri = _rri_score(exp_peaks_region, dp.get('sticks', []))
                    if rri is not None:
                        rri_scores.append(rri)
                met['rri'] = float(np.mean(rri_scores)) if rri_scores else None

            conn.close()
        except Exception as e:
            import traceback; traceback.print_exc()
            print(f"Fingerprint fetch error: {e}")

        # Safety net: cosine must not stay at 0 when coverage > 0
        for met in self.metabolites:
            if met.get('cosine', 0.0) == 0.0 and met.get('coverage', 0.0) > 0:
                met['cosine'] = met['coverage'] / 100.0

    # ── Layout ────────────────────────────────────────────────────────────────

    def _build(self):
        paned = tk.PanedWindow(
            self.win, orient=tk.HORIZONTAL,
            sashwidth=6, sashrelief=tk.RAISED)
        paned.pack(fill=tk.BOTH, expand=True, padx=4, pady=4)

        # ── Panel A ───────────────────────────────────────────────────────────
        frame_a = ttk.Frame(paned)
        paned.add(frame_a, minsize=420)

        n_pk  = len(set(mp['peak_rank']
                        for m in self.metabolites
                        for mp in m['matched_peaks']))
        n_met = len(self.metabolites)
        self._summary_lbl = ttk.Label(
            frame_a,
            text=f"{n_pk} peaks assigned  ·  {n_met} metabolites",
            font=("Arial", 9, "italic"), foreground="gray")
        self._summary_lbl.pack(anchor=tk.W, padx=4, pady=(4, 2))
        ttk.Label(frame_a,
                  text="Ctrl+1 = Good  ·  Ctrl+2 = Undef (→ MCR)  ·  Ctrl+3 = Bad",
                  font=("Arial", 7), foreground="#888").pack(
            anchor=tk.W, padx=4, pady=(0, 2))

        # Name search
        sf = ttk.Frame(frame_a)
        sf.pack(fill=tk.X, padx=4, pady=(0, 2))
        ttk.Label(sf, text="🔍").pack(side=tk.LEFT)
        self._flt_name = tk.StringVar()
        ttk.Entry(sf, textvariable=self._flt_name,
                  width=22).pack(side=tk.LEFT, padx=2)
        self._flt_name.trace_add('write', lambda *_: self._populate())
        ttk.Button(sf, text='✕', width=2,
                   command=lambda: self._flt_name.set('')
                   ).pack(side=tk.LEFT)

        # Quality filter checkboxes
        qf = ttk.Frame(frame_a)
        qf.pack(fill=tk.X, padx=4, pady=(0, 4))
        ttk.Label(qf, text='Show:', font=('Arial', 8)).pack(side=tk.LEFT, padx=(0, 4))
        self._ann_filt_good  = tk.BooleanVar(value=True)
        self._ann_filt_bad   = tk.BooleanVar(value=True)
        self._ann_filt_undef = tk.BooleanVar(value=True)
        self._ann_filt_bdl   = tk.BooleanVar(value=True)
        # 'm' multiplets are permanently excluded (no J values available)
        self._ann_filt_mult_m = False
        for text, var, bg, fg in [
            ('✓ Good',  self._ann_filt_good,  '#c8f7c5', '#1a7a1a'),
            ('✗ Bad',   self._ann_filt_bad,   '#ffd6d6', '#9a0000'),
            ('— Undef', self._ann_filt_undef, '#f0f0f0', '#444444'),
            ('⬇ BDL',   self._ann_filt_bdl,   '#ebebeb', '#888888'),
        ]:
            tk.Checkbutton(qf, text=text, variable=var,
                           bg=bg, fg=fg, selectcolor=bg,
                           activebackground=bg, font=('Arial', 8),
                           command=self._populate).pack(side=tk.LEFT, padx=2)

        # Treeview
        tf  = ttk.Frame(frame_a)
        tf.pack(fill=tk.BOTH, expand=True, padx=4, pady=4)
        vsb = ttk.Scrollbar(tf, orient=tk.VERTICAL)
        hsb = ttk.Scrollbar(tf, orient=tk.HORIZONTAL)

        self.tree = ttk.Treeview(
            tf,
            columns=('name', 'ppm', 'start', 'end', 'score', 'quality', 'overlap'),
            show='tree headings',
            selectmode='browse',
            yscrollcommand=vsb.set,
            xscrollcommand=hsb.set)
        vsb.config(command=self.tree.yview)
        hsb.config(command=self.tree.xview)
        self.tree.grid(row=0, column=0, sticky='nsew')
        vsb.grid(row=0, column=1, sticky='ns')
        hsb.grid(row=1, column=0, sticky='ew')
        tf.grid_rowconfigure(0, weight=1)
        tf.grid_columnconfigure(0, weight=1)

        self.tree.heading('#0',      text='Peak #',
                          command=lambda: self._sort_by('ppm'))
        self.tree.heading('name',    text='Metabolite',
                          command=lambda: self._sort_by('name'))
        self.tree.heading('ppm',     text='PPM',
                          command=lambda: self._sort_by('ppm'))
        self.tree.heading('start',   text='Start')
        self.tree.heading('end',     text='End')
        self.tree.heading('score',   text='Score',
                          command=lambda: self._sort_by('score'))
        self.tree.heading('quality', text='Quality / Match')
        self.tree.heading('overlap', text='Overlap')
        self.tree.column('#0',      width=90,  minwidth=70)
        self.tree.column('name',    width=190, minwidth=130)
        self.tree.column('ppm',     width=80,  minwidth=60, anchor=tk.CENTER)
        self.tree.column('start',   width=78,  minwidth=60, anchor=tk.CENTER)
        self.tree.column('end',     width=78,  minwidth=60, anchor=tk.CENTER)
        self.tree.column('score',   width=65,  minwidth=50, anchor=tk.CENTER)
        self.tree.column('quality', width=70,  minwidth=50, anchor=tk.CENTER)
        self.tree.column('overlap', width=65,  minwidth=50, anchor=tk.CENTER)

        self.tree.tag_configure('met_high',   foreground='#1a7a1a',
                                background='#f0fff0')
        self.tree.tag_configure('met_mid',    foreground='#7a6000',
                                background='#fffff0')
        self.tree.tag_configure('met_low',    foreground='#9a0000',
                                background='#fff0f0')
        self.tree.tag_configure('peak_match', foreground='#1a1a2e')
        self.tree.tag_configure('mult_info',  foreground='#1a5c2e',
                                background='#e8f5e9', font=('Courier', 8))
        self.tree.tag_configure('qual_good',  background='#d6f5d6')
        self.tree.tag_configure('qual_bad',   background='#f5d6d6')
        self.tree.tag_configure('qual_mid',   background='#fff3cc')  # overlap warning
        self.tree.tag_configure('qual_bdl',   foreground='#999999', background='#f0f0f0')
        self.tree.bind('<<TreeviewSelect>>', self._on_select)
        self.tree.bind('<Button-3>', self._on_right_click)
        self.tree.bind('<<TreeviewClose>>', self._on_tree_close)
        self.win.bind('<Control-Key-1>', lambda e: self._classify('good'))
        self.win.bind('<Control-Key-2>', lambda e: self._classify(None))  # → Undef → MCR
        self.win.bind('<Control-Key-3>', lambda e: self._classify('bad'))

        # Export / action buttons
        bf = ttk.Frame(frame_a)
        bf.pack(fill=tk.X, padx=4, pady=4)
        ttk.Button(bf, text="Export CSV",
                   command=self._export).pack(side=tk.LEFT)
        ttk.Button(bf, text="🔬 Deconvolve Undef",
                   command=self._open_mcr_deconv).pack(side=tk.LEFT, padx=6)
        ttk.Button(bf, text="Close",
                   command=self.win.destroy).pack(side=tk.RIGHT)

        # ── Panel B ───────────────────────────────────────────────────────────
        frame_b = ttk.Frame(paned)
        paned.add(frame_b, minsize=500)

        ttk.Label(frame_b, text="Fingerprint Comparison",
                  font=("Arial", 10, "bold")).pack(
            anchor=tk.W, padx=4, pady=(4, 0))
        self.match_info = ttk.Label(
            frame_b, text="Select a metabolite to see fingerprint",
            font=("Arial", 8), foreground="gray")
        self.match_info.pack(anchor=tk.W, padx=4)
        ttk.Label(frame_b,
                  text="Tip: right-drag on zoom view to select peak region",
                  font=("Arial", 7), foreground="#999").pack(anchor=tk.W, padx=4)

        self.fig = plt.Figure(figsize=(6, 4), dpi=100)
        self.ax  = self.fig.add_subplot(111)
        self.fig.patch.set_facecolor('#f8f8f8')

        self.plot_canvas = FigureCanvasTkAgg(self.fig, master=frame_b)
        self.plot_canvas.draw()
        
        # Toolbar: BOTTOM inside frame_b, before canvas TOP
        from matplotlib.backends.backend_tkagg import NavigationToolbar2Tk
        self._toolbar = NavigationToolbar2Tk(self.plot_canvas, frame_b, pack_toolbar=False)
        self._toolbar.update()
        self._toolbar.pack(side=tk.BOTTOM, fill=tk.X)

        self.plot_canvas.get_tk_widget().pack(
            side=tk.TOP, fill=tk.BOTH, expand=True, padx=4, pady=4)

        # Scroll/pan on the fingerprint plot
        self._pan_active = False
        self._pan_start  = None
        self.plot_canvas.mpl_connect('scroll_event',         self._zoom)
        self.plot_canvas.mpl_connect('button_press_event',   self._pan_press)
        self.plot_canvas.mpl_connect('button_release_event', self._pan_release)
        self.plot_canvas.mpl_connect('motion_notify_event',  self._pan_move)

        # Quality card — scrollable so it never gets cut off
        qf_outer = ttk.LabelFrame(frame_b, text="Match Quality", padding=4)
        qf_outer.pack(fill=tk.X, padx=4, pady=(0, 2))

        _qf_canvas = tk.Canvas(qf_outer, height=110, bd=0, highlightthickness=0)
        _qf_vsb    = ttk.Scrollbar(qf_outer, orient=tk.VERTICAL,
                                   command=_qf_canvas.yview)
        _qf_canvas.configure(yscrollcommand=_qf_vsb.set)
        _qf_vsb.pack(side=tk.RIGHT, fill=tk.Y)
        _qf_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        qf = ttk.Frame(_qf_canvas, padding=2)
        _qf_win = _qf_canvas.create_window((0, 0), window=qf, anchor='nw')

        def _qf_configure(e):
            _qf_canvas.configure(scrollregion=_qf_canvas.bbox('all'))
        def _qf_canvas_resize(e):
            _qf_canvas.itemconfig(_qf_win, width=e.width)
        qf.bind('<Configure>', _qf_configure)
        _qf_canvas.bind('<Configure>', _qf_canvas_resize)

        def _qf_wheel(e, c=_qf_canvas):
            if e.num == 4:   c.yview_scroll(-1, 'units')
            elif e.num == 5: c.yview_scroll(1, 'units')
            else:            c.yview_scroll(int(-e.delta / 60), 'units')
        _qf_canvas.bind('<MouseWheel>', _qf_wheel)
        _qf_canvas.bind('<Button-4>',   _qf_wheel)
        _qf_canvas.bind('<Button-5>',   _qf_wheel)

        self._q_labels = {}
        for i, (key, label, hint) in enumerate([
            ('coverage',  'Coverage',    '% DB peaks matched'),
            ('cosine',    'Similarity',  'Cosine similarity (0–1)'),
            ('n_matched', 'Matched/RRI', 'peaks found / total · RRI'),
            ('j_obs',     'J / ΔJ',      'J obs vs DB (Hz) · right-drag to reselect'),
        ]):
            ttk.Label(qf, text=f"{label}:",
                      font=("Arial", 8, "bold")).grid(
                row=i, column=0, sticky=tk.W, padx=4, pady=1)
            vl = ttk.Label(qf, text="—", font=("Arial", 8))
            vl.grid(row=i, column=1, sticky=tk.W, padx=4)
            ind = tk.Label(qf, text="●", font=("Arial", 10), fg='#cccccc')
            ind.grid(row=i, column=2, padx=2)
            ttk.Label(qf, text=hint,
                      font=("Arial", 7), foreground='#666').grid(
                row=i, column=3, sticky=tk.W, padx=2)
            self._q_labels[key] = (vl, ind)

        # Reset button row inside quality card
        reset_row = ttk.Frame(qf)
        reset_row.grid(row=4, column=0, columnspan=4, sticky=tk.EW, pady=(4, 2))
        self._reset_btn = tk.Button(
            reset_row, text='↺ Reset peaks to original',
            font=('Arial', 8), fg='#cc5500', bg='#fff8f0',
            relief='groove', cursor='hand2', command=self._rc_reset)
        self._reset_btn.pack(side=tk.LEFT, padx=4)
        self._reset_modified_lbl = ttk.Label(
            reset_row, text='', font=('Arial', 7, 'italic'), foreground='#cc5500')
        self._reset_modified_lbl.pack(side=tk.LEFT)

        self._current_det_pk_mcr = None  # last det_pk with MCR

        # ── Right-click drag state (region selection in zoom view) ────────────
        self._rc_drag_start   = None   # xdata where right-drag started
        self._rc_span_patch   = None   # axvspan shown during drag
        self._current_dp      = None   # db_peak currently shown in zoom
        self._current_met_dp  = None   # met currently shown in zoom
        self._current_mp_ref  = None   # matched_peak ref currently shown
        self._orig_pred_lines = None   # backup taken on FIRST display of dp

        # ── Right-click drag canvas events ────────────────────────────────────
        self.plot_canvas.mpl_connect('button_press_event',   self._rc_press)
        self.plot_canvas.mpl_connect('button_release_event', self._rc_release)
        self.plot_canvas.mpl_connect('motion_notify_event',  self._rc_move)

    # ── Detectability & Overlap ───────────────────────────────────────────────

    def _compute_detectability(self):
        """
        For each matched peak, estimate its SNR from the observed spectrum and
        the relative proton count within the metabolite.  Peaks with expected
        SNR < 3.0 are marked  below_detection_limit = True  so they are
        excluded from overlap detection and shown as gray in the table.
        """
        ppm_arr  = self.ppm
        int_arr  = self.mean_intensity
        if ppm_arr is None or int_arr is None or len(ppm_arr) < 10:
            return

        # Noise estimate: MAD of the spectrum tail (far upfield, > 9.5 ppm)
        tail_mask = ppm_arr > 9.5
        if tail_mask.sum() < 20:
            # fall back: lowest 5th percentile of the whole spectrum
            noise = float(np.percentile(np.abs(int_arr), 5)) or 1.0
        else:
            tail = int_arr[tail_mask]
            noise = float(np.median(np.abs(tail - np.median(tail)))) * 1.4826 or 1.0
        if noise <= 0:
            noise = 1.0

        from collections import defaultdict
        by_metabolite = defaultdict(list)
        for met in self.metabolites:
            mid = met['id']
            for mp in met['matched_peaks']:
                by_metabolite[mid].append(mp)

        for mid, peaks in by_metabolite.items():
            # Compute observed SNR for each peak from the spectrum
            for mp in peaks:
                ppk = mp.get('peak_ppm', mp.get('db_ppm', 0))
                idx = int(np.argmin(np.abs(ppm_arr - ppk)))
                mp['obs_intensity'] = float(int_arr[idx])
                mp['obs_snr']       = mp['obs_intensity'] / noise

            # Anchor = peak with highest observed SNR
            anchor     = max(peaks, key=lambda p: p.get('obs_snr', 0))
            anchor_snr = anchor.get('obs_snr', 0)
            try:
                anchor_protons = int(anchor['db_peak'].get('protons', 1) or 1)
            except Exception:
                anchor_protons = int(anchor.get('protons', 1) or 1)

            for mp in peaks:
                try:
                    p_protons = int(mp['db_peak'].get('protons', 1) or 1)
                except Exception:
                    p_protons = int(mp.get('protons', 1) or 1)
                if anchor_protons > 0:
                    expected_snr = anchor_snr * (p_protons / anchor_protons)
                else:
                    expected_snr = anchor_snr
                mp['expected_snr']          = expected_snr
                mp['below_detection_limit'] = expected_snr < 3.0

    def _compute_overlap(self):
        """Build peak_rank → [metabolite names] map for the overlap column.
        BDL peaks are excluded — they are not considered real competitors."""
        peak_mets = {}
        for met in self.metabolites:
            for mp in met['matched_peaks']:
                if mp.get('below_detection_limit'):
                    continue
                rank = mp.get('peak_rank')
                if rank is not None:
                    peak_mets.setdefault(rank, []).append(met['name'])
        self._peak_overlap = peak_mets

    def _apply_resolve(self, peak_rank, chosen_met_id, quality_map):
        """
        Called after the user assigns a peak in PeakResolveWindow.
        Updates annotation_quality and assignment, then repopulates.
        """
        # Apply quality_map to all matching mp dicts
        for met in self.metabolites:
            mid = met['id']
            if mid not in quality_map:
                continue
            for mp2 in met['matched_peaks']:
                if mp2.get('peak_rank') == peak_rank:
                    mp2['annotation_quality'] = quality_map[mid]

        # Update assignment to the chosen metabolite
        chosen = next((m for m in self.metabolites if m['id'] == chosen_met_id), None)
        if chosen:
            mp = next((m for m in chosen['matched_peaks']
                       if m.get('peak_rank') == peak_rank), None)
            if mp:
                self._peak_assignments[peak_rank] = (chosen, mp)

        self._populate()

    @staticmethod
    def _is_mult_m(mp):
        t = (mp.get('type', '') or mp.get('multiplicity', '') or '').strip().lower()
        return t in ('m', 'multiplet')

    @staticmethod
    def _delta_j_hz(mp, field_mhz=600.0):
        """Return |J_obs - J_db| in Hz, or None if not applicable."""
        pl = mp.get('predicted_lines', [])
        if len(pl) < 2:
            return None
        ppms = sorted(p['ppm'] for p in pl)
        seps = [ppms[i+1] - ppms[i] for i in range(len(ppms)-1)]
        j_obs = sum(seps) / len(seps) * field_mhz
        j_raw = str(mp.get('j_coupling') or '').strip()
        if not j_raw:
            return None
        try:
            j_db = float(j_raw.split(',')[0].strip())
        except ValueError:
            return None
        return abs(j_obs - j_db)

    def _auto_mark_good(self):
        """
        Automatically mark as Good any matched peak whose rank is not
        claimed by any other metabolite (no overlap in _peak_overlap).
        Mark as Bad if delta-J > 0.5 Hz.
        Only sets quality when it hasn't been manually assigned yet.
        """
        for met in self.metabolites:
            for mp in met['matched_peaks']:
                if mp.get('annotation_quality') is not None:
                    continue   # respect manual assignment
                # Bad if J coupling mismatch > 0.5 Hz
                dj = self._delta_j_hz(mp)
                if dj is not None and dj > 0.5:
                    mp['annotation_quality'] = 'bad'
                    continue
                rank   = mp.get('peak_rank')
                others = [n for n in self._peak_overlap.get(rank, [])
                          if n != met['name']]
                if not others:
                    mp['annotation_quality'] = 'good'

    def _build_peak_assignments(self):
        """
        Build peak_rank → (met, mp) assignment enforcing 1-peak-1-metabolite.

        For each detected peak rank, all (met, mp) pairs that matched it become
        candidates. The default assignment is the highest composite_score.
        If a match is already manually marked 'good', it takes priority.
        """
        all_cands = {}  # rank → [(score, met, mp)]
        for met in self.metabolites:
            for mp in met['matched_peaks']:
                rank = mp.get('peak_rank')
                if rank is None:
                    continue
                score = float(
                    mp.get('composite_score',
                           mp.get('multiplet_score', 0.0)) or 0.0)
                all_cands.setdefault(rank, []).append((score, met, mp))

        self._peak_candidates = {}   # rank → [(score, met, mp)] sorted desc
        self._peak_assignments = {}  # rank → (met, mp)

        for rank, cands in all_cands.items():
            cands.sort(key=lambda x: x[0], reverse=True)
            self._peak_candidates[rank] = cands
            # Prefer a manually-assigned 'good' match, otherwise take best score
            manual = next(
                ((m, mp2) for _, m, mp2 in cands
                 if mp2.get('annotation_quality') == 'good'),
                None)
            self._peak_assignments[rank] = manual if manual else (
                cands[0][1], cands[0][2])

    def _classify(self, quality):
        """Mark the selected row as Good / Bad / Undefined (Ctrl+1/2/3)."""
        sel = self.tree.selection()
        if not sel:
            return
        iid = sel[0]
        if iid in self._iid_to_row:
            self._classify_one(iid, quality)
        elif iid in self._iid_to_child:
            self._classify_child(iid, quality)

    def _classify_one(self, iid, quality):
        """Classify a parent peak-assignment row (Good/Bad/None=Undefined)."""
        rank, met, mp, det_pk = self._iid_to_row[iid]
        mp['annotation_quality'] = quality

        # Persist mark so it survives window close/reopen
        ann = (getattr(self.app, 'stages', {}) or {}).get('annotation')
        if ann is not None:
            if not hasattr(ann, '_quality_marks') or ann._quality_marks is None:
                ann._quality_marks = {}
            key = (met['id'], mp.get('peak_rank'))
            if quality:
                ann._quality_marks[key] = quality
            else:
                ann._quality_marks.pop(key, None)
            # Mark project dirty
            pm = getattr(self.app, 'project_manager', None)
            if pm is not None:
                pm.mark_dirty()

        # If marked Good, promote this metabolite as the assignment for this peak
        if quality == 'good':
            self._peak_assignments[rank] = (met, mp)

        if quality == 'good':
            qual_mark = '✓ Good'
        elif quality == 'bad':
            qual_mark = '✗ Bad'
        else:
            qual_mark = '—'
        score = float(mp.get('composite_score', mp.get('multiplet_score', 0.0)) or 0.0)
        tag = 'met_high' if score >= 0.7 else 'met_mid' if score >= 0.4 else 'met_low'
        if quality == 'good':
            tags = (tag, 'qual_good')
        elif quality == 'bad':
            tags = (tag, 'qual_bad')
        else:
            tags = (tag,)
        cur = list(self.tree.item(iid, 'values'))
        cur[5] = qual_mark
        self.tree.item(iid, values=cur, tags=tags)

    def _classify_child(self, ciid, quality):
        """Classify a child DB-peak row (Good/Bad/None=Undefined)."""
        met, dp = self._iid_to_child[ciid]
        dp_ppm  = float(dp.get('ppm_center', dp.get('ppm', 0)))
        key     = (met['id'], round(dp_ppm, 3))

        ann = (getattr(self.app, 'stages', {}) or {}).get('annotation')
        if ann is not None:
            if not hasattr(ann, '_child_quality_marks') or ann._child_quality_marks is None:
                ann._child_quality_marks = {}
            if quality:
                ann._child_quality_marks[key] = quality
            else:
                ann._child_quality_marks.pop(key, None)
            pm = getattr(self.app, 'project_manager', None)
            if pm is not None:
                pm.mark_dirty()

        if quality == 'good':
            tags = ('peak_match', 'qual_good')
        elif quality == 'bad':
            tags = ('peak_match', 'qual_bad')
        else:
            # Revert to automatic colouring based on match/overlap
            mp_ref  = next(
                (mp2 for mp2 in met['matched_peaks']
                 if round(float(mp2.get('db_ppm', 0)), 3) == round(dp_ppm, 3)),
                None)
            is_matched  = mp_ref is not None
            child_pk    = mp_ref.get('peak_rank') if mp_ref else None
            n_cands     = len(self._peak_candidates.get(child_pk, [])) if child_pk else 0
            if is_matched and n_cands > 1:
                tags = ('peak_match', 'qual_mid')
            elif is_matched:
                tags = ('peak_match', 'qual_good')
            else:
                tags = ('peak_match', 'qual_bad')

        if quality == 'good':
            match_mark = '✓ Good'
        elif quality == 'bad':
            match_mark = '✗ Bad'
        else:
            match_mark = '✓' if tags[1] != 'qual_bad' else '✗'

        cur = list(self.tree.item(ciid, 'values'))
        cur[5] = match_mark
        self.tree.item(ciid, values=cur, tags=tags)

    def _on_tree_close(self, event):
        """When a parent row is collapsed, refresh its score in the treeview."""
        iid = self.tree.focus()
        if iid not in self._iid_to_row:
            return
        rank, met, mp, det_pk = self._iid_to_row[iid]
        # Recalculate composite score from only Good child peaks
        ann = (getattr(self.app, 'stages', {}) or {}).get('annotation')
        cqm = getattr(ann, '_child_quality_marks', {}) if ann else {}
        good_children = [
            dp for dp in met.get('db_peaks', [])
            if cqm.get((met['id'], round(float(dp.get('ppm_center', dp.get('ppm', 0))), 3)))
               == 'good'
        ]
        if good_children:
            n_good    = len(good_children)
            n_db      = max(len(met.get('db_peaks', [])), 1)
            coverage  = n_good / n_db
            new_score = float(mp.get('composite_score',
                                     mp.get('multiplet_score', 0.0)) or 0.0)
            # Blend original score with coverage of Good peaks
            new_score = new_score * 0.6 + coverage * 0.4
            mp['composite_score'] = new_score
            tag = 'met_high' if new_score >= 0.7 else 'met_mid' if new_score >= 0.4 else 'met_low'
            qual = mp.get('annotation_quality')
            tags = (tag, 'qual_good') if qual == 'good' else (tag, 'qual_bad') if qual == 'bad' else (tag,)
            cur = list(self.tree.item(iid, 'values'))
            cur[4] = f'{new_score:.3f}'
            self.tree.item(iid, values=cur, tags=tags)

    # ── Table ─────────────────────────────────────────────────────────────────

    def _sort_by(self, key):
        """Toggle sort on the peak assignments list and repopulate."""
        cur = getattr(self, '_sort_key', None)
        rev = getattr(self, '_sort_rev', True)
        self._sort_rev = not rev if cur == key else True
        self._sort_key = key
        self._populate()

    def _on_right_click(self, event):
        """Right-click on a peak-assignment row → candidates / Peak List / Deconv."""
        iid = self.tree.identify_row(event.y)
        if not iid:
            return

        # ── Parent row (peak assignment) ──────────────────────────────────────
        if iid in self._iid_to_row:
            rank, met, mp, det_pk = self._iid_to_row[iid]
            peak_ppm = float(mp.get('peak_ppm', 0))
            cands_raw = self._peak_candidates.get(rank, [])
            candidates = [(m, mp2) for _, m, mp2 in cands_raw]

            def _open_peak_list():
                app = getattr(self, 'app', None)
                if not app: return
                stage = getattr(app, 'stages', {}).get('peak_detection')
                if not stage: return
                try:
                    from gui.widgets.peak_list_window import PeakListWindow
                    win = PeakListWindow(
                        app.root, stage.peaks,
                        app.ppm, app.all_intensities, app=app)
                    if hasattr(win, 'scroll_to_rank'):
                        win.scroll_to_rank(rank)
                except Exception as e:
                    print(f'Peak List nav: {e}')

            def _open_deconv():
                app = getattr(self, 'app', None)
                if not app: return
                stage = getattr(app, 'stages', {}).get('peak_detection')
                if not stage: return
                try:
                    peak = next(
                        (p for p in stage.peaks if p.get('rank') == rank), None)
                    if peak is None:
                        peak = min(stage.peaks,
                                   key=lambda p: abs(p['ppm'] - peak_ppm),
                                   default=None)
                    if peak is None:
                        return
                    from gui.notation.deconvolution import (
                        DeconvController, DeconvWindow)
                    if (stage._deconv_controller is None
                            or stage._deconv_controller.processor
                            is not stage.processor):
                        stage._deconv_controller = DeconvController(
                            stage.processor)
                        if stage._overlaps:
                            stage._deconv_controller.set_regions(
                                stage._overlaps)
                    ctrl = stage._deconv_controller
                    region_idx, child_idx = ctrl.add_peak(
                        peak, target_ppm=peak['ppm'])
                    app.switch_stage('peak_detection')
                    stage.btn_open_deconv.config(state='normal')
                    dw = DeconvWindow(app.root, ctrl, stage)
                    dw.select_region(region_idx, child_idx)
                except Exception as e:
                    import traceback; traceback.print_exc()
                    print(f'Deconv nav: {e}')

            def _open_resolve():
                from gui.widgets.peak_resolve_window import PeakResolveWindow
                PeakResolveWindow(
                    self.win,
                    candidates=candidates,
                    peak_rank=rank,
                    peak_ppm=peak_ppm,
                    ppm=self.ppm,
                    mean_intensity=self.mean_intensity,
                    on_assign=lambda chosen_id, qmap: self._apply_resolve(
                        rank, chosen_id, qmap),
                    peaks_list=self.peaks)

            menu = tk.Menu(self.win, tearoff=0)
            menu.add_command(
                label=f'📋 Open Peak #{rank} in Peak List',
                command=_open_peak_list)
            menu.add_command(
                label=f'🧅 Send Peak #{rank} to Deconvolution Tool',
                command=_open_deconv)
            menu.add_separator()
            menu.add_command(
                label=f'🔀 View Candidates  ({len(candidates)} metabolites)',
                command=_open_resolve)
            menu.add_separator()
            menu.add_command(
                label=f'PPM {peak_ppm:.4f}  ·  {met["name"]}',
                state='disabled')
            try:
                menu.tk_popup(event.x_root, event.y_root)
            finally:
                menu.grab_release()

        # ── Child row (DB peak) ───────────────────────────────────────────────
        elif iid in self._iid_to_child:
            met, dp = self._iid_to_child[iid]
            dp_ppm = float(dp.get('ppm_center', dp.get('ppm', 0)))
            menu = tk.Menu(self.win, tearoff=0)
            menu.add_command(
                label=f'DB peak @ {dp_ppm:.4f} ppm  [{dp.get("type","?")}]',
                state='disabled')
            try:
                menu.tk_popup(event.x_root, event.y_root)
            finally:
                menu.grab_release()

    def _populate(self):
        self.tree.delete(*self.tree.get_children(''))

        # Name filter
        name_q = getattr(self, '_flt_name', None)
        q = name_q.get().lower() if name_q else ''

        # Quality filter
        show_good   = getattr(self, '_ann_filt_good',   None)
        show_bad    = getattr(self, '_ann_filt_bad',    None)
        show_undef  = getattr(self, '_ann_filt_undef',  None)
        show_bdl    = getattr(self, '_ann_filt_bdl',    None)
        show_good   = show_good.get()   if show_good   else True
        show_bad    = show_bad.get()    if show_bad    else True
        show_undef  = show_undef.get()  if show_undef  else True
        show_bdl    = show_bdl.get()    if show_bdl    else True
        show_mult_m = False  # 'm' multiplets permanently excluded

        def _is_mult_m(mp):
            t = (mp.get('type', '') or mp.get('multiplicity', '') or '').strip().lower()
            return t in ('m', 'multiplet')

        def _qual_visible(mp):
            # Filter out 'm' (multiplet without J) unless explicitly shown
            if _is_mult_m(mp) and not show_mult_m:
                return False
            if mp.get('below_detection_limit'):
                return show_bdl
            qual = mp.get('annotation_quality')
            if qual == 'good':  return show_good
            if qual == 'bad':   return show_bad
            return show_undef   # None / undefined

        def _met_visible(met):
            """Hide metabolite entirely if ALL its matched peaks are 'm' and filter is off."""
            if show_mult_m:
                return True
            non_m = [mp2 for mp2 in met['matched_peaks'] if not _is_mult_m(mp2)]
            return len(non_m) > 0

        ranks = [r for r, (m, mp) in self._peak_assignments.items()
                 if (not q or q in m['name'].lower())
                 and _qual_visible(mp)
                 and _met_visible(m)]

        # Sort
        sk  = getattr(self, '_sort_key', 'ppm')
        rev = getattr(self, '_sort_rev', True)
        if sk == 'name':
            ranks.sort(
                key=lambda r: self._peak_assignments[r][0]['name'].lower(),
                reverse=not rev)
        elif sk == 'score':
            ranks.sort(
                key=lambda r: float(
                    self._peak_assignments[r][1].get(
                        'composite_score', 0) or 0),
                reverse=rev)
        else:  # ppm / default
            ranks.sort(
                key=lambda r: float(
                    self._peak_assignments[r][1].get('peak_ppm', 0) or 0),
                reverse=rev)

        # Update summary label
        n_assigned = len(self._peak_assignments)
        lbl = getattr(self, '_summary_lbl', None)
        if lbl:
            lbl.config(
                text=f"{len(ranks)}/{n_assigned} peaks assigned  ·  "
                     f"{len(self.metabolites)} metabolites")

        self._iid_to_row   = {}
        self._iid_to_child = {}

        for ri, rank in enumerate(ranks):
            met, mp = self._peak_assignments[rank]

            # Look up the detected peak for start/end ppm
            det_pk = next((p for p in self.peaks if p.get('rank') == rank), None)
            peak_ppm = float(mp.get('peak_ppm', 0))
            if det_pk:
                start_ppm = float(det_pk.get('start_ppm', peak_ppm + 0.01))
                end_ppm   = float(det_pk.get('end_ppm',   peak_ppm - 0.01))
            else:
                start_ppm = peak_ppm + 0.01
                end_ppm   = peak_ppm - 0.01

            score = float(
                mp.get('composite_score', mp.get('multiplet_score', 0.0)) or 0.0)
            qual      = mp.get('annotation_quality')
            is_bdl    = mp.get('below_detection_limit', False)
            if is_bdl:
                qual_mark = f"⬇ BDL"
            else:
                qual_mark = '✓ Good' if qual == 'good' else '✗ Bad' if qual == 'bad' else '—'

            n_other  = len(self._peak_candidates.get(rank, [])) - 1
            ovlp_str = f"⚠ {n_other}" if n_other > 0 else '—'

            tag  = ('met_high' if score >= 0.7
                    else 'met_mid' if score >= 0.4 else 'met_low')
            if is_bdl:
                tags = (tag, 'qual_bdl')
            else:
                tags = (tag, 'qual_good') if qual == 'good' else \
                       (tag, 'qual_bad')  if qual == 'bad'  else (tag,)

            piid = f"pk{ri}"
            self._iid_to_row[piid] = (rank, met, mp, det_pk)

            try:
                self.tree.insert(
                    '', tk.END, iid=piid,
                    text=f"Peak #{rank}",
                    values=(
                        met['name'],
                        f"{peak_ppm:.4f}",
                        f"{start_ppm:.4f}",
                        f"{end_ppm:.4f}",
                        f"{score:.3f}",
                        qual_mark,
                        ovlp_str),
                    tags=tags,
                    open=False)
            except Exception as e:
                print(f"Tree insert error for peak #{rank}: {e}")
                continue

            # Build lookups for child rows
            # db_ppm (rounded) → matched_peak dict
            matched_mp_by_dbppm = {round(float(mp2.get('db_ppm', 0)), 3): mp2
                                   for mp2 in met['matched_peaks']}
            matched_db_ppms = set(matched_mp_by_dbppm.keys())

            # Load persisted child quality marks for this metabolite
            ann     = (getattr(self.app, 'stages', {}) or {}).get('annotation')
            cqm     = getattr(ann, '_child_quality_marks', {}) if ann else {}

            # Children: DB peaks of the assigned metabolite
            for ci, dp in enumerate(sorted(
                    met['db_peaks'],
                    key=lambda p: p.get('ppm_center', p.get('ppm', 0)),
                    reverse=True)):
                ciid    = f"dp{ri}_{ci}"
                dp_ppm  = float(dp.get('ppm_center', dp.get('ppm', 0)))
                dp_type = dp.get('type', '?') or '?'
                try:
                    protons_str = f"  {int(dp.get('protons') or 0)}H"
                except (ValueError, TypeError):
                    protons_str = f"  {dp.get('protons','')}" if dp.get('protons') else ''
                dp_start = float(dp.get('ppm_start', dp_ppm))
                dp_end   = float(dp.get('ppm_end',   dp_ppm))

                # ── Match status ───────────────────────────────────────────────
                dp_key     = round(dp_ppm, 3)
                is_matched = dp_key in matched_db_ppms
                match_mark = '✓' if is_matched else '✗'

                # ── Overlap: how many other metabolites claim this exp. peak ───
                mp_ref_child  = matched_mp_by_dbppm.get(dp_key)
                child_pk_rank = mp_ref_child.get('peak_rank') if mp_ref_child else None
                if child_pk_rank is not None:
                    n_cands = len(self._peak_candidates.get(child_pk_rank, []))
                    child_ovlp = f"⚠ {n_cands}" if n_cands > 1 else '—'
                else:
                    child_ovlp = '—'

                # ── Apply persisted child quality mark (overrides auto-colour) ─
                child_saved_quality = cqm.get((met['id'], dp_key))
                if child_saved_quality == 'good':
                    child_tags = ('peak_match', 'qual_good')
                    match_mark = '✓ Good'
                elif child_saved_quality == 'bad':
                    child_tags = ('peak_match', 'qual_bad')
                    match_mark = '✗ Bad'
                else:
                    # Auto-colour: green/yellow/red based on match + overlap
                    if is_matched and child_ovlp != '—':
                        child_tags = ('peak_match', 'qual_mid')
                    elif is_matched:
                        child_tags = ('peak_match', 'qual_good')
                    else:
                        child_tags = ('peak_match', 'qual_bad')

                self._iid_to_child[ciid] = (met, dp)
                try:
                    self.tree.insert(
                        piid, tk.END, iid=ciid,
                        text=f"  ↳ {dp_ppm:.4f}",
                        values=(
                            f"{dp_type}{protons_str}",
                            f"{dp_ppm:.4f}",
                            f"{dp_start:.4f}",
                            f"{dp_end:.4f}",
                            '',
                            match_mark,
                            child_ovlp),
                        tags=child_tags)
                except Exception as e:
                    print(f"  child insert error: {e}")

        # Select first row
        children = self.tree.get_children('')
        if children:
            self.tree.selection_set(children[0])
            self.tree.focus(children[0])
            self._on_select()

    # ── Plot ──────────────────────────────────────────────────────────────────

    def _on_select(self, event=None):
        sel = self.tree.selection()
        if not sel:
            return
        iid = sel[0]

        if iid in self._iid_to_row:
            # Parent row: full metabolite fingerprint
            rank, met, mp, det_pk = self._iid_to_row[iid]
            self._current_met = met
            self._plot_fingerprint(met)

        elif iid in self._iid_to_child:
            # Child row: zoom into this specific DB peak inside the fingerprint panel
            met, dp = self._iid_to_child[iid]
            self._current_met = met
            self._plot_db_peak_zoom(met, dp)

    # ── DB-peak zoom ──────────────────────────────────────────────────────────

    def _plot_db_peak_zoom(self, met, dp):
        """
        Zoom the fingerprint comparison panel to a single DB peak (multiplet).

        Shows:
          • Grey fill + dark line  = experimental spectrum in the region
          • Green sticks + shape   = DB peak that was MATCHED in the experiment
          • Red   sticks + shape   = DB peak NOT FOUND in the experiment
          • Orange Δppm arrow      = shift between DB centre and observed centre
          • Yellow/green highlight = region of the multiplet
        """
        # Track current context for right-click drag region selection.
        # Backup predicted_lines ONCE when switching to a new db_peak,
        # so reset always returns to the state at first display.
        if dp is not self._current_dp:
            # Save original for the peak we're leaving (if any)
            self._orig_pred_lines = None
            self._show_reset_btn(False)
        self._current_dp     = dp
        self._current_met_dp = met

        self.ax.clear()

        dp_ppm  = float(dp.get('ppm_center', dp.get('ppm', 0)))
        dp_type = (dp.get('type', 's') or 's').strip()

        # ── Is this DB peak matched? ───────────────────────────────────────────
        matched_db_ppms = {round(float(mp.get('db_ppm', 0)), 3)
                           for mp in met['matched_peaks']}
        is_matched = round(dp_ppm, 3) in matched_db_ppms
        mp_ref = next((mp for mp in met['matched_peaks']
                       if round(float(mp.get('db_ppm', 0)), 3) == round(dp_ppm, 3)),
                      None)
        self._current_mp_ref = mp_ref
        # Take the backup exactly once — on the first call for this dp.
        # _orig_pred_lines is cleared when dp changes (above).
        if self._orig_pred_lines is None and mp_ref is not None:
            self._orig_pred_lines = list(mp_ref.get('predicted_lines') or [])

        # ── Overlap: how many metabolites claim the same exp. peak ─────────────
        child_pk_rank = mp_ref.get('peak_rank') if mp_ref else None
        overlap_cands = self._peak_candidates.get(child_pk_rank, []) \
                        if child_pk_rank is not None else []
        n_overlap  = max(0, len(overlap_cands) - 1)   # exclude self
        ovlp_names = [m.get('name', '?')
                      for _, m, _ in overlap_cands
                      if m.get('name') != met['name']]

        # ── Centre on experimental position if matched, else on DB ppm ──────────
        if mp_ref:
            centre = float(mp_ref.get('peak_ppm', dp_ppm))
            offset = centre - dp_ppm
        else:
            centre = dp_ppm
            offset = 0.0

        # ── Determine matched sticks FIRST so the window can be built around them
        # Prefer predicted_lines (actual observed positions from the match).
        db_width = max(
            abs(dp.get('ppm_end', dp_ppm) - dp.get('ppm_start', dp_ppm)), 0.002)
        sticks   = dp.get('sticks') or [(dp_ppm, 1.0)]
        if mp_ref and mp_ref.get('predicted_lines'):
            plot_sticks = [(l['ppm'], l['rel_intensity'])
                           for l in mp_ref['predicted_lines']]
        else:
            plot_sticks = [(sp + offset, si) for sp, si in sticks]

        # Window is derived from the ACTUAL matched stick span, not DB metadata.
        # This prevents an overly wide window that includes unrelated signals.
        stick_ppms_plot = [s[0] for s in plot_sticks]
        stick_span_plot = (max(stick_ppms_plot) - min(stick_ppms_plot)
                           ) if len(plot_sticks) > 1 else 0.0
        half_win = max(stick_span_plot * 2.5 + 0.012, 0.025)
        hwhm     = max(stick_span_plot / 6 if stick_span_plot > 0
                       else db_width / 2, 0.001)

        lo = centre - half_win
        hi = centre + half_win

        # ── Experimental spectrum ──────────────────────────────────────────────
        mask  = (self.ppm >= lo) & (self.ppm <= hi)
        x_exp = self.ppm[mask]
        y_exp = self.mean_intensity[mask].copy()
        y_norm = np.zeros_like(y_exp)          # always defined
        if len(x_exp) >= 4 and y_exp.max() > 0:
            # Local linear baseline: removes broad underlying signals so only
            # the sharp multiplet lines are visible in the zoomed panel.
            y_exp = np.maximum(y_exp - _local_linear_baseline(y_exp), 0.0)

            # Normalise by the maximum WITHIN the doublet/multiplet region,
            # not by the global window max. This prevents an adjacent unrelated
            # peak from compressing the matched doublet lines to look tiny.
            s_lo = min(stick_ppms_plot) - hwhm * 4
            s_hi = max(stick_ppms_plot) + hwhm * 4
            doublet_mask = (x_exp >= s_lo) & (x_exp <= s_hi)
            ref_max = (float(y_exp[doublet_mask].max())
                       if doublet_mask.any() and y_exp[doublet_mask].max() > 0
                       else float(y_exp.max()))
            ref_max = max(ref_max, 1e-10)
            y_norm  = y_exp / ref_max

            self.ax.fill_between(x_exp, 0, y_norm,
                                 color='#aaaaaa', alpha=0.30, zorder=1)
            self.ax.plot(x_exp, y_norm,
                         color='#1a1a6e', linewidth=1.2, zorder=2,
                         label='Experimental')

        # ── DB multiplet simulated shape ───────────────────────────────────────
        x_db = np.linspace(lo, hi, 600)
        y_db = np.zeros_like(x_db)
        for st_ppm, st_rel in plot_sticks:
            y_db += st_rel * hwhm**2 / ((x_db - st_ppm)**2 + hwhm**2)
        if y_db.max() > 0:
            y_db /= y_db.max()

        db_color = '#1a7a1a' if is_matched else '#cc2200'
        db_fill  = '#44bb44' if is_matched else '#ee4444'
        lbl      = 'DB matched' if is_matched else 'DB — not found'
        self.ax.fill_between(x_db, 0, y_db,
                             color=db_fill, alpha=0.22, zorder=3)
        self.ax.plot(x_db, y_db,
                     color=db_color, linewidth=1.5, linestyle='--',
                     zorder=4, label=lbl)

        # Individual sticks (highlight the multiplet lines)
        for st_ppm, st_rel in plot_sticks:
            self.ax.plot([st_ppm, st_ppm], [0, st_rel * 0.95],
                         color=db_color, linewidth=2.2, alpha=0.85, zorder=5)
            self.ax.scatter([st_ppm], [st_rel * 0.95],
                            color=db_color, s=45, zorder=6)

        # ── Highlight span around the multiplet ───────────────────────────────
        span_lo = min(s[0] for s in plot_sticks) - hwhm * 2.5
        span_hi = max(s[0] for s in plot_sticks) + hwhm * 2.5
        span_color = '#00cc44' if is_matched else '#ffaa00'
        self.ax.axvspan(span_hi, span_lo,   # NMR inverted axis
                        alpha=0.07, color=span_color, zorder=0)

        # ── Mark matched experimental peaks + J coupling annotation ───────────
        if is_matched and len(plot_sticks) >= 1 and len(x_exp) > 0:
            # Orange ▼ markers ON the experimental spectrum at each matched line.
            # Placed at the actual spectrum height so the user sees exactly which
            # detected peaks the algorithm identified as the multiplet lines.
            for st_ppm, _ in plot_sticks:
                idx = int(np.argmin(np.abs(x_exp - st_ppm)))
                h   = float(y_norm[idx])
                self.ax.plot([st_ppm], [h + 0.04], 'v',
                             color='#cc5500', ms=8, zorder=9,
                             alpha=0.90, markeredgewidth=0)

            # J coupling values → sent to quality card, not drawn on the plot
            if len(plot_sticks) >= 2:
                try:
                    ann_stage = (getattr(self.app, 'stages', {}) or {}).get('annotation')
                    mhz_plot  = float(ann_stage.spectrometer_var.get()) \
                                if (ann_stage and hasattr(ann_stage, 'spectrometer_var')) \
                                else 600.0
                except Exception:
                    mhz_plot = 600.0

                sorted_s     = sorted(plot_sticks, key=lambda s: s[0])
                obs_seps_ppm = [abs(sorted_s[i+1][0] - sorted_s[i][0])
                                for i in range(len(sorted_s) - 1)]
                j_obs_hz     = [sep * mhz_plot for sep in obs_seps_ppm]
                j_obs_str    = ' / '.join(f'{j:.1f}' for j in j_obs_hz)

                db_j_raw = str(dp.get('j_coupling') or '').strip()
                import re as _re2
                _j_db_nums = ([float(x) for x in _re2.findall(r'\d+\.?\d*', db_j_raw)
                               if float(x) > 0] if db_j_raw else [])

                if _j_db_nums:
                    # ΔJ = mean |J_obs_i - J_db_i|, paired by order
                    n_pairs = min(len(j_obs_hz), len(_j_db_nums))
                    dj_vals = [abs(j_obs_hz[i] - _j_db_nums[i]) for i in range(n_pairs)]
                    dj_mean = sum(dj_vals) / len(dj_vals)
                    j_card  = (f'obs {j_obs_str} Hz  /  db {db_j_raw} Hz'
                               f'  —  ΔJ {dj_mean:.2f} Hz')
                    j_color = ('#1a7a1a' if dj_mean < 1.0 else
                               '#7a6000' if dj_mean < 3.0 else '#9a0000')
                else:
                    j_card  = f'obs {j_obs_str} Hz  (no DB J)'
                    j_color = '#7a6000'

                self._set_q('j_obs', j_card, j_color)
                # Also add small J annotation on plot — just the obs value, compact
                self.ax.text(0.02, 0.04,
                             f'J = {j_obs_str} Hz',
                             transform=self.ax.transAxes,
                             fontsize=7, color='#cc5500', va='bottom',
                             bbox=dict(boxstyle='round,pad=0.2',
                                       facecolor='white', edgecolor='#cc5500',
                                       alpha=0.70))

        # ── Δppm arrow if matched and shift is visible ─────────────────────────
        if mp_ref and abs(offset) > 0.0002:
            ppm_diff = float(mp_ref.get('ppm_diff', abs(offset)))
            # Set xlim first so transLimits is valid for coordinate conversion
            self.ax.set_xlim(hi + half_win * 0.05, lo - half_win * 0.05)
            # Convert data ppm → axes-fraction so arrow sits above the data
            # regardless of whether unrelated peaks go above 1.0.
            x_lo_lim, x_hi_lim = self.ax.get_xlim()
            def _ppm_to_ax(ppm):
                return (ppm - x_lo_lim) / (x_hi_lim - x_lo_lim)
            x_exp_ax = _ppm_to_ax(centre)
            x_db_ax  = _ppm_to_ax(dp_ppm)
            y_arr_ax = 0.92
            self.ax.annotate(
                '', xy=(x_exp_ax, y_arr_ax), xytext=(x_db_ax, y_arr_ax),
                xycoords='axes fraction', textcoords='axes fraction',
                arrowprops=dict(arrowstyle='<->', color='#cc5500', lw=1.2))
            self.ax.text((x_exp_ax + x_db_ax) / 2, y_arr_ax + 0.05,
                         f'Δ {ppm_diff:.4f} ppm',
                         transform=self.ax.transAxes,
                         ha='center', fontsize=8, color='#cc5500')

        # ── Axes ──────────────────────────────────────────────────────────────
        # xlim may already be set by the arrow block — set it unconditionally.
        self.ax.set_xlim(hi + half_win * 0.05, lo - half_win * 0.05)
        # Y-axis: doublet normalised to ~1.0; adjacent unrelated peaks may
        # exceed 1.0 (normalised by doublet-region max, not window max).
        try:
            y_top = max(
                1.15,
                *(float(l.get_ydata().max())
                  for l in self.ax.lines if len(l.get_ydata()) > 0))
        except Exception:
            y_top = 1.30
        self.ax.set_ylim(-0.06, min(y_top * 1.05, 2.5))
        self.ax.set_xlabel('δ (ppm)', fontsize=9)
        self.ax.set_ylabel('Intensity (normalised)', fontsize=8)
        if is_matched:
            match_str = '✓ Matched'
            title_col = '#1a7a1a'
        else:
            match_str = '✗ Not found in spectrum'
            title_col = '#cc2200'
        self.ax.set_title(
            f"{met['name']}  ·  {dp_ppm:.4f} ppm  [{dp_type.upper()}]  "
            f"{match_str}",
            fontsize=9, fontweight='bold', color=title_col)
        self.ax.legend(loc='upper right', fontsize=7)
        self.ax.tick_params(labelsize=8)
        self.ax.grid(True, alpha=0.2, linestyle=':')
        self.ax.set_facecolor('#fafafa')
        self.fig.tight_layout()
        self.plot_canvas.draw_idle()

        # ── Quality card ──────────────────────────────────────────────────────
        self._set_q('coverage',
                    f"DB: {dp_ppm:.4f} ppm  [{dp_type.upper()}]",
                    '#1a7a1a' if is_matched else '#9a0000')
        if mp_ref:
            ppm_diff = float(mp_ref.get('ppm_diff', abs(offset)))
            self._set_q('cosine',
                        f"Δ = {ppm_diff:.4f} ppm",
                        '#1a7a1a' if ppm_diff < 0.005 else
                        '#7a6000' if ppm_diff < 0.02 else '#9a0000')
        else:
            self._set_q('cosine', 'No experimental match', '#9a0000')
        n_sticks = len(plot_sticks)
        ovlp_card = f"  ⚠ {n_overlap} competing metabolite(s)" if n_overlap > 0 else ''
        self._set_q('n_matched',
                    f"{n_sticks} line(s)  ·  "
                    f"{'✓ matched' if is_matched else '✗ missing'}{ovlp_card}",
                    '#8B6914' if (is_matched and n_overlap > 0)
                    else '#1a7a1a' if is_matched else '#9a0000')
        # J quality card: populated by the J block above when n_sticks≥2,
        # cleared here when the peak is a singlet or unmatched.
        if n_sticks < 2 or not is_matched:
            self._set_q('j_obs',
                        '— singlet' if n_sticks < 2 else '— not matched',
                        '#888888')
        # Modified indicator
        is_modified = (self._orig_pred_lines is not None and
                       mp_ref is not None and
                       mp_ref.get('predicted_lines') != self._orig_pred_lines)
        self._show_reset_btn(is_modified)

        info_ovlp = f"  ⚠ overlap: {', '.join(ovlp_names[:2])}" if ovlp_names else ''
        self.match_info.config(
            text=f"{met['name']}  ·  {dp_ppm:.4f} ppm  [{dp_type.upper()}]  "
                 f"{'— MATCHED' if is_matched else '— NOT FOUND'}{info_ovlp}")

    def _plot_fingerprint(self, met):
        # Switching to fingerprint view — clear per-peak zoom state
        self._current_dp      = None
        self._current_met_dp  = None
        self._current_mp_ref  = None
        self._orig_pred_lines = None
        self._show_reset_btn(False)
        self._set_q('j_obs', '— select a DB peak row', '#888888')

        self.ax.clear()

        db_peaks = met['db_peaks']
        if not db_peaks:
            self.ax.text(0.5, 0.5, "No DB fingerprint available",
                         transform=self.ax.transAxes,
                         ha='center', va='center', color='gray')
            self.plot_canvas.draw_idle()
            return

        # ── Determine ppm window ──────────────────────────────────────────────
        db_ppms = [p.get('ppm_center', p.get('ppm', 0)) for p in db_peaks]
        # Include predicted_lines positions in span
        all_ppms = list(db_ppms)
        for _mp in met['matched_peaks']:
            for _l in _mp.get('predicted_lines', []):
                all_ppms.append(_l['ppm'])
        span_lo = min(all_ppms) - 0.08
        span_hi = max(all_ppms) + 0.08

        # ── Experimental signal — only plot segments around matched peaks ──────
        # Each matched peak contributes a small slice (±3×fwhm or ±0.03 ppm).
        # Gaps between peaks are left empty so the plot shows only the
        # analyte signals, not the whole spectrum.
        exp_peak_ppms = [mp['peak_ppm'] for mp in met['matched_peaks']]
        y_global_max  = 1.0
        y_segments    = []   # collect for computing global max

        # Compute window covering all predicted lines for this matched peak
        for mp in met['matched_peaks']:
            pred_l = mp.get('predicted_lines', [])
            if pred_l:
                ppms_l = [l['ppm'] for l in pred_l]
                ep_lo  = min(ppms_l)
                ep_hi  = max(ppms_l)
            else:
                ep_lo = ep_hi = mp['peak_ppm']
            det_pk = next((p for p in self.peaks
                           if p.get('rank') == mp.get('peak_rank')), None)
            # Fallback: find by ppm if rank changed after merge
            if det_pk is None and self.peaks:
                det_pk = min(self.peaks,
                             key=lambda p: abs(p['ppm'] - mp['peak_ppm']))
                if abs(det_pk['ppm'] - mp['peak_ppm']) > 0.05:
                    det_pk = None
            fwhm   = det_pk.get('width_at_half', det_pk.get('width_ppm', 0.004))
            if fwhm is None or fwhm <= 0: fwhm = 0.004
            win    = max(fwhm * 6, (ep_hi - ep_lo) + 0.02)
            centre = (ep_lo + ep_hi) / 2
            mask   = (self.ppm >= centre - win) & (self.ppm <= centre + win)
            x_seg  = self.ppm[mask]
            # Per-group per-sample segments — apply local baseline correction
            # so that peaks sitting on a broad hump are shown at their true height.
            if len(x_seg) >= 2:
                y_mean_seg = self.mean_intensity[mask].copy()
                bl_mean    = _local_linear_baseline(y_mean_seg)
                y_mean_seg = np.maximum(y_mean_seg - bl_mean, 0.0)
                if (self.all_intensities is not None
                        and self.all_intensities.ndim == 2):
                    y_all_seg = self.all_intensities[mask, :].copy()
                    for _k in range(y_all_seg.shape[1]):
                        bl_k = _local_linear_baseline(y_all_seg[:, _k])
                        y_all_seg[:, _k] = np.maximum(y_all_seg[:, _k] - bl_k, 0.0)
                    y_segments.append((x_seg, y_mean_seg, y_all_seg))
                else:
                    y_segments.append((x_seg, y_mean_seg, None))

        if y_segments:
            y_global_max = max(float(np.max(ys_mean))
                               for _, ys_mean, _ in y_segments)
            y_global_max = y_global_max if y_global_max > 0 else 1.0
            # Group colours from app
            si = getattr(self.app, 'samples_info', []) if self.app else []
            gc = getattr(self.app, 'group_colors', {}) if self.app else {}
            groups = {}
            for _i, _s in enumerate(si):
                lbl = _s.get('label', 'All')
                if str(_s.get('type', lbl)).upper() != 'BLK':
                    groups.setdefault(lbl, []).append(_i)
            import matplotlib.cm as _cm
            _cmap = _cm.get_cmap('tab10', max(len(groups), 1))
            gcols = {g: gc.get(g) or _cmap(i)
                     for i, g in enumerate(groups)}
            _legend_done = set()
            for x_seg, y_mean, y_all in y_segments:
                gmax = y_global_max
                if groups and y_all is not None:
                    n_s = y_all.shape[1]
                    for g, idxs in groups.items():
                        col = gcols.get(g, '#888')
                        ys  = [y_all[:, i] for i in idxs if i < n_s]
                        for y_s in ys:
                            self.ax.plot(x_seg, y_s / gmax, color=col,
                                         lw=0.6, alpha=0.35, zorder=1)
                        if ys and g not in _legend_done:
                            ymean_g = np.mean(ys, axis=0)
                            self.ax.plot(x_seg, ymean_g / gmax, color=col,
                                         lw=1.8, alpha=0.95, zorder=2,
                                         label=g)
                            _legend_done.add(g)
                else:
                    y_n = y_mean / gmax
                    self.ax.fill_between(x_seg, 0, y_n, color='#aaaaaa',
                                         alpha=0.35, zorder=1)
                    self.ax.plot(x_seg, y_n, color='#444444',
                                 lw=0.8, zorder=2, label='Experimental')

        # ── DB fingerprint sticks ─────────────────────────────────────────────
        matched_db_ppms = {round(mp['db_ppm'], 3)
                           for mp in met['matched_peaks']}

        db_height_max = max((p.get('height', 1.0) for p in db_peaks), default=1.0)

        # Build lookup: db_ppm → matched experimental ppm
        db_to_exp = {round(mp['db_ppm'], 3): mp['peak_ppm']
                     for mp in met['matched_peaks']}

        # ── Simulated DB spectrum ─────────────────────────────────────────────
        # For each DB multiplet, build a sum of Lorentzianas using the
        # relative intensities from the multiplet type.
        # Matched multiplets are positioned at the experimental peak (aligned);
        # unmatched ones stay at their DB position.
        x_sim  = np.linspace(span_lo - 0.05, span_hi + 0.05, 1000)
        y_sim  = np.zeros_like(x_sim)

        # Build peak-width lookup from experimental peaks
        _pk_width = {}
        for _pk in self.peaks:
            w = _pk.get('width_ppm') or _pk.get('width_at_half', 0.002)
            _pk_width[round(_pk['ppm'], 4)] = float(w) / 2  # HWHM

        import re as _re
        for p in db_peaks:
            dp_ppm     = p.get('ppm_center', p.get('ppm', 0))
            is_matched = round(dp_ppm, 3) in matched_db_ppms
            pred_lines = p.get('predicted_lines') if is_matched else None

            if pred_lines:
                # HWHM from the actual experimental peaks matched to each line
                for line in pred_lines:
                    xp   = line['ppm']
                    ri   = line['rel_intensity']
                    # Find nearest experimental peak for its linewidth
                    near = min(self.peaks, key=lambda pk: abs(pk['ppm'] - xp),
                               default=None) if self.peaks else None
                    if near:
                        w = (near.get('width_ppm') or
                             near.get('width_at_half') or 0.004)
                        hwhm = max(float(w) / 2, 0.0005)
                    else:
                        hwhm = 0.002
                    y_sim += ri * hwhm**2 / ((x_sim - xp)**2 + hwhm**2)
            else:
                # Unmatched: use DB window / 6 for linewidth estimate
                db_w  = max(abs(p.get('ppm_end', dp_ppm) -
                                p.get('ppm_start', dp_ppm)), 0.001)
                _jn   = [float(x) for x in _re.findall(r'\d+\.?\d*',
                         str(p.get('j_coupling', '') or '')) if float(x) > 0]
                hwhm  = max(db_w / 6, 0.001)
                anchor = db_to_exp.get(round(dp_ppm, 3), dp_ppm)
                offset = anchor - dp_ppm
                for st_ppm, st_rel in (p.get('sticks') or [(dp_ppm, 1.0)]):
                    xp = st_ppm + offset
                    y_sim += st_rel * hwhm**2 / ((x_sim - xp)**2 + hwhm**2)

        # Normalise simulated spectrum to 1
        if y_sim.max() > 0:
            y_sim /= y_sim.max()

        # Draw matched portions in green, unmatched in red
        # Build a colour mask along x_sim
        y_matched   = np.zeros_like(y_sim)
        y_unmatched = np.zeros_like(y_sim)
        for p in db_peaks:
            dp_ppm     = p.get('ppm_center', p.get('ppm', 0))
            is_matched = round(dp_ppm, 3) in matched_db_ppms
            db_w       = max(abs(p.get('ppm_end', dp_ppm) -
                                 p.get('ppm_start', dp_ppm)), 0.002)
            pred_lines = p.get('predicted_lines') if is_matched else None
            if pred_lines:
                ppms     = [l['ppm'] for l in pred_lines]
                center_x = (max(ppms) + min(ppms)) / 2
                win      = (max(ppms) - min(ppms)) / 2 + db_w
            else:
                anchor   = db_to_exp.get(round(dp_ppm, 3), dp_ppm)
                center_x = anchor
                win      = db_w * 3
            region = (x_sim >= center_x - win) & (x_sim <= center_x + win)
            if is_matched:
                y_matched[region]   = np.maximum(y_matched[region],
                                                  y_sim[region])
            else:
                y_unmatched[region] = np.maximum(y_unmatched[region],
                                                  y_sim[region])

        if y_matched.max() > 0:
            self.ax.fill_between(x_sim, 0, y_matched,
                                  color='#44bb44', alpha=0.30,
                                  label='DB matched', zorder=3)
            self.ax.plot(x_sim, y_matched,
                         color='#1a7a1a', linewidth=1.2, zorder=4)
        if y_unmatched.max() > 0:
            self.ax.fill_between(x_sim, 0, y_unmatched,
                                  color='#ee4444', alpha=0.20,
                                  label='DB unmatched', zorder=3)
            self.ax.plot(x_sim, y_unmatched,
                         color='#cc2200', linewidth=1.0,
                         linestyle='--', zorder=4)

        # ── Δppm labels on matched peaks ──────────────────────────────────────
        for mp in met['matched_peaks']:
            self.ax.annotate(
                f"Δ{mp['ppm_diff']:.3f}",
                xy=(mp['peak_ppm'], 0.92),
                xytext=(2, 3), textcoords='offset points',
                fontsize=6, color='#1a7a1a', alpha=0.9)

        # ── Legend / axes ─────────────────────────────────────────────────────
        self.ax.set_xlim(span_hi + 0.05, span_lo - 0.05)   # NMR inverted
        self.ax.set_ylim(bottom=-0.20, top=1.15)
        self.ax.set_xlabel('δ (ppm)', fontsize=9)
        self.ax.set_ylabel('Intensity (normalised to peak max)', fontsize=8)
        self.ax.set_title(met['name'], fontsize=10, fontweight='bold')
        self.ax.tick_params(labelsize=8)
        self.ax.grid(True, alpha=0.2, linestyle=':')
        # ── MCR deconvolution overlay ─────────────────────────────────────────
        # Find the detected peak for this metabolite (any matched peak rank)
        _det_pk_mcr = None
        for _mp2 in met['matched_peaks']:
            _rk2 = _mp2.get('peak_rank')
            if _rk2 is not None:
                _det_pk_mcr = next(
                    (p for p in self.peaks if p.get('rank') == _rk2), None)
                if _det_pk_mcr and _det_pk_mcr.get('mcr_annotation'):
                    break

        if _det_pk_mcr is not None:
            _mcr = _det_pk_mcr.get('mcr_annotation')
            if _mcr and _mcr.get('K', 1) >= 2:
                _r2 = _mcr.get('metrics', {}).get('r2', float('nan'))
                _K  = _mcr['K']
                self.ax.text(
                    0.02, 0.97,
                    f'MCR  K={_K}  R²={_r2:.3f}',
                    transform=self.ax.transAxes,
                    fontsize=7, va='top', color='#c62828',
                    bbox=dict(boxstyle='round,pad=0.2',
                              fc='white', ec='#c62828', alpha=0.75))

        # Legend — collect all labeled artists automatically
        from matplotlib.patches import Patch
        from matplotlib.lines import Line2D
        _base_handles = [
            Patch(facecolor='#aaaaaa', alpha=0.35, label='Experimental'),
            Line2D([0], [0], color='#1a7a1a', lw=2, label='DB matched'),
            Line2D([0], [0], color='#cc2200', lw=1.2,
                   alpha=0.5, label='DB unmatched'),
        ]
        _auto_h, _auto_l = self.ax.get_legend_handles_labels()
        _extra = [(h, l) for h, l in zip(_auto_h, _auto_l)
                  if l not in ('Experimental', 'DB matched', 'DB unmatched')]
        _all_h = _base_handles + [h for h, _ in _extra]
        self.ax.legend(handles=_all_h, loc='upper right', fontsize=7)

        self.ax.set_facecolor('#fafafa')
        self.fig.tight_layout()
        self.plot_canvas.draw_idle()

        # ── Quality card ──────────────────────────────────────────────────────
        n_db  = len(db_peaks)
        n_mat = len(matched_db_ppms)
        cov   = met['coverage']
        cos   = met['cosine']

        def _col(v, good, ok):
            if v >= good: return '#1a7a1a'
            if v >= ok:   return '#7a6000'
            return '#9a0000'

        self._set_q('coverage',  f"{cov:.1f}%",
                    _col(cov, 70, 40))
        self._set_q('cosine',    f"{cos:.4f}",
                    _col(cos, 0.80, 0.50))
        rri = met.get('rri')
        rri_txt   = f"{rri:.3f}" if rri is not None else 'N/A (singlets)'
        rri_color = (_col(rri, 0.85, 0.60) if rri is not None
                     else '#888888')
        self._set_q('n_matched',
                    f"{n_mat}/{n_db}  ·  RRI {rri_txt}",
                    rri_color)

        self.match_info.config(
            text=(f"{met['name']}  ·  {n_mat}/{n_db} DB peaks matched  "
                  f"·  {cov:.0f}% coverage  ·  cosine {cos:.3f}"))

    def _plot_peak_zoom(self, met, mp):
        """
        Show a single matched peak: experimental shape vs DB Lorentzian.

        The DB provides ppm_center + ppm_start/end (= width at base).
        We construct a normalised Lorentzian from those and overlay it
        on the normalised experimental slice around the peak.
        """
        self.ax.clear()

        exp_ppm  = float(mp['peak_ppm'])
        db_ppm   = float(mp['db_ppm'])
        ppm_diff = float(mp['ppm_diff'])

        # Find the DB peak entry to get width
        db_entry = next(
            (p for p in met['db_peaks']
             if abs(p.get('ppm_center', p.get('ppm', 0)) - db_ppm) < 0.01),
            None)
        if db_entry:
            db_width = max(
                abs(db_entry.get('ppm_end', db_ppm) -
                    db_entry.get('ppm_start', db_ppm)),
                0.002)
        else:
            db_width = 0.005   # fallback FWHM

        # Zoom window: 4× the larger of db_width or fwhm of experimental peak
        exp_peak = next(
            (p for p in self.peaks
             if p.get('rank') == mp.get('peak_rank')),
            None)
        exp_fwhm = (exp_peak.get('width_at_half', db_width)
                    if exp_peak else db_width)
        half_win = max(db_width * 4, exp_fwhm * 4, 0.015)

        lo = min(exp_ppm, db_ppm) - half_win
        hi = max(exp_ppm, db_ppm) + half_win

        # ── Experimental shape ────────────────────────────────────────────────
        mask  = (self.ppm >= lo) & (self.ppm <= hi)
        x_exp = self.ppm[mask]
        y_exp = self.mean_intensity[mask]

        if len(x_exp) >= 2:
            y_max = float(np.max(y_exp)) if np.max(y_exp) > 0 else 1.0
            y_norm = y_exp / y_max
            self.ax.fill_between(x_exp, 0, y_norm,
                                  color='#4477aa', alpha=0.30,
                                  label='Experimental', zorder=1)
            self.ax.plot(x_exp, y_norm,
                         color='#1a1a6e', linewidth=1.2, zorder=2)

        # ── DB multiplet shape: sum of Lorentzians at each stick position ──────
        # The sticks are anchored at exp_ppm (already shifted by offset above)
        db_entry = next(
            (p for p in met['db_peaks']
             if abs(p.get('ppm_center', p.get('ppm', 0)) - db_ppm) < 0.01),
            None)
        sticks = (db_entry.get('sticks') if db_entry else None) or [(db_ppm, 1.0)]
        # Shift sticks to align with experimental peak
        offset  = exp_ppm - db_ppm
        sticks  = [(sp + offset, si) for sp, si in sticks]
        hwhm    = max(db_width / 2, 0.001)

        x_db    = np.linspace(lo, hi, 600)
        y_db    = np.zeros_like(x_db)
        for st_ppm, st_rel in sticks:
            y_db += st_rel * hwhm**2 / ((x_db - st_ppm)**2 + hwhm**2)
        if y_db.max() > 0:
            y_db /= y_db.max()

        self.ax.fill_between(x_db, 0, y_db,
                              color='#44aa44', alpha=0.25,
                              label='DB fingerprint', zorder=1)
        self.ax.plot(x_db, y_db,
                     color='#1a7a1a', linewidth=1.5,
                     linestyle='--', zorder=3)

        # Individual sticks showing relative intensities
        for st_ppm, st_rel in sticks:
            self.ax.plot([st_ppm, st_ppm], [0, st_rel],
                         color='#1a7a1a', linewidth=1.5,
                         alpha=0.7, zorder=4)
            self.ax.scatter([st_ppm], [st_rel],
                            color='#1a7a1a', s=25, zorder=5)

        # ── Centre lines ──────────────────────────────────────────────────────
        self.ax.axvline(exp_ppm, color='#1a1a6e', linewidth=1.0,
                        linestyle=':', alpha=0.8, zorder=4,
                        label=f'Exp {exp_ppm:.4f}')
        self.ax.axvline(db_ppm, color='#1a7a1a', linewidth=1.0,
                        linestyle=':', alpha=0.8, zorder=4,
                        label=f'DB {db_ppm:.4f}')

        # ── Shift annotation ─────────────────────────────────────────────────
        y_ann = 1.05
        self.ax.annotate(
            '', xy=(exp_ppm, y_ann), xytext=(db_ppm, y_ann),
            arrowprops=dict(arrowstyle='<->', color='#cc5500', lw=1.2))
        self.ax.text((exp_ppm + db_ppm) / 2, y_ann + 0.04,
                     f'Δ {ppm_diff:.4f} ppm',
                     ha='center', fontsize=8, color='#cc5500')

        # ── Axes ──────────────────────────────────────────────────────────────
        self.ax.set_xlim(hi + half_win * 0.1, lo - half_win * 0.1)
        self.ax.set_ylim(-0.05, 1.25)
        self.ax.set_xlabel('δ (ppm)', fontsize=9)
        self.ax.set_ylabel('Intensity (normalised to peak max)', fontsize=8)
        self.ax.set_title(
            f"{met['name']}  ·  Peak #{mp['peak_rank']}",
            fontsize=9, fontweight='bold')
        self.ax.legend(loc='upper right', fontsize=7)
        self.ax.tick_params(labelsize=8)
        self.ax.grid(True, alpha=0.2, linestyle=':')
        self.ax.set_facecolor('#fafafa')
        self.fig.tight_layout()
        self.plot_canvas.draw_idle()

        # Update quality card for this peak
        self._set_q('coverage',
                    f"Δ = {ppm_diff:.4f} ppm",
                    '#1a7a1a' if ppm_diff < 0.005 else
                    '#7a6000' if ppm_diff < 0.02 else '#9a0000')
        self._set_q('cosine',
                    f"width {db_width:.4f} ppm",
                    '#1a7a1a' if db_width < 0.02 else '#7a6000')
        # RRI for this specific multiplet
        exp_region = [(p['ppm'],
                        float(self.mean_intensity[
                            int(np.argmin(np.abs(self.ppm - p['ppm'])))]))
                      for p in self.peaks
                      if lo <= p['ppm'] <= hi]
        rri = _rri_score(exp_region, sticks) if len(sticks) > 1 else None
        rri_txt = f"{rri:.3f}" if rri is not None else 'N/A'
        self._set_q('n_matched',
                    f"#{mp['peak_rank']}  {mp.get('type','')}  RRI {rri_txt}",
                    ('#1a7a1a' if rri is not None and rri >= 0.85
                     else '#7a6000' if rri is not None and rri >= 0.60
                     else '#9a0000') if rri is not None else '#888888')
        _pl = mp.get('predicted_lines', [])
        if len(_pl) > 1:
            _obs_c  = (_pl[0]['ppm'] + _pl[-1]['ppm']) / 2
            _j_obs  = abs(_pl[-1]['ppm'] - _pl[0]['ppm']) * 600.0
            _jdb    = mp.get('j_coupling', '')
            self.match_info.config(
                text=(f"{met['name']}  ·  centre {_obs_c:.4f}  →  "
                      f"db {db_ppm:.4f}  Δ{ppm_diff:.4f} ppm  ·  "
                      f"J_obs={_j_obs:.2f}Hz"))
        else:
            self.match_info.config(
                text=(f"{met['name']}  ·  exp {exp_ppm:.4f}  →  "
                      f"db {db_ppm:.4f}  Δ{ppm_diff:.4f} ppm  ·  "
                      f"width {db_width:.4f} ppm"))

    def _set_q(self, key, text, color):
        if key in self._q_labels:
            vl, ind = self._q_labels[key]
            vl.config(text=text)
            ind.config(fg=color)

    # ── Right-click drag region selection ────────────────────────────────────

    def _show_reset_btn(self, modified):
        """Update the 'modified' indicator next to the reset button."""
        try:
            if modified:
                self._reset_modified_lbl.config(text='● peaks modified by selection')
            else:
                self._reset_modified_lbl.config(text='')
        except Exception:
            pass

    def _rc_press(self, event):
        if event.button != 3 or event.inaxes != self.ax:
            return
        self._rc_drag_start = event.xdata
        # Remove old span if any
        if self._rc_span_patch is not None:
            try:
                self._rc_span_patch.remove()
            except Exception:
                pass
            self._rc_span_patch = None
        self.plot_canvas.draw_idle()

    def _rc_move(self, event):
        if self._rc_drag_start is None or event.inaxes != self.ax:
            return
        if event.xdata is None:
            return
        x0, x1 = sorted([self._rc_drag_start, event.xdata])
        if self._rc_span_patch is not None:
            try:
                self._rc_span_patch.remove()
            except Exception:
                pass
        self._rc_span_patch = self.ax.axvspan(
            x0, x1, color='#ff9900', alpha=0.18, zorder=10)
        self.plot_canvas.draw_idle()

    def _rc_release(self, event):
        if event.button != 3 or self._rc_drag_start is None:
            return
        x_end = event.xdata
        start  = self._rc_drag_start
        self._rc_drag_start = None

        # Remove selection span
        if self._rc_span_patch is not None:
            try:
                self._rc_span_patch.remove()
            except Exception:
                pass
            self._rc_span_patch = None

        if x_end is None or self._current_dp is None:
            self.plot_canvas.draw_idle()
            return

        lo_ppm, hi_ppm = min(start, x_end), max(start, x_end)
        if abs(hi_ppm - lo_ppm) < 0.0005:
            self.plot_canvas.draw_idle()
            return

        self._rc_select_region(lo_ppm, hi_ppm)

    # Multiplicity → number of expected peaks
    _MULT_N = {
        's': 1, 'd': 2, 't': 3, 'q': 4, 'p': 5, 'h': 6,
        'dd': 4, 'dt': 6, 'td': 6, 'ddd': 8,
    }

    def _rc_select_region(self, lo_ppm, hi_ppm):
        """Find N highest peaks in [lo_ppm, hi_ppm] and update predicted_lines."""
        dp     = self._current_dp
        mp_ref = self._current_mp_ref
        met    = self._current_met_dp
        if dp is None or met is None:
            return

        dp_type = (dp.get('type', 's') or 's').lower().strip()
        n_peaks = self._MULT_N.get(dp_type, 1)

        # Slice experimental spectrum
        mask = (self.ppm >= lo_ppm) & (self.ppm <= hi_ppm)
        if mask.sum() < 2:
            return
        x_reg = self.ppm[mask]
        y_reg = self.mean_intensity[mask].copy()

        # Try scipy find_peaks; fall back to top-N by intensity
        try:
            from scipy.signal import find_peaks as _fp
            # distance: at least 3 points between peaks
            peaks_idx, _ = _fp(y_reg, distance=max(1, len(y_reg) // (n_peaks * 4 + 1)))
        except ImportError:
            peaks_idx = np.array([])

        if len(peaks_idx) == 0:
            # Use top-N point indices by intensity
            peaks_idx = np.argsort(y_reg)[::-1][:n_peaks * 3]

        # Take N highest by intensity
        if len(peaks_idx) > n_peaks:
            top = sorted(peaks_idx, key=lambda i: y_reg[i], reverse=True)[:n_peaks]
            peaks_idx = np.array(top)

        if len(peaks_idx) == 0:
            return

        # Sort by ppm (ascending = high-field first as in NMR convention)
        peaks_idx = sorted(peaks_idx, key=lambda i: x_reg[i])

        # Build relative intensities from type
        intensities = _relative_intensities_from_type(dp_type, len(peaks_idx))

        new_pred_lines = []
        for k, idx in enumerate(peaks_idx):
            new_pred_lines.append({
                'ppm':           float(x_reg[idx]),
                'rel_intensity': intensities[k] if k < len(intensities) else 1.0,
            })

        # _orig_pred_lines is taken in _plot_db_peak_zoom on first display;
        # no separate backup needed here.

        # Update the matched_peak dict
        if mp_ref is not None:
            mp_ref['predicted_lines'] = new_pred_lines
            # Recompute ppm_diff using intensity-weighted centre
            if new_pred_lines:
                tot = sum(l['rel_intensity'] for l in new_pred_lines)
                if tot > 0:
                    obs_c = sum(l['ppm'] * l['rel_intensity']
                                for l in new_pred_lines) / tot
                else:
                    obs_c = (new_pred_lines[0]['ppm'] + new_pred_lines[-1]['ppm']) / 2
                mp_ref['ppm_diff'] = abs(obs_c - mp_ref.get('db_ppm', obs_c))
                mp_ref['peak_ppm'] = obs_c

            # Recompute J observed (spacing in Hz)
            ann_stage = (getattr(self.app, 'stages', {}) or {}).get('annotation')
            mhz = 600.0
            try:
                if ann_stage and hasattr(ann_stage, 'spectrometer_var'):
                    mhz = float(ann_stage.spectrometer_var.get())
            except Exception:
                pass
            if len(new_pred_lines) >= 2:
                sorted_pl = sorted(new_pred_lines, key=lambda l: l['ppm'])
                seps_ppm  = [abs(sorted_pl[i+1]['ppm'] - sorted_pl[i]['ppm'])
                             for i in range(len(sorted_pl) - 1)]
                j_obs_hz  = [s * mhz for s in seps_ppm]
                mp_ref['j_obs_hz']  = j_obs_hz
                mp_ref['j_obs_ppm'] = seps_ppm

        self._show_reset_btn(True)
        # Redraw the zoom view
        self._plot_db_peak_zoom(met, dp)

    def _rc_reset(self):
        """Restore predicted_lines to the initial state (taken on first display)."""
        if self._current_dp is None:
            return
        if self._current_mp_ref is None or self._orig_pred_lines is None:
            return
        # Restore to initial backup
        restored = list(self._orig_pred_lines)  # keep backup intact
        self._current_mp_ref['predicted_lines'] = restored
        # Restore ppm_diff / peak_ppm
        if restored:
            tot = sum(l['rel_intensity'] for l in restored)
            if tot > 0:
                obs_c = sum(l['ppm'] * l['rel_intensity'] for l in restored) / tot
            else:
                obs_c = (restored[0]['ppm'] + restored[-1]['ppm']) / 2
            db_ppm = self._current_mp_ref.get('db_ppm', obs_c)
            self._current_mp_ref['ppm_diff'] = abs(obs_c - db_ppm)
            self._current_mp_ref['peak_ppm'] = obs_c
        # Keep _orig_pred_lines intact so repeated resets always go to the same state.
        # Temporarily prevent _plot_db_peak_zoom from overwriting the backup by marking
        # that dp hasn't changed (it hasn't — same dp object).
        self._plot_db_peak_zoom(self._current_met_dp, self._current_dp)

    # ── Zoom / pan ────────────────────────────────────────────────────────────

    def _zoom(self, event):
        if event.inaxes != self.ax:
            return
        factor = 0.85 if event.button == 'up' else 1 / 0.85
        xlim = self.ax.get_xlim()
        ylim = self.ax.get_ylim()
        xd   = event.xdata or (xlim[0]+xlim[1])/2
        yd   = event.ydata or (ylim[0]+ylim[1])/2
        self.ax.set_xlim(xd+(xlim[0]-xd)*factor, xd+(xlim[1]-xd)*factor)
        self.ax.set_ylim(yd+(ylim[0]-yd)*factor, yd+(ylim[1]-yd)*factor)
        self.plot_canvas.draw_idle()

    def _pan_press(self, event):
        if event.inaxes != self.ax or event.button != 1:
            return
        self._pan_active = True
        self._pan_start  = (event.xdata, event.ydata)
        self.plot_canvas.get_tk_widget().config(cursor='fleur')

    def _pan_release(self, event):
        self._pan_active = False
        self._pan_start  = None
        self.plot_canvas.get_tk_widget().config(cursor='')

    def _pan_move(self, event):
        if not self._pan_active or event.inaxes != self.ax:
            return
        if event.xdata is None:
            return
        dx = self._pan_start[0] - event.xdata
        dy = self._pan_start[1] - event.ydata
        xl = self.ax.get_xlim()
        yl = self.ax.get_ylim()
        self.ax.set_xlim(xl[0]+dx, xl[1]+dx)
        self.ax.set_ylim(yl[0]+dy, yl[1]+dy)
        self._pan_start = (event.xdata, event.ydata)
        self.plot_canvas.draw_idle()

    # ── MCR Deconvolution for Undef peaks ────────────────────────────────────

    def _open_mcr_deconv(self):
        """Collect all Undef peaks and open AnnotationMCRWindow."""
        # Gather (met_dict, mp_dict, peak_dict) for every Undef matched peak
        app        = getattr(self, 'app', None)
        pd_stage   = getattr(app, 'stages', {}).get('peak_detection') if app else None
        ann_stage  = (getattr(app, 'stages', {}).get('annotation') if app else None)

        undef_items = []
        for met in self.metabolites:
            for mp in met['matched_peaks']:
                if mp.get('annotation_quality') is not None:
                    continue   # skip Good and Bad — only Undef
                rank = mp.get('peak_rank')
                peak = None
                if pd_stage and rank is not None:
                    peak = next((p for p in pd_stage.peaks
                                 if p.get('rank') == rank), None)
                if peak is None:
                    # Build a minimal stub so the window can still open
                    ppm = float(mp.get('peak_ppm', mp.get('db_ppm', 0)))
                    peak = {'rank': rank or 0, 'ppm': ppm,
                            'start_ppm': ppm - 0.015,
                            'end_ppm':   ppm + 0.015}
                undef_items.append((met, mp, peak))

        if not undef_items:
            from tkinter import messagebox
            messagebox.showinfo(
                'No Undef Peaks',
                'No Undefined peaks found.\n\n'
                'Use Ctrl+2 on a selected peak to mark it as Undef.',
                parent=self.win)
            return

        from gui.widgets.annotation_mcr_window import AnnotationMCRWindow
        AnnotationMCRWindow(
            self.win,
            undef_items,
            app,
            ann_stage=ann_stage,
            ann_results=self)

    # ── Export ────────────────────────────────────────────────────────────────

    def _export(self):
        from tkinter import filedialog
        import csv
        fn = filedialog.asksaveasfilename(
            title="Export Annotation Results",
            defaultextension=".csv",
            filetypes=[("CSV", "*.csv"), ("All", "*.*")],
            initialfile="annotation_results.csv",
            parent=self.win)
        if not fn:
            return
        try:
            with open(fn, 'w', newline='', encoding='utf-8-sig') as f:
                w = csv.writer(f)
                w.writerow([
                    'Peak #', 'Metabolite', 'Met ID',
                    'PPM', 'Start PPM', 'End PPM',
                    'Score', 'Quality', 'Candidates',
                    'DB PPM', 'Δ PPM', 'Multiplicity',
                ])
                for rank in sorted(self._peak_assignments):
                    met, mp = self._peak_assignments[rank]
                    det_pk = next((p for p in self.peaks
                                   if p.get('rank') == rank), None)
                    peak_ppm  = float(mp.get('peak_ppm', 0))
                    start_ppm = float(det_pk.get('start_ppm', peak_ppm)
                                      if det_pk else peak_ppm)
                    end_ppm   = float(det_pk.get('end_ppm', peak_ppm)
                                      if det_pk else peak_ppm)
                    score     = float(
                        mp.get('composite_score',
                               mp.get('multiplet_score', 0.0)) or 0.0)
                    n_cands   = len(self._peak_candidates.get(rank, []))
                    w.writerow([
                        rank,
                        met['name'],
                        met['id'],
                        f"{peak_ppm:.5f}",
                        f"{start_ppm:.5f}",
                        f"{end_ppm:.5f}",
                        f"{score:.4f}",
                        mp.get('annotation_quality', ''),
                        n_cands,
                        f"{mp.get('db_ppm', 0):.5f}",
                        f"{mp.get('ppm_diff', 0):.5f}",
                        mp.get('type', ''),
                    ])
            tk.messagebox.showinfo("Exported", f"Saved to:\n{fn}",
                                   parent=self.win)
        except Exception as e:
            tk.messagebox.showerror("Error", str(e), parent=self.win)

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _center(self):
        self.win.update_idletasks()
        w  = self.win.winfo_width()
        h  = self.win.winfo_height()
        sw = self.win.winfo_screenwidth()
        sh = self.win.winfo_screenheight()
        self.win.geometry(f"{w}x{h}+{(sw-w)//2}+{(sh-h)//2}")